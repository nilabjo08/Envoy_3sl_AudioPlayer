board/ab32vg1_hal_msp.o: ../board/ab32vg1_hal_msp.c \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_conf.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_gpio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_def.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vgx.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vg1.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/system_ab32vgx.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_gpio_ex.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_uart.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_rcu.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_wdt.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_sd.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_ll_sdio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_tim.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_rtc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_adc.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_conf.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_gpio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_def.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vgx.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vg1.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/system_ab32vgx.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_gpio_ex.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_uart.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_rcu.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_wdt.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_sd.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_ll_sdio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_tim.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_rtc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_adc.h:

applications/led.o: ../applications/led.c \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/rtdevice.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/ringbuffer.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/completion.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/dataqueue.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/workqueue.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/waitqueue.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/pipe.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/poll.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/ringblk_buf.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/serial.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_core.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_host.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_card.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_cmd.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sd.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio_func_ids.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/pin.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/hwtimer.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/audio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\audio/audio_pipe.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/adc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/pm.h \
 ../applications/Gpio_Pins_Defines.h ../applications/led.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board/board.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vgx.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vg1.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/system_ab32vgx.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_conf.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_gpio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_def.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_gpio_ex.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_uart.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_rcu.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_wdt.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_sd.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_ll_sdio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_tim.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_rtc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_adc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers/drv_gpio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers/drv_common.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rthw.h \
 ../applications/cable.h ../applications/play_mode.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\mp3player-latest\inc/mp3_player.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub/mp3dec.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/rtdevice.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/ringbuffer.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/completion.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/dataqueue.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/workqueue.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/waitqueue.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/pipe.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/poll.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/ringblk_buf.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/serial.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_core.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_host.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_card.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_cmd.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sd.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio_func_ids.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/pin.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/hwtimer.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/audio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\audio/audio_pipe.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/adc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/pm.h:
../applications/Gpio_Pins_Defines.h:
../applications/led.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board/board.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vgx.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vg1.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/system_ab32vgx.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_conf.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_gpio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_def.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_gpio_ex.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_uart.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_rcu.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_wdt.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_sd.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_ll_sdio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_tim.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_rtc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include/ab32vg1_hal_adc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers/drv_gpio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers/drv_common.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rthw.h:
../applications/cable.h:
../applications/play_mode.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\mp3player-latest\inc/mp3_player.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub/mp3dec.h:

################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../applications/adc1.c \
../applications/blehr_app.c \
../applications/book_mark.c \
../applications/cable.c \
../applications/dac_beep.c \
../applications/handshake_protocol.c \
../applications/led.c \
../applications/main.c \
../applications/mnt.c \
../applications/notify_audio.c \
../applications/notify_clip.c \
../applications/pause_mode.c \
../applications/play_mode.c \
../applications/timer1.c 

OBJS += \
./applications/adc1.o \
./applications/blehr_app.o \
./applications/book_mark.o \
./applications/cable.o \
./applications/dac_beep.o \
./applications/handshake_protocol.o \
./applications/led.o \
./applications/main.o \
./applications/mnt.o \
./applications/notify_audio.o \
./applications/notify_clip.o \
./applications/pause_mode.o \
./applications/play_mode.o \
./applications/timer1.o 

C_DEPS += \
./applications/adc1.d \
./applications/blehr_app.d \
./applications/book_mark.d \
./applications/cable.d \
./applications/dac_beep.d \
./applications/handshake_protocol.d \
./applications/led.d \
./applications/main.d \
./applications/mnt.d \
./applications/notify_audio.d \
./applications/notify_clip.d \
./applications/pause_mode.d \
./applications/play_mode.d \
./applications/timer1.d 


# Each subdirectory must supply rules for building sources it contributes
applications/%.o: ../applications/%.c
	riscv64-unknown-elf-gcc  -DDEBUG -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\blue_driver" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\apps\blehr\src" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\ext\tinycrypt\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ans\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\bas\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\dis\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\gap\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\gatt\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ias\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ipss\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\lls\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\tps\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\store\ram\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\util\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\porting\nimble\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\porting\npl\rtthread\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\applications" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board\ports" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libcpu\cpu" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers\config" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\MultiButton-v1.1.0" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\blue_driver\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\fal-v1.0.0\inc" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\real" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\mp3player-latest\inc" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\mp3player-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\optparse-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\devfs" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\elmfat" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\romfs" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\audio" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\libc\compilers\common" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\libc\compilers\gcc\newlib" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\utilities\ulog" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include" -isystem"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A" -include"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h" -std=gnu11 -c -mcmodel=medany -march=rv32imc -mabi=ilp32 -msave-restore  -ffunction-sections -Os -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"


################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../packages/helix-latest/real/bitstream.c \
../packages/helix-latest/real/buffers.c \
../packages/helix-latest/real/dct32.c \
../packages/helix-latest/real/dequant.c \
../packages/helix-latest/real/dqchan.c \
../packages/helix-latest/real/huffman.c \
../packages/helix-latest/real/hufftabs.c \
../packages/helix-latest/real/imdct.c \
../packages/helix-latest/real/polyphase.c \
../packages/helix-latest/real/scalfact.c \
../packages/helix-latest/real/stproc.c \
../packages/helix-latest/real/subband.c \
../packages/helix-latest/real/trigtabs.c 

OBJS += \
./packages/helix-latest/real/bitstream.o \
./packages/helix-latest/real/buffers.o \
./packages/helix-latest/real/dct32.o \
./packages/helix-latest/real/dequant.o \
./packages/helix-latest/real/dqchan.o \
./packages/helix-latest/real/huffman.o \
./packages/helix-latest/real/hufftabs.o \
./packages/helix-latest/real/imdct.o \
./packages/helix-latest/real/polyphase.o \
./packages/helix-latest/real/scalfact.o \
./packages/helix-latest/real/stproc.o \
./packages/helix-latest/real/subband.o \
./packages/helix-latest/real/trigtabs.o 

C_DEPS += \
./packages/helix-latest/real/bitstream.d \
./packages/helix-latest/real/buffers.d \
./packages/helix-latest/real/dct32.d \
./packages/helix-latest/real/dequant.d \
./packages/helix-latest/real/dqchan.d \
./packages/helix-latest/real/huffman.d \
./packages/helix-latest/real/hufftabs.d \
./packages/helix-latest/real/imdct.d \
./packages/helix-latest/real/polyphase.d \
./packages/helix-latest/real/scalfact.d \
./packages/helix-latest/real/stproc.d \
./packages/helix-latest/real/subband.d \
./packages/helix-latest/real/trigtabs.d 


# Each subdirectory must supply rules for building sources it contributes
packages/helix-latest/real/%.o: ../packages/helix-latest/real/%.c
	riscv64-unknown-elf-gcc  -DDEBUG -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\blue_driver" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\apps\blehr\src" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\ext\tinycrypt\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ans\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\bas\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\dis\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\gap\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\gatt\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ias\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ipss\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\lls\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\tps\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\store\ram\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\util\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\porting\nimble\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\porting\npl\rtthread\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\applications" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board\ports" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libcpu\cpu" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers\config" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\MultiButton-v1.1.0" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\blue_driver\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\fal-v1.0.0\inc" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\real" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\mp3player-latest\inc" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\mp3player-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\optparse-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\devfs" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\elmfat" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\romfs" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\audio" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\libc\compilers\common" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\libc\compilers\gcc\newlib" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\utilities\ulog" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include" -isystem"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A" -include"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h" -std=gnu11 -c -mcmodel=medany -march=rv32imc -mabi=ilp32 -msave-restore  -ffunction-sections -Os -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"


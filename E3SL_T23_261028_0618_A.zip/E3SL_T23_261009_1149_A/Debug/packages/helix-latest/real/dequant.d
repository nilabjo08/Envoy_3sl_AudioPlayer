packages/helix-latest/real/dequant.o: \
 ../packages/helix-latest/real/dequant.c \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h \
 ../packages/helix-latest/real/coder.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub/mp3common.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub/mp3dec.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub/statname.h \
 ../packages/helix-latest/real/assembly.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h:
../packages/helix-latest/real/coder.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub/mp3common.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub/mp3dec.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub/statname.h:
../packages/helix-latest/real/assembly.h:

packages/fal-v1.0.0/src/fal_partition.o: \
 ../packages/fal-v1.0.0/src/fal_partition.c \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\fal-v1.0.0\inc/fal.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board\ports/fal_cfg.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\fal-v1.0.0\inc/fal_def.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\fal-v1.0.0\inc/fal.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board\ports/fal_cfg.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\fal-v1.0.0\inc/fal_def.h:

packages/optparse-latest/optparse.o: \
 ../packages/optparse-latest/optparse.c \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h \
 ../packages/optparse-latest/optparse.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h:
../packages/optparse-latest/optparse.h:

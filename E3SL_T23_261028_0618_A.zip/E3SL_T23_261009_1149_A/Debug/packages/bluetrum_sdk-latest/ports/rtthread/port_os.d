packages/bluetrum_sdk-latest/ports/rtthread/port_os.o: \
 ../packages/bluetrum_sdk-latest/ports/rtthread/port_os.c \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h:

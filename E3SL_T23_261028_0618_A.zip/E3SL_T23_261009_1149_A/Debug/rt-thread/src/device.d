rt-thread/src/device.o: ../rt-thread/src/device.c \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/rtdevice.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/ringbuffer.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/completion.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/dataqueue.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/workqueue.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/waitqueue.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/pipe.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/poll.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/ringblk_buf.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/serial.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_core.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_host.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_card.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_cmd.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sd.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio_func_ids.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/pin.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/hwtimer.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/audio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\audio/audio_pipe.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/adc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/pm.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/rtdevice.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/ringbuffer.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/completion.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/dataqueue.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/workqueue.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/waitqueue.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/pipe.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/poll.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/ipc/ringblk_buf.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/serial.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_core.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_host.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_card.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_cmd.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sd.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio_func_ids.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/pin.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/hwtimer.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/audio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\audio/audio_pipe.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/adc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/pm.h:

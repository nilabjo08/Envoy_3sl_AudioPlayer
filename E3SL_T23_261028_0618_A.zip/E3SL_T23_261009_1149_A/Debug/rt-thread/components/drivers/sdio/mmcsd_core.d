rt-thread/components/drivers/sdio/mmcsd_core.o: \
 ../rt-thread/components/drivers/sdio/mmcsd_core.c \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_core.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_host.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_card.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_cmd.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sd.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmc.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio_func_ids.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdbg.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\utilities\ulog/ulog.h \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\utilities\ulog/ulog_def.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh/finsh.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_core.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_host.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_card.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmcsd_cmd.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sd.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/mmc.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include/drivers/sdio_func_ids.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include/rtdbg.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\utilities\ulog/ulog.h:
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\utilities\ulog/ulog_def.h:

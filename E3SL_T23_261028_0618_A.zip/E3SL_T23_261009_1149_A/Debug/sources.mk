################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
OBJS := 
SECONDARY_FLASH := 
SECONDARY_LIST := 
SECONDARY_SIZE := 
ASM_DEPS := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
applications \
board \
board/ports/audio \
board/ports \
libcpu/cpu \
libraries/hal_drivers \
libraries/hal_libraries/ab32vg1_hal/source \
libraries/hal_libraries/bmsis/source \
packages/MultiButton-v1.1.0 \
packages/bluetrum_sdk-latest/ports/rtthread \
packages/fal-v1.0.0/src \
packages/helix-latest \
packages/helix-latest/real \
packages/mp3player-latest/src \
packages/optparse-latest \
rt-thread/components/dfs/filesystems/devfs \
rt-thread/components/dfs/filesystems/elmfat \
rt-thread/components/dfs/filesystems/romfs \
rt-thread/components/dfs/src \
rt-thread/components/drivers/audio \
rt-thread/components/drivers/hwtimer \
rt-thread/components/drivers/misc \
rt-thread/components/drivers/pm \
rt-thread/components/drivers/sdio \
rt-thread/components/drivers/serial \
rt-thread/components/drivers/src \
rt-thread/components/finsh \
rt-thread/components/libc/compilers/common \
rt-thread/components/libc/compilers/gcc/newlib \
rt-thread/components/utilities/ulog/backend \
rt-thread/components/utilities/ulog \
rt-thread/src \


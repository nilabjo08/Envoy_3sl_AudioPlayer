libraries/hal_libraries/bmsis/source/startup.o: \
 ../libraries/hal_libraries/bmsis/source/startup.S \
 D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vg1.h
D\:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include/ab32vg1.h:

################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../libraries/hal_drivers/drv_adc.c \
../libraries/hal_drivers/drv_common.c \
../libraries/hal_drivers/drv_flash.c \
../libraries/hal_drivers/drv_gpio.c \
../libraries/hal_drivers/drv_hwtimer.c \
../libraries/hal_drivers/drv_sdio.c \
../libraries/hal_drivers/drv_usart.c 

OBJS += \
./libraries/hal_drivers/drv_adc.o \
./libraries/hal_drivers/drv_common.o \
./libraries/hal_drivers/drv_flash.o \
./libraries/hal_drivers/drv_gpio.o \
./libraries/hal_drivers/drv_hwtimer.o \
./libraries/hal_drivers/drv_sdio.o \
./libraries/hal_drivers/drv_usart.o 

C_DEPS += \
./libraries/hal_drivers/drv_adc.d \
./libraries/hal_drivers/drv_common.d \
./libraries/hal_drivers/drv_flash.d \
./libraries/hal_drivers/drv_gpio.d \
./libraries/hal_drivers/drv_hwtimer.d \
./libraries/hal_drivers/drv_sdio.d \
./libraries/hal_drivers/drv_usart.d 


# Each subdirectory must supply rules for building sources it contributes
libraries/hal_drivers/%.o: ../libraries/hal_drivers/%.c
	riscv64-unknown-elf-gcc  -DDEBUG -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\blue_driver" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\apps\blehr\src" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\ext\tinycrypt\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ans\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\bas\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\dis\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\gap\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\gatt\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ias\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\ipss\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\lls\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\services\tps\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\store\ram\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\host\util\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\nimble\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\porting\nimble\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\bluetrum_nimble\porting\npl\rtthread\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\applications" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board\ports" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\board" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libcpu\cpu" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers\config" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_drivers" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\ab32vg1_hal" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\libraries\hal_libraries\bmsis" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\MultiButton-v1.1.0" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest\blue_driver\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\bluetrum_sdk-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\fal-v1.0.0\inc" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\pub" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\helix-latest\real" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\mp3player-latest\inc" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\mp3player-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\packages\optparse-latest" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\devfs" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\elmfat" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\filesystems\romfs" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\dfs\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\audio" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\drivers\include" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\finsh" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\libc\compilers\common" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\libc\compilers\gcc\newlib" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\components\utilities\ulog" -I"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rt-thread\include" -isystem"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A" -include"D:\RT-ThreadStudio\workspace\E3SL_T23_261009_1149_A\rtconfig_preinc.h" -std=gnu11 -c -mcmodel=medany -march=rv32imc -mabi=ilp32 -msave-restore  -ffunction-sections -Os -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"


#include <rtthread.h>
#include "board.h"
#include <rtdevice.h>
#include "led.h"
#include "play_mode.h"
#include "Gpio_Pins_Defines.h"


#define ADC_DEV_NAME        "adc0"   /* ADC Device name */
#define ADC_DEV_CHANNEL     9

/* ---------------- Battery thresholds ---------------- */
#define ADC_SHUTDOWN_THRESH 783u     /* <= 839 -> critical, must shutdown cleanly */
#define ADC_LOWBATT_THRESH  801u     /* <= 870 -> low battery warning (blink LED) */
#define ADC_RECOVER_THRESH  821u     /* >  890 -> clear low-battery flag (hysteresis) */
#define ADC_FULL_THRESH     970u     /* >= 967 AND charging -> full */

/* ---- Sample-averaging configuration ----
 * We collect SAMPLE_COUNT ADC readings (one per SAMPLE_INTERVAL_MS) and
 * compare the average against each threshold.  Using an average removes
 * single-sample noise spikes from triggering false positives.
 */
#define SAMPLE_COUNT        15       /* number of samples to average */
#define SAMPLE_INTERVAL_MS  50       /* ms between individual samples (~750 ms total) */

/* After the 15-sample window is averaged, we still require
 * SHUTDOWN_CONFIRM_COUNT consecutive "averaged" readings to be at or below
 * the shutdown threshold before triggering the shutdown.  This adds a second
 * layer of hysteresis (each averaged window already filters noise). */
#define SHUTDOWN_CONFIRM_COUNT  3
#define FULL_CONFIRM_MS  (156000UL)

extern char battery_low;

/* Set by this thread when battery has been below the shutdown threshold
 * for SHUTDOWN_CONFIRM_COUNT consecutive averaged samples.  Consumed by the
 * keypad scan thread, which has a much larger stack and can safely run the
 * full device_stop() sequence (bookmark save + SD I/O + double beep + PE6
 * LOW).  We deliberately do NOT call device_stop() from this thread -- its
 * stack is too small for the deep call chain and would corrupt the thread
 * struct, causing the rt_timer_control assertion we saw before. */
volatile bool battery_shutdown_request = false;
volatile bool low_battery_bookmark_mode = false;

#define debug_prints 0   /* 0 = off, 1 = on */


/* ------------------------------------------------------------------
 * read_adc_average()
 *   Take SAMPLE_COUNT raw ADC readings spaced SAMPLE_INTERVAL_MS apart
 *   and return their arithmetic mean as a 32-bit value.
 * ------------------------------------------------------------------ */
static rt_uint32_t read_adc_average(rt_adc_device_t adc_dev)
{
    rt_uint32_t sum = 0;
    int i;

    for (i = 0; i < SAMPLE_COUNT; i++)
    {
        sum += rt_adc_read(adc_dev, ADC_DEV_CHANNEL);
        rt_thread_mdelay(SAMPLE_INTERVAL_MS);
    }

    return sum / SAMPLE_COUNT;
}


static void adc_vol_sample_thread(void *parameter)
{
    rt_adc_device_t adc_dev;     /* ADC device handle */
    rt_uint32_t value;
    rt_uint32_t     avg_value;   /* Averaged ADC value for this cycle */
    rt_err_t        ret = RT_EOK;
    bool            stable_state;
    int             low_count = 0;  /* consecutive averaged readings <= shutdown threshold */
    rt_tick_t  full_timer_start   = 0;
    bool       full_timer_running = false;

    /* ---- Find the ADC device ---- */
    adc_dev = (rt_adc_device_t)rt_device_find(ADC_DEV_NAME);
    if (adc_dev == RT_NULL)
    {
//        rt_kprintf("ADC sample run failed! Can't find %s device!\n", ADC_DEV_NAME);
        return;
    }

    /* ---- Enable the ADC channel (outside the loop) ---- */
    ret = rt_adc_enable(adc_dev, ADC_DEV_CHANNEL);
    if (ret != RT_EOK)
    {
//        rt_kprintf("ADC enable failed!\n");
        return;
    }

    /* ---- Main loop ---- */
    while (1)
    {
        /* If a shutdown has already been requested, just keep ticking
         * quietly – do not re-request, do not reset the counter. */
        if (battery_shutdown_request)
        {
            rt_thread_mdelay(1000);
            continue;
        }

        /* ---- Collect and average SAMPLE_COUNT readings ---- */
        avg_value = read_adc_average(adc_dev);

        /* Read cable / charging state AFTER the sampling window so it
         * reflects the state at the end of the window. */
        stable_state = rt_pin_read(CABLE_PIN);
        value        = rt_adc_read(adc_dev, ADC_DEV_CHANNEL);

//        rt_kprintf("ADC=%lu, ADC_avg=%lu, cable=%d, battery_low=%d, low_count=%d\n",
//                value, avg_value, stable_state, battery_low, low_count);

        #if debug_prints
//        rt_kprintf("cable pin=%d, ADC avg=%lu\n", stable_state, avg_value);
        #endif

        /* =============================================================
         * 1) CRITICAL SHUTDOWN  (highest priority, check first)
         *    Condition: averaged ADC <= ADC_SHUTDOWN_THRESH AND NOT
         *    charging, confirmed over SHUTDOWN_CONFIRM_COUNT consecutive
         *    averaged windows.
         * ============================================================= */

        if (!low_battery_bookmark_mode && (avg_value <= 800u))
        {
            low_battery_bookmark_mode = true;
//            rt_kprintf("Low-battery bookmark mode ACTIVATED (avg ADC=%lu)\n", avg_value);
        }
        if ((avg_value <= ADC_SHUTDOWN_THRESH) && (stable_state == 0))
        {
            /* Also set the low-battery flag for LED/UX consistency. */
            battery_low = 1;

            low_count++;
//            rt_kprintf("Critical battery window %d/%d  (avg ADC=%lu)\n",
//                       low_count, SHUTDOWN_CONFIRM_COUNT, avg_value);

            if (low_count >= SHUTDOWN_CONFIRM_COUNT)
            {
//                rt_kprintf("Critical battery CONFIRMED. Requesting shutdown...\n");
                /* Hand off to the keypad scan thread (big stack). */
                battery_shutdown_request = true;
                /* Keep looping (see top of loop) so we don't exit the
                 * thread while shutdown is pending. */
            }
        }
        else
        {
            /* Not in the shutdown zone (or cable plugged in) -> reset
             * the debounce counter so we only trip on sustained low V. */
            if (low_count != 0)
            {
//                rt_kprintf("Shutdown debounce reset (was %d)\n", low_count);
                low_count = 0;
            }

            /* =========================================================
             * 2) LOW BATTERY WARNING
             *    Averaged ADC <= ADC_LOWBATT_THRESH and NOT charging.
             *    Sets battery_low=1 so the LED thread blinks red.
             * ========================================================= */
            if ((avg_value <= ADC_LOWBATT_THRESH) && (stable_state == 0))
            {
                battery_low = 1;
//                rt_kprintf("Low battery warning! avg ADC=%lu\n", avg_value);
            }

            /* =========================================================
             * 3) FULL BATTERY
             *    Averaged ADC >= ADC_FULL_THRESH AND charging (cable in).
             *    Sets battery_full=1 and clears battery_low.
             * ========================================================= */
            else if ((avg_value >= ADC_FULL_THRESH) && (stable_state == 1))
            {
                if (!battery_full && !full_timer_running)
                {
                    full_timer_start   = rt_tick_get();
                    full_timer_running = true;
//                    rt_kprintf("Battery full timer started (avg ADC=%lu)\n", avg_value);
                }
            }

            if (full_timer_running && !battery_full)
            {
                rt_tick_t elapsed = rt_tick_get() - full_timer_start;
                rt_tick_t needed  = rt_tick_from_millisecond(FULL_CONFIRM_MS);
//                rt_kprintf("full timer: elapsed=%lu needed=%lu ticks_per_sec=%lu\n",
//                            elapsed, needed, (rt_tick_t)RT_TICK_PER_SECOND);

                if (elapsed >= needed)
                {
                    battery_full       = 1;
                    battery_low        = 0;
                    full_timer_running = false;
//                    rt_kprintf("Battery full CONFIRMED after 5 min!\n");
                }
            }

            /* =========================================================
             * 4) NORMAL / RECOVERY
             *    Averaged ADC clearly above the low-battery band.
             *    Clears battery_low (hysteresis: only above ADC_RECOVER_THRESH,
             *    not just above ADC_LOWBATT_THRESH).
             * ========================================================= */
            else if (avg_value > ADC_RECOVER_THRESH)
            {
                battery_low = 0;
                if (low_battery_bookmark_mode)
                {
                    low_battery_bookmark_mode = false;
//                    rt_kprintf("Low-battery bookmark mode CLEARED (avg ADC=%lu)\n", avg_value);
                }
                /* battery_full is left as-is; it was set above and will be
                 * cleared by the charging logic elsewhere when needed. */
            }
            /* else: in the hysteresis band (871..890) -> leave flags as-is */
        }

        /* Small gap between averaged windows to avoid hammering the ADC.
         * The sampling itself already takes ~750 ms (15 * 50 ms), so a
         * short pause here gives ~1 s between window starts. */
        rt_thread_mdelay(250);
    }
}


/* Thread entry function */
int adc_vol_sample_init(void)
{
    rt_thread_t tid;

    /* Stack can stay small because this thread no longer calls
     * device_stop() -- it just samples ADC and sets flags. */
    tid = rt_thread_create("adc_vol_sample",
                           adc_vol_sample_thread,
                           RT_NULL,
                           512,                          /* slightly larger for averaging loop */
                           RT_THREAD_PRIORITY_MAX - 2,
                           50);
    if (tid != RT_NULL)
    {
        rt_thread_startup(tid);
    }
    else
    {
        return -1;
    }

    return 0;
}

/* Export the ADC sampling thread function to the MSH command list */
INIT_ENV_EXPORT(adc_vol_sample_init);

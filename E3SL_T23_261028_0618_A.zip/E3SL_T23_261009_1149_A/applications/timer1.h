
#ifndef TIMER0123
#define TIMER0123


#include <rtthread.h>
#include "board.h"
#include "ab32vg1_hal_rtc.h"

extern volatile bool stopwatchflag;          // 1 == 3 sec,  2 == 5 sec
#define TIMER_PERIOD RT_TICK_PER_SECOND * 468 // 5 minutes (300 seconds) 20 == 40 sec, 156 == 5 min , 468 = 15 minutes
#define  PE6_PIN rt_pin_get("PE.6")
void timer_callback(void *parameter);
int start_5min_timer(void);
void stop_timer(void);



#endif

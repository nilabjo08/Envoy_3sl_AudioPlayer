/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-02     Admin       the first version
 */

#include <rtthread.h>
#include <rtdevice.h>
#include <rtconfig.h>
#include <stdio.h>
#include <stdbool.h>

#ifndef APPLICATIONS_PLAY_MODE_H_
#define APPLICATIONS_PLAY_MODE_H_

extern unsigned long start_time;
extern volatile bool suppress_playback;
extern volatile bool sd_switch_in_progress;
extern volatile bool firston;
extern volatile bool hold_browse_active;
typedef enum { SLOT_INTERNAL = 0, SLOT_EXTERNAL = 1 } sd_slot_t;
int switch_mount_and_play(sd_slot_t target, bool auto_play, bool source_lost);
//static rt_bool_t poweroff_in_progress = RT_FALSE;

extern volatile bool cableplay;
extern volatile bool sid;
extern volatile int Playoffcharge;
//volatile bool pause_mode_active = false;

typedef struct hk{
    unsigned char SD:1;
    unsigned char INT:1;
    unsigned char EXT:1;
}SLScombinations;

typedef struct
{
    int chapter_index;
    int book_index;
    int section_index;
    uint8_t volume;
    rt_tick_t last_button_press_time;
    bool button_pressed;
    rt_tick_t chapter_start_time;
    bool is_paused;
} app_state_t;
extern volatile app_state_t state;

extern volatile SLScombinations hk;
static int scan_sections();
static int scan_books();
static int scan_chapters();
void play_current(void);
void fast_forward(void);
void fast_rewind(void);
void enter_hold_browse_mode(void);
void exit_hold_browse_mode(bool should_play);
static void next_chapter(void);
static void prev_chapter(void);
static void next_book(void);
static void prev_book(void);
static void next_section(void);
static void prev_section(void);
static void volume_up(int step);
static void volume_down(int step);
 void button_play_pause(void);
static uint8_t Play_button_read_pin(void);
static uint8_t SD_BUTTON_READ_PIN(void);
void play_pause_callback(void* p);
static void button_callback(void *btn);
void keypad_scan_thread_entry(void* p);
void init_pins(void);
int keypad_matrix_init(void);
static void keypad_matrix_cleanup(void);
void exitSleepMode();
void prepareSleepMode();
static void wakeup_init(void);
int rtthread_startup(void);
static void wakeup_callback(void *args);
#endif /* APPLICATIONS_PLAY_MODE_H_ */





















































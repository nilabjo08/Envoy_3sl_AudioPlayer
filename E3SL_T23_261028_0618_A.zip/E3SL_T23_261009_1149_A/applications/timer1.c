

#include "timer1.h"
#include "play_mode.h"
#include "Gpio_Pins_Defines.h"
#include "dac_beep.h"
 rt_timer_t timer = RT_NULL;
 volatile bool stopwatchflag=false;
//void timer_callback(void *parameter)
//{
//    // Timer timeout callback function.
//   rt_kprintf("Timer expired after 5 minutes!\n");
//    rt_kprintf("Auto shut-off triggered\n");
//
//    int current_state = rt_pin_read(PE6_PIN);
//    if(current_state == PIN_HIGH)
//    {
//
////        stopwatchflag=true;
//    }
//
//}

 void timer_callback(void *parameter)
 {
     stopwatchflag = true;
 }


//int start_5min_timer(void)
//{
//
//
//    // Create a timer that expires after 5 minutes (300 seconds)
//    timer = rt_timer_create("timer_5min", timer_callback, RT_NULL, TIMER_PERIOD, RT_TIMER_FLAG_ONE_SHOT);
//
//    if (timer == RT_NULL)
//    {
//        rt_kprintf("Timer creation failed!\n");
//        return -RT_ERROR;
//    }
//
//    // Start the timer
//    rt_timer_start(timer);
//
//    rt_kprintf("Timer activated!\n");
//
//    return RT_EOK;
//}


 int start_5min_timer(void)
 {
     if (timer == RT_NULL)
     {
         timer = rt_timer_create("timer_5min",
                                 timer_callback,
                                 RT_NULL,
                                 TIMER_PERIOD,
                                 RT_TIMER_FLAG_ONE_SHOT);

         if (timer == RT_NULL)
         {
//             rt_kprintf("Timer creation failed!\n");
             return -RT_ERROR;
         }
     }

     rt_timer_stop(timer);   // ensure clean restart
     rt_timer_start(timer);

//     rt_kprintf("Timer activated!\n");

     return RT_EOK;
 }


//void stop_timer(void){
//    rt_timer_stop(timer);
//    rt_kprintf("Timer Stopped!\n");
//}

 void stop_timer(void)
 {
     if (timer != RT_NULL)
     {
         rt_timer_stop(timer);
         stopwatchflag = false;   // prevent accidental trigger
//         rt_kprintf("Timer Stopped!\n");
     }
 }


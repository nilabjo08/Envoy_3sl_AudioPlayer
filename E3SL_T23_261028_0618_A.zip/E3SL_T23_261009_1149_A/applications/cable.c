#include <rtthread.h>
#include "board.h"
#include "play_mode.h"
#include "pause_mode.h"
#include <mp3_player.h>
#include "cable.h"
#include "Gpio_Pins_Defines.h"
#include "handshake_protocol.h"
#include "mp3_player.h"
#include "led.h"


#define CABLE_SLOT_INTERNAL  0   /* matches sd_slot_t SLOT_INTERNAL in play_mode.c */
#define CABLE_SLOT_EXTERNAL  1   /* matches sd_slot_t SLOT_EXTERNAL in play_mode.c */


#define  PE6_PIN rt_pin_get("PE.6")        /* power-hold latch (MOS_PIN). */
                                           /* HIGH = power on, LOW = power OFF! */
//static int a=0,b=0,c=0,d=0;
#define DEBOUNCE_MS 30
volatile char typec=false;
rt_bool_t charging;
volatile bool pause=false;
volatile int g_in_switch=false;
extern volatile uint32_t songseek;   /* from play_mode.c — current playback second */

typedef enum {
    STATE_IDLE,
    STATE_CABLE_INSERTED
} system_state_t;

static rt_thread_t cable_thread = RT_NULL;
static rt_sem_t cable_sem = RT_NULL;
static volatile system_state_t current_state = STATE_IDLE;
static rt_mutex_t state_mutex = RT_NULL;

/*
 * Tracks whether the cable was inserted while the device was already active
 * (playing or paused).  On removal we use this to choose the right teardown
 * path instead of the full "power-off / GLIC" remount sequence.
 */
volatile bool cable_charge_only = false;

void set_internal_sd_active(void)
{
    rt_pin_mode(GPIO_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(GPIO_PIN, PIN_HIGH);
//    rt_kprintf("[SD] Internal + microSD enabled\n");
}

void set_external_sd_active(void)
{
    rt_pin_mode(GPIO_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(GPIO_PIN, PIN_LOW);
//    rt_kprintf("[SD] External microSD only\n");
}

void cable_isr(void *args)
{
    rt_sem_release(cable_sem);
}

/*
 * handle_cable_event()
 *
 * Behaviour summary
 * -----------------
 *
 *  cable_state != 0  →  cable / SLS inserted
 *  ├─ Device ON, playback active  (PLAYER_STATE_PLAYING)
 *  │    REQ 1:  Stay in playback mode.  Start battery charging.
 *  │    REQ 4:  GL823K held in reset — NO USB data access from host.
 *  │
 *  ├─ Device ON, player paused    (PLAYER_STATE_PAUSED)
 *  │    REQ 2:  Stay in pause mode.  Start battery charging.
 *  │    REQ 4:  GL823K held in reset — NO USB data access from host.
 *  │
 *  └─ Device OFF / stopped        (PLAYER_STATE_STOPPED or initial power-up)
 *       REQ 3:  Switch to GLIC mode.  Route appropriate SD card(s) to
 *               GL823K so the host can write data.  Start charging.
 *
 *  cable_state == 0  →  cable / SLS removed
 *  ├─ Was inserted while device was active (active_on_insert == true)
 *  │    Just clear charging flags and update the LED.  No remount needed
 *  │    because the MCU never lost SD bus ownership.
 *  │
 *  └─ Was inserted while device was off  (active_on_insert == false)
 *       Disable GL823K, restore MCU SD-bus ownership, and re-enter normal
 *       playback (switch_mount_and_play → resume from bookmark).
 */
void handle_cable_event(uint8_t cable_state)
{
    static uint32_t cable = 0;
    int held = 0;

    if (state_mutex && rt_mutex_take(state_mutex, RT_WAITING_FOREVER) == RT_EOK)
        held = 1;

    if (cable_state) {
        /* ============================================================
         * CABLE INSERTED
         * ============================================================ */
        rt_pin_mode(PE6_PIN, PIN_MODE_OUTPUT);
        rt_pin_write(PE6_PIN, PIN_HIGH);          /* keep power latched on */

        if (current_state == STATE_IDLE) {
            int player_state = mp3_player_state_get();

            if (player_state == PLAYER_STATE_PLAYING ||
                player_state == PLAYER_STATE_PAUSED) {
                /* -------------------------------------------------------
                 * REQ 1 (playing) / REQ 2 (paused):
                 *   Remain in current mode.  Start charging.
                 *   REQ 4: Block GL823K — no host data access.
                 * ------------------------------------------------------- */

                /* GL823K stays in (or is put into) reset so the USB-C/SLS
                 * port presents only a charging profile to the host.       */
                rt_pin_write(GL_Soc, PIN_HIGH);

                if (player_state == PLAYER_STATE_PLAYING) {
                    /* Snapshot position for a potential unplug/resume cycle */
                    songseek = mp3_get_cur_seconds();
//                    rt_kprintf("Cable: playback active — charge-only mode, "
//                               "GL823K blocked. cur_sec=%u\n",
//                               (unsigned)songseek);
                } else {
//                    rt_kprintf("Cable: player paused — charge-only mode, "
//                               "GL823K blocked.\n");
                }

                /* Do NOT call pause_mode_activate():
                 *   REQ 1 — device must STAY in playback.
                 *   REQ 2 — device must STAY in pause mode.               */
                typec             = true;
                charging          = 1;
                cable_charge_only  = true;   /* remember: was active on insert */
                current_state     = STATE_CABLE_INSERTED;

            } else {
                /* -------------------------------------------------------
                 * REQ 3:  Device was off (player stopped / initial boot
                 *         via VBUS power).  Enable GLIC (GL823K) and route
                 *         the correct SD card so the host can write data.
                 *
                 * HandShake_setup() handles everything:
                 *   1. Sends a pulse on SBU_PIN and listens for a reply.
                 *   2. HANDSHAKE_SUCCESS (reply received) → SLS cable
                 *        internal_Mosfet LOW, external_Mosfet HIGH,
                 *        SD1_SD2 LOW  → GL823K sees INTERNAL SD only.
                 *   3. HANDSHAKE_FAILED (no reply) → normal Type-C cable
                 *        internal_Mosfet HIGH, external_Mosfet LOW,
                 *        SD1_SD2 HIGH → GL823K sees EXTERNAL SD only.
                 *   4. GL_Soc LOW → releases GL823K from reset so the
                 *        host can enumerate and access the chosen SD card.
                 * ------------------------------------------------------- */
//                rt_kprintf("Cable: device off — calling HandShake_setup() "
//                           "to detect SLS vs Type-C and route SD card.\n");

                songseek          = 0;   /* no playback position to restore */
                typec             = true;
                charging          = 1;
                cable_charge_only  = false;
                current_state     = STATE_CABLE_INSERTED;

                /* HandShake_setup() performs cable detection, SD switching,
                 * and GL823K enable in one call.                            */
                HandShake_setup();
            }
        }

    } else {
        /* ============================================================
         * CABLE REMOVED
         * ============================================================
         *
         * PE6_PIN must stay HIGH throughout.  Driving it LOW — even
         * briefly — releases the power MOSFET and kills the CPU the
         * instant VBUS disappears.
         */
        rt_pin_mode(PE6_PIN, PIN_MODE_OUTPUT);
        rt_pin_write(PE6_PIN, PIN_HIGH);

        typec = false;

        if (cable_charge_only) {
            /* -------------------------------------------------------
             * Device was playing or paused when the cable was inserted.
             * The MCU never relinquished SD bus ownership and the player
             * never stopped, so no remount or resume sequence is needed.
             * Just clear charging state and restore the LED.
             * ------------------------------------------------------- */
//            rt_kprintf("Cable removed: device was active on insert — "
//                       "clearing charge flags, no remount.\n");

            charging         = 0;
            Playoffcharge    = 0;
            cable_charge_only = false;

            /* GL823K was already in reset; re-assert to be safe             */
            rt_pin_write(GL_Soc, PIN_HIGH);

            /* Restore LED to its normal SD-colour                           */
            update_led_color();

            current_state = STATE_IDLE;

        } else {
            /* -------------------------------------------------------
             * Device was off (GLIC mode) when the cable was inserted.
             * Disable GL823K, restore MCU SD-bus ownership, and restart
             * playback from the bookmark.
             * ------------------------------------------------------- */
            int player_state = mp3_player_state_get();

            if (player_state == PLAYER_STATE_STOPED)
            {
//                rt_kprintf("Cable removed: charging from power-off mode, going power off\n");

                charging          = 0;
                Playoffcharge     = 0;
                battery_full      = 0;
                ledflag           = false;
                cable_charge_only = false;
                current_mode      = LED_MODE_OFF;
                current_state     = STATE_IDLE;

                rt_pin_write(GL_Soc, PIN_HIGH);   // keep GL823K disabled
                update_led_off();                 // orange/green/red LED off

                if (held)
                    rt_mutex_release(state_mutex);

                rt_enter_critical();
                rt_pin_write(PE6_PIN, PIN_LOW);   // release power latch, device off
                rt_exit_critical();

                return;
            }
//            rt_kprintf("Cable removed: was in GLIC mode — restoring MCU "
//                       "SD access and resuming playback.\n");

            if (cableplay == false) {
//                rt_kprintf("cable off\n");
                rt_thread_mdelay(10);
            }

            /* Snapshot pin states at the moment of unplug                  */
            int a = rt_pin_read(GL_Soc);
            int b = rt_pin_read(SD1_SD2);
            int c = rt_pin_read(internal_Mosfet);
            int d = rt_pin_read(external_Mosfet);
//            rt_kprintf("at unplug: GL=%d SD=%d INT=%d EXT=%d\n", a, b, c, d);

            unsigned char tempo = ((b << 2) | (c << 1) | (d));
            unsigned char temp  = ((hk.SD << 2) | (hk.INT << 1) | (hk.EXT));
//            rt_kprintf("hk before unplug: SD=%d INT=%d EXT=%d "
//                       "(temp=0x%02X tempo=0x%02X)\n",
//                       hk.SD, hk.INT, hk.EXT, temp, tempo);

            /* Park GL823K in reset so the SD lines belong to the MCU       */
            rt_pin_write(GL_Soc, PIN_HIGH);

            if (temp == 0x01) {
//                rt_kprintf("mount and switch INTERNAL %d\n", cable++);
                paused = 100;
                g_in_switch = 1;
                switch_mount_and_play(CABLE_SLOT_INTERNAL, true, false);
                paused = 0;
            } else if (temp == 0x06) {
//                rt_kprintf("mount and switch EXTERNAL %d\n", cable++);
                paused = 100;
                g_in_switch = 1;
                switch_mount_and_play(CABLE_SLOT_EXTERNAL, true, false);
                paused = 0;
            }

            rt_pin_write(AUDIO_SWITCH_PIN, PIN_LOW);

            /* switch_mount_and_play(auto_play=true) already:
             *   1. primes player.start_offset_seconds from songseek (if > 0)
             *   2. calls play_current() which sends MSG_START
             *   3. the player thread seeks to the bookmark byte in one FAT
             *      chain walk inside its startup sequence — no second open.
             * Nothing more to do here for playback or seeking. */

            /* Release the autoplay gate only after playback has resumed     */
            g_in_switch = 0;

            /* Paranoid keep-alive: re-assert the power latch                */
            rt_pin_write(PE6_PIN, PIN_HIGH);

            charging      = 0;
            Playoffcharge = 0;

            update_led_color();

            current_state = STATE_IDLE;
        }
    }

//    rt_kprintf("release mutex from cable.c\n");
    if (held) rt_mutex_release(state_mutex);
}


void cable_thread_entry(void *parameter)
{
    uint8_t last_state = rt_pin_read(CABLE_PIN);
    uint8_t stable_state;
    rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);
    rt_pin_mode(CABLE_PIN, PIN_MODE_INPUT_PULLDOWN);
    rt_pin_attach_irq(CABLE_PIN, PIN_IRQ_MODE_FALLING, cable_isr, RT_NULL);
    rt_pin_irq_enable(CABLE_PIN, PIN_IRQ_ENABLE);
//    rt_kprintf("cable thread initialised\n");


    while (1) {
        rt_sem_take(cable_sem, rt_tick_from_millisecond(500));
        rt_thread_mdelay(DEBOUNCE_MS);
        stable_state = rt_pin_read(CABLE_PIN);

        if (stable_state != last_state) {
            last_state = stable_state;
            handle_cable_event(stable_state);
        }
    }
}

int cable_detect_init(void)
{
    state_mutex = rt_mutex_create("cable_mutex", RT_IPC_FLAG_PRIO);
    if (!state_mutex) return -RT_ERROR;

    cable_sem = rt_sem_create("cable_sem", 0, RT_IPC_FLAG_FIFO);
    if (!cable_sem) {
        rt_mutex_delete(state_mutex);
        return -RT_ERROR;
    }

    cable_thread = rt_thread_create("cable_thread", cable_thread_entry,
                                    RT_NULL, 2048, 7, 20);
    if (cable_thread) {
        rt_thread_startup(cable_thread);
        return RT_EOK;
    }

    rt_sem_delete(cable_sem);
    rt_mutex_delete(state_mutex);
    return -RT_ERROR;
}

void cable_detect_deinit(void)
{
    if (cable_thread) rt_thread_delete(cable_thread);
    if (cable_sem)    rt_sem_delete(cable_sem);
    if (state_mutex)  rt_mutex_delete(state_mutex);
}

INIT_APP_EXPORT(cable_detect_init);

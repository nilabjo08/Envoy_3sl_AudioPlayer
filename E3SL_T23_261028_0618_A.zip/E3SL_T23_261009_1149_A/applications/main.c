/*
 * Copyright (c) 2020-2021, Bluetrum Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2020/12/10     greedyhao    The first version
 */
#include <rtthread.h>
#include "board.h"
#include <Gpio_Pins_Defines.h>

int main()
{

    while(1){
//        if (rt_pin_read(AUDIO_SWITCH_PIN) == PIN_LOW)
//        {
//            rt_kprintf("LOW\n");
//        }
//        else {
//            rt_kprintf("HIGH\n");
//        }
        rt_thread_mdelay(500);
    }
}








/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-19     Admin       the first version
 */
// Code of 3sl_testing_code_v3.2

#include <rtthread.h>
#include <rtdevice.h>
#include <stdbool.h>
#define power_play rt_pin_get("PB.3")    // Play/Pause and Power ON/OFF

#define   GPIO_PIN  rt_pin_get("PF.5")  // GPIO Switching PIN between SD cards

#define   MOS_PIN   rt_pin_get("PE.6")
#define   SD_EXT    rt_pin_get("PE.2")

#define  MICR       rt_pin_get("MICR")


#define Red_led rt_pin_get("PE.1")             // Red Led
#define Green_led rt_pin_get("PE.4")            // Green Led

#define EARPHONE_DETECT_PIN   rt_pin_get("PF.2")  // Earphone jack pin
#define AUDIO_SWITCH_PIN rt_pin_get("PB.4")        // Speaker Shut down pin



#define CABLE_PIN rt_pin_get("PF.0")  // Cable detection pin (SLS and standard cable)

#define SBU_PIN  rt_pin_get("PE.0")     // Handshake start pin
#define GL_Soc rt_pin_get("PE.5")
#define SD1_SD2 rt_pin_get("PE.3")
extern volatile char sd_det_flag;


#define external_Mosfet rt_pin_get("PA.6")
#define internal_Mosfet rt_pin_get("PA.5")
#define GL_Soc rt_pin_get("PE.5")


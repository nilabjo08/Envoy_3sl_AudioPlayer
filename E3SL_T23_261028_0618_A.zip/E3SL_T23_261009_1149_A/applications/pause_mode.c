#include <rtthread.h>
#include "play_mode.h"
#include <mp3_player.h>
#include "pause_mode.h"


static rt_mutex_t pause_mutex = RT_NULL;
static pause_mode_state_t current_state = PAUSE_MODE_INACTIVE;



int pause_mode_init(void)
{
    // Check if mutex already exists
    if (pause_mutex != RT_NULL) {
//        rt_kprintf("Pause mutex already exists\n");
        return RT_EOK;
    }

    // Create mutex with priority inheritance to prevent priority inversion
    pause_mutex = rt_mutex_create("pause_mutex", RT_IPC_FLAG_PRIO);
    if(!pause_mutex) {
//        rt_kprintf("Failed to create pause mode mutex\n");
        return -RT_ERROR;
    }

//    rt_kprintf("Pause mode mutex created successfully\n");
    return RT_EOK;
}

// Add this to ensure initialization
INIT_COMPONENT_EXPORT(pause_mode_init);

int pause_mode_lock(void) {
    if(pause_mutex == RT_NULL) {
//        rt_kprintf("Mutex not initialized, trying to recreate\n");
        pause_mode_init();
        if(pause_mutex == RT_NULL) {
            return -RT_ERROR;
        }
    }

    rt_err_t result = rt_mutex_take(pause_mutex, rt_tick_from_millisecond(100));
    if(result != RT_EOK) {
//        rt_kprintf("Failed to take mutex (error: %d), owner: %s\n",
//                  result,
//                  pause_mutex->owner ? pause_mutex->owner->name : "none");
        return -RT_ERROR;
    }
    return RT_EOK;
}

int pause_mode_unlock(void) {
    if(pause_mutex == RT_NULL) {
        return -RT_ERROR;
    }

    // Verify current thread owns the mutex
    if(pause_mutex->owner != rt_thread_self()) {
//        rt_kprintf("Warning: Thread %s trying to unlock mutex owned by %s\n",
//                  rt_thread_self()->name,
//                  pause_mutex->owner ? pause_mutex->owner->name : "none");
        return -RT_ERROR;
    }

    return rt_mutex_release(pause_mutex);
}
pause_mode_state_t pause_mode_get_state(void) {
    pause_mode_state_t state;
    if(pause_mode_lock() == RT_EOK)
    {
        state = current_state;
        pause_mode_unlock();
    }
    else{
        state = PAUSE_MODE_INACTIVE;
    }
    return state;
}
int pause_mode_activate(void) {
    if (pause_mode_lock() != RT_EOK) {
//        rt_kprintf("Critical: Unable to acquire pause mutex\n");
        return -RT_ERROR;
    }

    int result = RT_EOK;
    if (current_state != PAUSE_MODE_ACTIVE) {
        int player_state = mp3_player_state_get();
//        rt_kprintf("Current player state: %d\n", player_state);

        if (player_state == PLAYER_STATE_PLAYING) {
            if (mp3_player_pause() == RT_EOK) {
                current_state = PAUSE_MODE_ACTIVE;
//                rt_kprintf("Playback successfully paused\n");
            } else {
//                rt_kprintf("Failed to pause playback\n");
                result = -RT_ERROR;
            }
        }
        else if (player_state == PLAYER_STATE_PAUSED) {
            /* Already paused — still arm pause_mode so cable removal triggers resume.
             * Without this, pause_mode_deactivate() sees INACTIVE and does nothing. */
            current_state = PAUSE_MODE_ACTIVE;
//            rt_kprintf("Player already paused; pause_mode armed for cable resume\n");
        }
    }

    pause_mode_unlock();
    return result;
}

int pause_mode_deactivate(void) {
    if (pause_mode_lock() != RT_EOK) {
//        rt_kprintf("Critical: Unable to acquire pause mutex\n");
        return -RT_ERROR;
    }

//    rt_kprintf("pause_mode_deactivate\n");              // 6
    int result = RT_EOK;

    if (current_state != PAUSE_MODE_INACTIVE) {
        int player_state = mp3_player_state_get();

        if (player_state == PLAYER_STATE_PAUSED) {
            if (mp3_player_resume() == RT_EOK) {
                current_state = PAUSE_MODE_INACTIVE;
//                rt_kprintf("Playback successfully resumed\n");
            } else {
//                rt_kprintf("Failed to resume playback\n");
                // Add recovery attempt
                rt_thread_mdelay(100);
                play_current();
                current_state = PAUSE_MODE_INACTIVE;
                result = RT_EOK;
            }
        } else if (player_state == PLAYER_STATE_PLAYING) {
            /* switch_mount_and_play(..., true, ...) already started the target
             * chapter.  Starting play_current() again here queues another STOP/
             * START cycle for the same URI and can make one chapter repeat. */
//            rt_kprintf("Player already playing; clearing pause state only\n");
            current_state = PAUSE_MODE_INACTIVE;
        } else {
//            rt_kprintf("Player stopped, trying play_current()\n");
            rt_thread_mdelay(50);
            play_current();
            current_state = PAUSE_MODE_INACTIVE;
        }
    }

    pause_mode_unlock();
    return result;
}

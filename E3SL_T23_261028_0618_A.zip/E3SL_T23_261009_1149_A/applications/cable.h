/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-03     Admin       the first version
 */
#ifndef APPLICATIONS_CABLE_H_
#define APPLICATIONS_CABLE_H_
#include <stdbool.h>
extern rt_bool_t charging;

extern volatile char typec;
extern volatile int g_in_switch;
extern volatile bool cable_charge_only;
extern rt_bool_t charging;
void cable_isr(void *args);
void cable_thread_entry(void *parameter);
int cable_detect_init(void);
void cable_detect_deinit(void);
void duplicate_cable_entry();
#endif /* APPLICATIONS_CABLE_H_ */

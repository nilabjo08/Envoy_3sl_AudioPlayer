#include "handshake_protocol.h"
#include "board.h"
#include "Gpio_Pins_Defines.h"
#include "play_mode.h"
#include "cable.h"
#include "led.h"
#define BIT_SHORT_MIN    400   // accept ~500 µs
#define BIT_SHORT_MAX    700
#define BIT_LONG_MIN     2000  // accept ~2500 µs
#define BIT_LONG_MAX     3000

#define GLITCH_THRESHOLD 300
#define BYTE_TIMEOUT_MS 300
#define  PE6_PIN rt_pin_get("PE.6")
bool sdswitch=false;

#define HEX                 "%02X"
#define HIGH                   1
#define  LOW                   0
#define HANDSHAKE_TIMEOUT_MS 500

volatile handshake_status_t handshake_status = HANDSHAKE_IDLE;
uint8_t receivedByte;
bool handshake_terminate=false;
// External symbols
extern bool cable_BTN_flag;
extern bool btn_flag;
volatile int PLY_resume=100;
static int a=0,b=0,c=0,d=0;
static bool sls_active = false;
extern void button_plus_cable(void);

// ----------------- Low-level pulse logic -----------------

static inline uint32_t millis(void) {
    return (uint32_t)((rt_tick_get() * 1000) / RT_TICK_PER_SECOND);
}

static uint32_t measureHighPulse(void)
{
    uint32_t duration_us = 0;
    while (rt_pin_read(SBU_PIN) == PIN_HIGH && duration_us < 20000) {
        rt_hw_us_delay(1);
        duration_us++;
    }
    return duration_us;
}

// Returns: 0 or 1 = decoded bit,
//          -2 = spacer/gap (~2.2–3.2 ms) -> caller should retry same bit,
//          -1 = error (timeout/invalid)
static int wait_and_decode_bit(void)
{
    // Wait for rising edge (max 20 ms)
    uint32_t timeout = 20000;
    while (rt_pin_read(SBU_PIN) == PIN_LOW && timeout--) {
        rt_hw_us_delay(1);
    }
    if (timeout == 0) {
//        rt_kprintf("Error: timeout waiting for rising edge\n");
        return -1;
    }

    // Measure HIGH duration (cap ~20 ms)
    uint32_t duration_us = 0;
    while (rt_pin_read(SBU_PIN) == PIN_HIGH && duration_us < 20000) {
        rt_hw_us_delay(1);
        duration_us++;
    }
    if (duration_us == 0) {
//        rt_kprintf("Error: invalid bit duration 0 us\n");
        return -1;
    }

    // Classify pulse
    if (duration_us >= 2200 && duration_us <= 3200) {
//        rt_kprintf("Gap ignored: %u us\n", duration_us);
        return -2; // spacer/gap -> retry same bit
    }
    else if (duration_us >= 1000 && duration_us <= 1700) { /* medium */ return 1; }
    else if (duration_us >= 350  && duration_us <= 800 ) { /* short  */ return 0; }
    else {
//        rt_kprintf("Error: invalid bit duration %u us\n", duration_us);
        return -1;
    }
}


// ----------------- Handshake protocol -----------------

void sendHandshakeSignal(void)
{

//    rt_kprintf("Sending handshake initiation signal\n");

    // 5 ms HIGH -> 2 ms LOW (your current pattern)
    rt_pin_mode(SBU_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(SBU_PIN, PIN_HIGH);  rt_thread_mdelay(5);
    rt_pin_write(SBU_PIN, PIN_LOW);   rt_thread_mdelay(2);    //2

    // LISTEN: use INPUT_PULLUP (not pulldown) + short guard
    rt_pin_mode(SBU_PIN, PIN_MODE_INPUT_PULLUP);
    rt_hw_us_delay(200);

//    rt_kprintf("Handshake signal sent, waiting for response\n");
}
// Measure a single HIGH pulse, returns microseconds (cap prevents blocking)
static uint32_t measure_high_us(uint32_t cap_us)
{
    // wait for HIGH (max ~2 ms)
    uint32_t waited = 0;
    while (rt_pin_read(SBU_PIN) == PIN_LOW && waited < 2000) {
        rt_hw_us_delay(20);
        waited += 20;
    }
    if (rt_pin_read(SBU_PIN) == PIN_LOW) return 0;

    // measure while HIGH
    uint32_t dur = 0;
    while (rt_pin_read(SBU_PIN) == PIN_HIGH && dur < cap_us) {
        rt_hw_us_delay(20);
        dur += 20;
    }
    return dur;
}



static int wait_for_start_ms(void)
{
    uint32_t start = rt_tick_get();

    while ((rt_tick_get() - start) < rt_tick_from_millisecond(1000))
    {
        if (rt_pin_read(SBU_PIN) == PIN_HIGH)
        {
            uint32_t dur = 0;
            while (rt_pin_read(SBU_PIN) == PIN_HIGH)
            {
                rt_hw_us_delay(5);
                dur += 5;
                if (dur > 20000) break;
            }

            if (dur >= 8000 && dur <= 14000)
            {
//                rt_kprintf("receive start: %u us\n", dur);
                return 0;
            }
        }

        rt_hw_us_delay(10);
    }

//    rt_kprintf("Error: start pulse not detected\n");
    return -1;
}
uint8_t receiveResponseByte(void)
{
    // 1) Detect the 10 ms start pulse first
    if (wait_for_start_ms() != 0) {
        return 0xFF;
    }

    uint8_t value = 0;
    rt_tick_t t0 = rt_tick_get();

    // 2) Now read 8 bits using the helper
    for (int i = 0; i < 8; ) {
        int b = wait_and_decode_bit();   // <-- this is the caller usage
        if (b == -2) continue;           // spacer/gap -> retry same bit
        if (b < 0) return 0xFF;          // error -> abort
        value = (uint8_t)((value << 1) | b);  // MSB-first accumulation
        i++;
        rt_hw_us_delay(800);             // inter-bit gap
        if ((rt_tick_get() - t0) > rt_tick_from_millisecond(300)) {
//            rt_kprintf("Error: timeout while decoding byte\n");
            return 0xFF;
        }
    }

//    rt_kprintf("receivedbyte , value = %u\n", value);
    receivedByte = value;
    return receivedByte;
}


void HandShake_setup(void)
{

    rt_thread_mdelay(50);
    btn_flag = false;
//    rt_kprintf("Initializing handshake protocol\n");
    rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);
    handshake_status = HANDSHAKE_IN_PROGRESS;

    if (!rt_pin_read(CABLE_PIN)) {
//        rt_kprintf("Error: Cable not detected\n");
        handshake_status = HANDSHAKE_FAILED;
        button_plus_cable();
        return;
    }
    rt_hw_us_delay(200);
    if(sid==false){
    sendHandshakeSignal();
    }
    // Allow line to settle before bit decoding
//    rt_hw_us_delay(5000); // 2 ms guard time

//    rt_kprintf("receive start\n");
    uint8_t response = receiveResponseByte();
//    rt_kprintf("receive end\n");
    rt_thread_mdelay(2000);
    if (response == 0x57) {
        rt_pin_write(PE6_PIN, PIN_HIGH);
        handshake_status = HANDSHAKE_SUCCESS;
        sls_active=false;
//        rt_kprintf("Handshake OK: 0x57\n");

        sdswitch=true;
//        rt_thread_mdelay(200);
        button_plus_cable();
    }
    else {
//        rt_kprintf("Handshake failed: 0x%02X\n", response);
        handshake_status = HANDSHAKE_FAILED;
        sdswitch=false;
        button_plus_cable();
    }



//    button_plus_cable();
}


//void HandShake_setup(void)
//{
//    btn_flag = false;
//    handshake_status = HANDSHAKE_IN_PROGRESS;
//
//    if (!rt_pin_read(CABLE_PIN))
//    {
//        handshake_status = HANDSHAKE_FAILED;
//        button_plus_cable();
//        return;
//    }
//
//    if (!sid)
//        sendHandshakeSignal();
//
//    // Only microsecond delay for line stabilization
//    rt_hw_us_delay(500);
//
//    uint8_t response = receiveResponseByte();
//
//    if (response == 0x57)
//    {
//        handshake_status = HANDSHAKE_SUCCESS;
//    }
//    else
//    {
//        handshake_status = HANDSHAKE_FAILED;
//    }
//
//    // Now do SD switching
//    button_plus_cable();
//}


uint32_t Insert_cable()
{
    return (receivedByte == 0x57) ? 1 : 0;
}



void button_plus_cable(void)
{
//    rt_kprintf("Inside button_plus_cable\n");

    static uint32_t sls_detection_time = 0;

    // -------------------------------------------------
    // 1. Disable USB bridge FIRST (GL823K in reset)
    // -------------------------------------------------
    rt_pin_write(GL_Soc, PIN_HIGH);     // Reset GL823K
    rt_thread_mdelay(30);              // Allow clean USB disconnect

    // -------------------------------------------------
    // 2. Configure GPIO
    // -------------------------------------------------
    rt_pin_mode(GPIO_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(GPIO_PIN, PIN_LOW);

    // -------------------------------------------------
    // 3. Cable disconnected case
    // -------------------------------------------------
    if (!rt_pin_read(CABLE_PIN))
    {
//        rt_kprintf("Cable disconnected\n");

        sls_active = false;
        cable_BTN_flag = false;
        btn_flag = false;

        // Keep SD in external default
        rt_pin_write(internal_Mosfet, PIN_HIGH);
        rt_pin_write(external_Mosfet, PIN_HIGH);
        rt_pin_write(external_Mosfet, PIN_LOW);
        rt_pin_write(SD1_SD2, PIN_HIGH);

        rt_thread_mdelay(100);

        // Enable USB bridge once
        rt_pin_write(GL_Soc, PIN_LOW);
        rt_thread_mdelay(200);

        return;
    }

    // -------------------------------------------------
    // 4. Decide SD selection based on handshake
    // -------------------------------------------------
    if (handshake_status == HANDSHAKE_SUCCESS)
    {
//        rt_kprintf("SLS detected -> INTERNAL SD\n");

        sls_active = true;
        sls_detection_time = millis();
        rt_pin_write(GPIO_PIN, PIN_HIGH);

        // Switch to INTERNAL SD
        rt_pin_write(internal_Mosfet, PIN_LOW);
        rt_pin_write(external_Mosfet, PIN_HIGH);
        rt_pin_write(SD1_SD2, PIN_LOW);
    }
    else
    {
//        rt_kprintf("Normal cable -> EXTERNAL SD\n");

        sls_active = false;

        // Switch to EXTERNAL SD
        rt_pin_write(internal_Mosfet, PIN_HIGH);
        rt_pin_write(external_Mosfet, PIN_LOW);
        rt_pin_write(SD1_SD2, PIN_HIGH);
    }

    // -------------------------------------------------
    // 5. Settle SD lines before enabling USB bridge
    // -------------------------------------------------
    rt_thread_mdelay(30);

    // -------------------------------------------------
    // 6. Enable USB bridge ONLY ONCE
    // -------------------------------------------------
//    rt_kprintf("Enabling GL823K\n");
    rt_pin_write(GL_Soc, PIN_LOW);      // Release reset
    rt_thread_mdelay(50);              // Allow enumeration stable


//    rt_thread_mdelay(1000);                 // extra
//    rt_kprintf("GLIC start\n");
//    // 1. Force GL reset
//    rt_pin_write(GL_Soc, PIN_HIGH);   // Hold reset
//    rt_thread_mdelay(300);            // 150ms reset hold (IMPORTANT)
//
//    // 2. Switch SD MUX FIRST
//    if (handshake_status == HANDSHAKE_SUCCESS)
//    {
//        // INTERNAL
//        rt_pin_write(internal_Mosfet, PIN_LOW);
////        rt_pin_write(external_Mosfet, PIN_HIGH);
//        rt_pin_write(SD1_SD2, PIN_LOW);
//    }
//    else
//    {
//        // EXTERNAL
////        rt_pin_write(internal_Mosfet, PIN_HIGH);
//        rt_pin_write(external_Mosfet, PIN_LOW);
//        rt_pin_write(SD1_SD2, PIN_HIGH);
//    }
//
//    // 3. Wait for SD power + lines stable
//    rt_thread_mdelay(300);   // IMPORTANT (minimum 150ms)
//
//    // 4. Release GL reset AFTER SD is stable
    rt_pin_write(GL_Soc, PIN_LOW);
    rt_thread_mdelay(300);   // Give time for USB enumeration
//    rt_kprintf("GLIC end\n");



}
static rt_thread_t handshake_thread = RT_NULL;
static rt_mutex_t handshake_mutex = RT_NULL;
static volatile bool handshake_active = false;
void handshake_thread_entry(void* parameter)
{
    uint32_t start_time = rt_tick_get();

    if (rt_mutex_take(handshake_mutex, RT_WAITING_FOREVER) == RT_EOK) {
        HandShake_setup();
        rt_mutex_release(handshake_mutex);
    }
rt_pin_mode(GPIO_PIN,PIN_MODE_OUTPUT);
    // Add timeout protection
    if (handshake_status == HANDSHAKE_IN_PROGRESS) {
        if ((rt_tick_get() - start_time) > HANDSHAKE_TIMEOUT_MS) {
//            rt_kprintf("Handshake timeout\n");
            handshake_status = HANDSHAKE_FAILED;
            button_plus_cable();
        }
    }

    handshake_active = false;
    handshake_thread = RT_NULL;
}
int handshake_init(void)
{
//    rt_kprintf("handshake_init\n");
    handshake_mutex = rt_mutex_create("hs_mtx", RT_IPC_FLAG_FIFO);
    if (handshake_mutex == RT_NULL) {
//        rt_kprintf("Failed to create handshake mutex\n");
        return -1;
    }
    if (handshake_thread == RT_NULL) {
        rt_mutex_delete(handshake_mutex);
//        rt_kprintf("Failed to create handshake thread\n");
        return -1;
    }

    handshake_active = true;
    return 0;
}


int handshake_start(void)
{
    rt_pin_mode(GPIO_PIN, PIN_MODE_OUTPUT);

    if (handshake_mutex == RT_NULL) {
        handshake_mutex = rt_mutex_create("hs_mtx", RT_IPC_FLAG_FIFO);
        if (handshake_mutex == RT_NULL) {
//            rt_kprintf("Failed to create handshake mutex\n");
            return -1;
        }
    }

//    handshake_stop();          // stop any existing
    handshake_terminate = false;
    handshake_active = true;

    // Create the thread and remember its handle
//    handshake_thread = rt_thread_create("handshake",
//                                        HandShake_setup,
//                                        RT_NULL,
//                                        1024,
//                                        5,
//                                        10);
    handshake_thread = rt_thread_create("handshake",
                                        handshake_thread_entry,
                                        RT_NULL,
                                        1024,
                                        3,
                                        10);

    if (handshake_thread == RT_NULL) {
//        rt_kprintf("Failed to create handshake thread\n");
        return -1;
    }

    return rt_thread_startup(handshake_thread);
}


void handshake_stop(void)
{
    if (handshake_thread != RT_NULL) {
//        rt_kprintf("Stopping handshake thread...\n");
        handshake_terminate = true;

        // Force cleanup of all resources
        rt_pin_write(SBU_PIN, PIN_LOW);
        rt_pin_mode(SBU_PIN, PIN_MODE_INPUT);

        // Wait for thread to terminate
        uint32_t start = rt_tick_get();
        while (handshake_active && (rt_tick_get() - start) < 50) {
            rt_thread_mdelay(1);
        }

        if (handshake_active) {
            rt_thread_delete(handshake_thread);
            handshake_active = false;
//            rt_kprintf("Handshake thread force-terminated\n");
        }

        handshake_thread = RT_NULL;
    }
}
void handshake_deinit(void)
{
    if (handshake_thread) {
        rt_thread_delete(handshake_thread);
        handshake_thread = RT_NULL;
    }

    if (handshake_mutex) {
        rt_mutex_delete(handshake_mutex);
        handshake_mutex = RT_NULL;
    }

    handshake_active = false;
}
// Initialize at system startup
INIT_APP_EXPORT(handshake_init);

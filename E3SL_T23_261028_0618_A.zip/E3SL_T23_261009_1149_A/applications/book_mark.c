#include <rtthread.h>
#include <fal.h>
#include <string.h>
#include "book_mark.h"

#define FLASH_MAGIC                  0x55AA55AA
#define SETTINGS_PARTITION_NAME      "param"
static uint8_t g_flash_aligned_buf[256] __attribute__((aligned(4)));
#define FLASH_DATA_OFFSET            0

#define FLASH_DATA_SIZE              sizeof(bookmark_flash_data_t)   // 12 bytes (your actual data)
#define FLASH_WRITE_ALIGNMENT_SIZE   256                              // Flash write requirement
#define FLASH_ERASE_BLOCK_SIZE       4096                             // Flash erase requirement

/* Cached SD content counts — updated once per normal save via bookmark_update_cache().
 * Reused by save_bookmark_direct() so count_items() is never called from the
 * low-battery periodic-save path.  Zero = not yet known (safe: loader re-scans on boot). */
static uint16_t g_cached_total_sections = 0;
static uint16_t g_cached_total_books    = 0;
static uint16_t g_cached_total_chapters = 0;
static uint8_t  g_cached_sdcard         = 0;

void bookmark_update_cache(uint16_t sections, uint16_t books,
                           uint16_t chapters, uint8_t sdcard)
{
    g_cached_total_sections = sections;
    g_cached_total_books    = books;
    g_cached_total_chapters = chapters;
    g_cached_sdcard         = sdcard;
}

/* Lean write: no SD directory scanning, no path building, no char[128] arrays on the stack.
 * Stack cost ~60 bytes total (bookmark_flash_data_t local + a few ints).
 * Safe to call from the low-battery periodic save path. */
int save_bookmark_direct(uint8_t  index,
                         uint8_t  volume,
                         uint16_t section,
                         uint16_t book,
                         uint16_t chapter,
                         uint32_t seektime)
{
    if (index >= NUM_BOOKMARK_SLOTS)
        return -1;

    bookmark_flash_data_t flash_data;

    if (read_flash_data(&flash_data) != 0)
    {
        /* Flash unreadable — init clean rather than aborting */
        memset(&flash_data, 0xFF, sizeof(flash_data));
        flash_data.magic = FLASH_MAGIC;
    }

    bookmark_info_t *bm = &flash_data.bookmarks[index];
    bm->volume         = volume;
    bm->section        = section;
    bm->book           = book;
    bm->chapter        = chapter;
    bm->sdcard         = g_cached_sdcard;
    bm->seektime       = seektime;
    bm->total_sections = g_cached_total_sections;
    bm->total_books    = g_cached_total_books;
    bm->total_chapters = g_cached_total_chapters;

    if (write_flash_data(&flash_data) != 0)
    {
//        rt_kprintf("save_bookmark_direct: write failed\n");
        return -1;
    }

//    rt_kprintf("Bookmark direct-saved slot %d (V=%d S=%d B=%d C=%d seek=%lu)\n",
//               index, volume, section, book, chapter, (unsigned long)seektime);
    return 0;
}

void test_flash_verify(void)
{
    bookmark_flash_data_t test;
//    rt_kprintf("Size of bookmark_flash_data_t = %d bytes\n", FLASH_DATA_SIZE);

    if (read_flash_data(&test) == 0)
    {
//        rt_kprintf("Flash check: magic=0x%08X (expected: 0x%08X)\n", test.magic, FLASH_MAGIC);
        for (int i = 0; i < NUM_BOOKMARK_SLOTS; i++)
        {
//            rt_kprintf("Slot[%d]: V=%d, S=%d, B=%d, C=%d\n",
//                       i,
//                       test.bookmarks[i].volume,
//                       test.bookmarks[i].section,
//                       test.bookmarks[i].book,
//                       test.bookmarks[i].chapter);
        }
    }
    else
    {
//        rt_kprintf("Failed to read flash during test verify.\n");
    }
}
int read_flash_data(bookmark_flash_data_t *flash_data)
{
//    rt_kprintf("read_flash_data called1\n");

    const struct fal_partition *part = fal_partition_find(SETTINGS_PARTITION_NAME);
    if (!part)
    {
//        rt_kprintf("Error: Partition '%s' not found\n", SETTINGS_PARTITION_NAME);
        return -1;
    }

    if (part->len < FLASH_ERASE_BLOCK_SIZE)
    {
//        rt_kprintf("Error: Partition too small\n");
        return -1;
    }

    uint8_t * const aligned_buffer = g_flash_aligned_buf;
    memset(aligned_buffer, 0xFF, FLASH_WRITE_ALIGNMENT_SIZE);  /* fix: was sizeof(ptr)=4 */

    int ret = fal_partition_read(part, FLASH_DATA_OFFSET, aligned_buffer, FLASH_DATA_SIZE);
    if (ret < 0)
    {
//        rt_kprintf("Flash read failed, ret=%d\n", ret);
        return -1;
    }
//    rt_thread_mdelay(20);

    memcpy(flash_data, aligned_buffer, FLASH_DATA_SIZE);

    // AFTER:
        if (flash_data->magic != FLASH_MAGIC)
        {
//            rt_kprintf("Flash data invalid or not initialized. Initializing...\n");

            memset(flash_data, 0xFF, FLASH_DATA_SIZE);
            flash_data->magic = FLASH_MAGIC;

            memset(aligned_buffer, 0xFF, FLASH_WRITE_ALIGNMENT_SIZE);
            memcpy(aligned_buffer, flash_data, FLASH_DATA_SIZE);

            /* Same XIP hazard as write_flash_data: both erase and write make the
             * SPI flash chip busy and unable to serve instruction fetches.
             * rt_enter_critical() prevents any thread from being scheduled during
             * the erase+write window (~25 ms total). */
            rt_enter_critical();
            ret = fal_partition_erase(part, FLASH_DATA_OFFSET, FLASH_ERASE_BLOCK_SIZE);
            if (ret < 0)
            {
                rt_exit_critical();
//                rt_kprintf("Flash erase failed during init, ret=%d\n", ret);
                return -1;
            }

            ret = fal_partition_write(part, FLASH_DATA_OFFSET, aligned_buffer, FLASH_WRITE_ALIGNMENT_SIZE);
            rt_exit_critical();
            if (ret < 0)
            {
//                rt_kprintf("Flash write failed during init, ret=%d\n", ret);
                return -1;
            }

//            rt_kprintf("Flash initialized with default bookmark data.\n");
        }

    return 0;
}

int write_flash_data(const bookmark_flash_data_t *flash_data)
{
    const struct fal_partition *part = fal_partition_find(SETTINGS_PARTITION_NAME);
    if (!part)
    {
//        rt_kprintf("Error: Partition '%s' not found\n", SETTINGS_PARTITION_NAME);
        return -1;
    }

    uint8_t * const aligned_buffer = g_flash_aligned_buf;
    memset(aligned_buffer, 0xFF, FLASH_WRITE_ALIGNMENT_SIZE);  /* fix: was sizeof(ptr)=4 */
    memcpy(aligned_buffer, flash_data, FLASH_DATA_SIZE);

    /* Disable the scheduler for the erase+write window.
     * The AB32VG1 SPI flash is shared between XIP (code execution) and FAL
     * data storage.  During fal_partition_erase() (~20 ms) the flash chip
     * cannot serve instruction fetches, so any thread that wakes up and tries
     * to run from flash (e.g. led_task) will fault with ERR: c0000002.
     * rt_enter_critical() prevents context switches for this short window.
     * Note: in RT-Thread 4.0.x both functions are void — no saved-level arg. */
    rt_enter_critical();

    int ret = fal_partition_erase(part, FLASH_DATA_OFFSET, FLASH_ERASE_BLOCK_SIZE);
    if (ret < 0)
    {
        rt_exit_critical();
//        rt_kprintf("Flash erase failed, ret=%d\n", ret);
        return -1;
    }

    ret = fal_partition_write(part, FLASH_DATA_OFFSET, aligned_buffer, FLASH_WRITE_ALIGNMENT_SIZE);
    rt_exit_critical();

    if (ret < 0)
    {
//        rt_kprintf("Flash write failed, ret=%d\n", ret);
        return -1;
    }

    return 0;
}


int save_bookmark_state(const bookmark_info_t *info, uint8_t index)
{
    if (index >= NUM_BOOKMARK_SLOTS)
        return -1;

    bookmark_flash_data_t flash_data;

    if (read_flash_data(&flash_data) != 0)
    {
//        rt_kprintf("read_flash_data failed, initializing default\n");
        memset(&flash_data, 0xFF, sizeof(flash_data));
        flash_data.magic = FLASH_MAGIC;
    }

    flash_data.bookmarks[index] = *info;

    if (write_flash_data(&flash_data) != 0)
    {
//        rt_kprintf("write_flash_data failed\n");
        return -1;
    }

//    rt_kprintf("Bookmark saved for slot %d\n", index);
    return 0;
}

int load_bookmark_state(bookmark_info_t *info, uint8_t index)
{
    if (index >= NUM_BOOKMARK_SLOTS)
        return -1;

    bookmark_flash_data_t flash_data;

    if (read_flash_data(&flash_data) != 0)
    {
//        rt_kprintf("read_flash_data failed\n");
        return -1;
    }

    *info = flash_data.bookmarks[index];

//    rt_kprintf("Loaded from flash: V=%d, S=%d, B=%d, C=%d\n",
//               info->volume, info->section, info->book, info->chapter);

    return 0;
}

int clear_bookmark_flash(void)
{
    const struct fal_partition *part = fal_partition_find(SETTINGS_PARTITION_NAME);
    if (!part)
    {
//        rt_kprintf("Error: Partition '%s' not found\n", SETTINGS_PARTITION_NAME);
        return -1;
    }

    int ret = fal_partition_erase(part, FLASH_DATA_OFFSET, FLASH_ERASE_BLOCK_SIZE);
    if (ret < 0)
    {
//        rt_kprintf("Flash erase failed, ret=%d\n", ret);
        return -1;
    }

//    rt_kprintf("Bookmark flash cleared.\n");
    return 0;
}

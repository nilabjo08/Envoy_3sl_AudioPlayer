# Comprehensive System Documentation

## System Overview

This project implements a feature-rich MP3 player using RT-Thread RTOS with complete implementations of:
- Keypad and button input handling
- SD card storage management
- Audio playback control with MP3 support
- Cable detection and SLS handshake protocol
- Audio system switching (Earphone + Speaker)
- Power management with sleep/wake functionality
- Bookmarking system for playback position
- LED status indicators

## Hardware Architecture

### Input Devices
- **3x3 Matrix Keypad**
  - Rows: PA.0, PA.1, PA.2
  - Columns: PA.3, PA.4, PF.1
  - Supports both short press and long press (2s hold)
  - Full debounce implementation (25ms)

- **Dedicated Play/Power Button**
  - Pin: PB.3
  - Functions:
    * Single click: Play/Pause toggle
    * Long press: Power control (enter sleep mode)
  - Independent debounce handling

- **Cable Detection System**
  - Detection pin: PF.0
  - SBU line: PE.0 (for handshake)
  - GPIO control: PA.5 (for SD card switching)
  - Implements 50ms debouncing
  - Full state machine implementation

### Output Devices
- **Audio System**
  - DAC-based beep generation (sound0 device)
  - Supports:
    * Single beep (standard feedback)
    * Double beep (min/max volume indication)
    * Triple beep (special notifications)
  - Volume-scaled amplitude
  - MP3 playback via dedicated driver
  - Audio switch control: PB.4

- **LED Indicators**
  - Red LED: PE.4
  - Green LED: PE.1

## Core Software Components

### 1. File System Management (`play_mode.c`, `book_mark.c`)
**SD Card Interface:**
- Automatic mounting/unmounting
- Supports FAT32 filesystem
- Filesystem scanning with dynamic memory allocation
- Automatic recovery mechanisms

**File Navigation:**
- Hierarchical structure:
  * Sections → Books → Chapters
- Natural sorting (numeric-aware)
- Dynamic arrays for file lists
- Boundary checking at all levels
- Automatic wrap-around

**Bookmark System:**
- Saves/loads playback position to flash
- Tracks:
  * Volume level
  * Section index
  * Book index
  * Chapter index
- Uses FAL (Flash Abstraction Layer) for reliable storage
- 2 bookmark slots available

### 2. Audio Playback System (`play_mode.c`, `dac_beep.c`, `mp3_player`)
**MP3 Playback:**
- Full MP3 decoder integration
- Playback state management:
  * PLAYING
  * PAUSED
  * STOPPED
- Time position tracking
- Volume control (1-100 in steps of 7)

**Playback Controls:**
- Play/Pause toggle
- 20-second seek forward/backward
- Chapter navigation:
  * Next/Previous chapter
  * Book-level navigation
  * Section-level navigation
- Automatic chapter advancement

**Audio Feedback:**
- Volume-scaled beeps
- Configurable:
  * Frequency (1kHz)
  * Duration (250ms)
  * Waveform (sine)
- Priority handling over MP3 playback

### 3. User Input Handling (`play_mode.c`)
**Keypad Matrix:**
- Complete debounce implementation
- Supports:
  * Short press: Immediate action
  * Long press: Continuous action
- Button functions:
  * Navigation (sections/books/chapters)
  * Volume control
  * Playback control
- Event-based callback system

**Play/Power Button:**
- Independent handling
- State machine implementation
- Distinct actions for:
  * Single click
  * Long press

### 4. Cable Detection & SLS (`handshake_protocol.c`, `cable.c`)
**Handshake Protocol:**
- Complete state machine:
  * IDLE
  * CABLE_INSERTED
  * HANDSHAKE_ACTIVE
- 5ms initiation signal
- 8-bit response parsing
- Timeout handling
- Error recovery

**SLS Implementation:**
- Automatic pause on cable insertion
- Handshake verification
- GPIO control based on status
- Automatic resume on cable removal
- 2-second window for button press
- Full cleanup on removal

### 5. Power Management (`play_mode.c`)
**Sleep/Wake Functionality:**
- Enter sleep mode on long press
- Wake on button press
- Proper resource cleanup before sleep
- State restoration after wake
- Uses PM (Power Management) subsystem

### 6. Thread Architecture

**Priority Levels:**
1. Beep Control Thread (Priority 12)
2. Keypad Scanning Thread (Priority 11)
3. Handshake Thread (Priority 8)
4. Cable Detection Thread (Priority 7)
5. LED Control Thread (Priority 5)

**Thread Details:**

1. **beep_ctrl** (Priority 12)
   - Handles audio feedback generation
   - Manages priority over MP3 playback
   - Controls waveform generation

2. **keypad** (Priority 11)
   - Matrix scanning
   - Debounce handling
   - Event generation
   - Earphone detection
   - State management

3. **handshake** (Priority 8)
   - Handshake protocol management
   - Timeout handling
   - Response parsing

4. **cable_thread** (Priority 7)
   - Continuous cable monitoring
   - State machine implementation
   - Debounce handling

5. **led_ctrl** (Priority 5)
   - Status indication
   - Blink patterns
   - Color control

### 7. Synchronization Primitives

**Mutexes:**
1. `scan_mutex` - Protects file system scanning operations
2. `audio_state_mutex` - Protects audio routing state
3. `pause_mutex` - Protects pause mode state
4. `beep_mutex` - Protects beep generation
5. `handshake_mutex` - Protects handshake operations
6. `state_mutex` - Protects cable detection state

**Semaphores:**
1. `beep_sem` - Signals beep playback request
2. `cable_sem` - Signals cable state changes

### 8. Dynamic Memory Management

**Dynamic Arrays:**
- Used for file system navigation
- Three arrays maintained:
  1. `sections` - Top-level directories
  2. `books` - Second-level directories
  3. `chapters` - MP3 files
- Initial allocation: 20 items
- Grows exponentially when needed
- Proper cleanup on sleep/deinit

### 9. Initialization Sequence

1. **Hardware initialization:**
   - GPIO pins
   - Audio system
   - SD card interface

2. **Subsystem initialization:**
   - Cable detection
   - Handshake protocol
   - Audio feedback
   - Keypad scanning
   - Pause mode
   - File system

3. **Resource allocation:**
   - Dynamic arrays
   - Mutexes
   - Thread creation

## Key Data Structures

1. **app_state_t** - Tracks:
   - Playback position
   - Volume state
   - Timing information
   - Pause state

2. **dynamic_array_t** - Manages:
   - File lists (sections/books/chapters)
   - Dynamic memory allocation
   - Sorting functionality

3. **key_button** - Handles:
   - Button state
   - Timing information
   - Press detection

4. **audio_state_t** - Manages:
   - Earphone state
   - Pause mode
   - Speaker control

5. **bookmark_flash_data_t** - Stores:
   - Playback position
   - Volume level
   - Section/book/chapter indices

## Critical Code Paths

1. **Playback Initialization:**
   - `play_current()` → `scan_directory()` → `mp3_player_play()`

2. **Cable Detection:**
   - `cable_isr()` → `handle_cable_event()` → `handshake_start()`

3. **Handshake Protocol:**
   - `sendHandshakeSignal()` → `receiveResponseByte()` → `button_plus_cable()`

4. **Sleep/Wake Cycle:**
   - Long press → `prepareSleepMode()` → Sleep → Wake → `exitSleepMode()`

## Error Handling

1. **File System Errors:**
   - Automatic remount on failure
   - Combination key (1+7) for manual recovery

2. **Handshake Failures:**
   - Timeout detection
   - Automatic retry
   - Clean state reset

3. **Memory Allocation:**
   - Proper cleanup on failure
   - Null checks before access

4. **Thread Safety:**
   - Mutex protection for shared resources
   - Timeout on mutex acquisition

## Development Notes

### Debugging Facilities
- Extensive debug prints via `rt_kprintf()`
- Hardware state changes logged
- File system operations traced
- Playback status monitored
- Button events logged
- Cable detection states tracked

### Testing Considerations
1. **File System:**
   - Test with various directory structures
   - Verify natural sorting behavior
   - Test boundary conditions

2. **Audio Playback:**
   - Verify all control functions
   - Test volume limits
   - Verify automatic advancement

3. **Cable Detection:**
   - Test insertion/removal sequences
   - Verify handshake timeout
   - Test button press window

4. **Power Management:**
   - Verify proper sleep entry
   - Test wake functionality
   - Verify state restoration

## Usage Instructions

### Normal Operation:
1. Insert SD card with properly organized content
2. System automatically mounts filesystem
3. Use keypad to navigate and play files
4. Dedicated button for play/pause control

### Special Functions:
1. **Volume Limits:**
   - Double beep indicates min/max volume
   - Automatic clamping

2. **Chapter Restart:**
   - Press previous chapter within 5s of start

3. **SD Card Recovery:**
   - Use 1+7 combination to remount

4. **Cable Mode:**
   - Automatic pause on insertion
   - Button press within 2s for special function
   - Automatic resume on removal

## Maintenance Considerations

1. **Memory Management:**
   - All dynamic allocations properly freed
   - Array growth handled gracefully
   - Cleanup functions available

2. **Thread Safety:**
   - Shared resources protected
   - Proper locking order maintained
   - Deadlock prevention measures

3. **Error Recovery:**
   - Graceful degradation
   - Automatic retry where appropriate
   - Clear error indications
   
   
   -----------------------------------------------------------------------------------------------------------
   
   # **In-Depth Developer Documentation for MP3 Player System**

## **1. System Overview**
This project is an **RT-Thread RTOS**-based **MP3 Player** with the following key functionalities:
- **File System Navigation** (Sections → Books → Chapters)
- **Audio Playback** (MP3 decoding, volume control, seek)
- **Keypad Input Handling** (Matrix scanning, debounce, long-press detection)
- **Cable Detection & SLS Handshake** (USB-C cable insertion/removal, Secure Listening Session)
- **Power Management** (Sleep/Wake, low-power mode)
- **Audio Routing** (Speaker/Earphone switching)
- **LED Feedback** (Status indication)
- **Bookmarking** (Save/load playback position in flash)

---

## **2. File-by-File Functional Breakdown**

### **2.1 `handshake_protocol.c`**
**Purpose**: Implements the **SLS (Secure Listening Session) handshake** protocol for cable detection.

#### **Key Functions:**
1. **`HandShake_setup()`**  
   - Initializes the handshake process.
   - Verifies cable connection.
   - Sends handshake signal and waits for response.

2. **`sendHandshakeSignal()`**  
   - Sends a **5ms HIGH pulse** followed by a **5ms LOW pulse** on `SBU_PIN` (PE.0).
   - Switches `SBU_PIN` to input mode to receive response.

3. **`receiveResponseByte()`**  
   - Waits for a **10ms HIGH start signal**.
   - Reads **8-bit response** (each bit represented by pulse width):
     - `1` = **5ms HIGH**
     - `0` = **2ms HIGH**
   - Returns `0x57` on success (`0xFF` on failure).

4. **`measureHighPulse()`**  
   - Measures the duration of a HIGH pulse on `SBU_PIN`.

5. **`button_plus_cable()`**  
   - Manages **GPIO_PIN (PA.5)** based on handshake status:
     - **Cable disconnected**: Forces `GPIO_PIN` LOW.
     - **Valid SLS detected**: Sets `GPIO_PIN` HIGH.
     - **Button press within 2s**: Triggers special action (if `cable_BTN_flag` is set).

6. **Thread Management Functions**  
   - `handshake_init()`: Creates handshake thread & mutex.
   - `handshake_start()`: Starts handshake thread.
   - `handshake_stop()`: Terminates handshake thread.

---

### **2.2 `cable.c`**
**Purpose**: Manages **cable detection** and **state transitions**.

#### **Key Functions:**
1. **`cable_isr()`**  
   - **Interrupt handler** for cable insertion/removal.
   - Releases `cable_sem` to trigger `cable_thread_entry`.

2. **`handle_cable_event()`**  
   - **State machine** for cable events:
     - **Cable inserted**:  
       - Pauses playback (`pause_mode_activate()`).
       - Starts handshake (`handshake_start()`).
     - **Cable removed**:  
       - Resumes playback (`pause_mode_deactivate()`).
       - Cleans up handshake (`force_handshake_cleanup()`).

3. **`cable_thread_entry()`**  
   - Monitors `cable_sem` for events.
   - Debounces cable state changes (50ms).
   - Reconfigures interrupt edge (rising/falling).

4. **`cable_detect_init()`**  
   - Initializes:
     - `state_mutex` (protects `current_state`).
     - `cable_sem` (signals cable events).
     - `handshake_init()`.

---

### **2.3 `play_mode.c`**
**Purpose**: Manages **file navigation, playback control, and keypad input**.

#### **Key Functions:**
1. **File System Navigation**  
   - `scan_directory()`: Scans SD card for files.
   - `scan_sections()`, `scan_books()`, `scan_chapters()`: Populate dynamic arrays.
   - `play_current()`: Plays the current chapter (MP3 file).

2. **Playback Control**  
   - `fast_forward()` / `fast_rewind()`: Seeks ±20 seconds.
   - `next_chapter()` / `prev_chapter()`: Navigates chapters.
   - `next_book()` / `prev_book()`: Navigates books.
   - `next_section()` / `prev_section()`: Navigates sections.
   - `button_play_pause()`: Toggles play/pause.

3. **Keypad Handling**  
   - `keypad_scan_thread_entry()`:  
     - Scans matrix keypad.
     - Detects **short press** (immediate action) and **long press** (continuous action).
     - Handles **button combinations** (e.g., **1+7** = remount SD card).
   - `button_callback()`: Processes key events.

4. **Power Management**  
   - `prepareSleepMode()`:  
     - Stops playback.
     - Releases mutexes.
     - Frees dynamic memory.
   - `exitSleepMode()`:  
     - Reinitializes mutexes.
     - Rescans filesystem.
     - Restores playback.

5. **Bookmarking**  
   - `save_current_bookmark()`: Saves state to flash.
   - `load_last_bookmark()`: Restores state from flash.

---

### **2.4 `dac_beep.c`**
**Purpose**: Generates **audio feedback** (beeps) using DAC.

#### **Key Functions:**
1. **`update_sine_table()`**  
   - Generates a **1kHz sine wave** scaled by `current_volume`.

2. **`beep_control_thread()`**  
   - Plays beeps when `beep_sem` is released.
   - Pauses MP3 playback during beep.

3. **Beep Playback Functions**  
   - `play_beep()`: Single beep (250ms).
   - `play_double_beep()`: Two beeps (min/max volume).
   - `play_triple_beep()`: Three beeps (special notification).

4. **Initialization**  
   - `beeper_init()`:  
     - Creates `beep_sem` and `beep_mutex`.
     - Configures audio device (`sound0`).

---

### **2.5 `book_mark.c`**
**Purpose**: Saves/loads **playback state** to/from flash.

#### **Key Functions:**
1. **`save_bookmark_state()`**  
   - Saves `bookmark_info_t` (volume, section, book, chapter) to flash.

2. **`load_bookmark_state()`**  
   - Restores state from flash.

3. **Flash Access**  
   - `read_flash_data()`: Reads `bookmark_flash_data_t` from flash.
   - `write_flash_data()`: Writes to flash (with erase-before-write).

---

### **2.6 `pause_mode.c`**
**Purpose**: Manages **pause mode** (used for cable detection).

#### **Key Functions:**
1. **`pause_mode_activate()`**  
   - Pauses playback (`mp3_player_pause()`).
   - Sets `current_state = PAUSE_MODE_ACTIVE`.

2. **`pause_mode_deactivate()`**  
   - Resumes playback (`mp3_player_resume()`).
   - Sets `current_state = PAUSE_MODE_INACTIVE`.

3. **Mutex Protection**  
   - `pause_mode_lock()` / `pause_mode_unlock()`: Protects `current_state`.

---

### **2.7 `led.c`**
**Purpose**: Controls **LED status indicators**.

#### **Key Functions:**
1. **LED Control**  
   - `Green_led_PAUSE()`: Blinking pattern (100ms ON/OFF).
   - `Red_led_HIGH()` / `Green_led_HIGH()`: Turns LED ON.
   - `Red_led_LOW()` / `Green_led_LOW()`: Turns LED OFF.

2. **Thread Management**  
   - `worker_thread_entry()`:  
     - Runs LED patterns based on events (`START_EVENT`/`STOP_EVENT`).

---

## **3. Thread Priorities & Scheduling**
| Thread Name          | Priority | Description |
|----------------------|----------|-------------|
| `beep_ctrl`          | 12       | Audio feedback (highest priority). |
| `keypad`             | 11       | Keypad scanning & input handling. |
| `handshake`          | 8        | SLS handshake protocol. |
| `cable_thread`       | 7        | Cable detection. |
| `led_ctrl`           | 5        | LED status updates. |

---

## **4. Mutex & Semaphore Usage**
| Resource             | Type      | Protected Data |
|----------------------|-----------|----------------|
| `scan_mutex`         | Mutex     | File system scanning. |
| `audio_state_mutex`  | Mutex     | Speaker/earphone state. |
| `pause_mutex`        | Mutex     | Pause mode state. |
| `beep_mutex`         | Mutex     | Beep playback control. |
| `state_mutex`        | Mutex     | Cable detection state. |
| `beep_sem`           | Semaphore | Signals beep request. |
| `cable_sem`          | Semaphore | Signals cable events. |

---

## **5. Dynamic Memory Management**
- **`dynamic_array_t`** (used in `play_mode.c`):
  - `items`: Array of strings (file/directory names).
  - `count`: Number of items.
  - `capacity`: Allocated size.
- **Functions**:
  - `dynamic_array_init()`: Allocates initial memory.
  - `dynamic_array_add()`: Expands array if full.
  - `dynamic_array_free()`: Releases memory.

---

## **6. Critical Code Paths**
1. **Playback Initialization**  
   `play_current()` → `scan_directory()` → `mp3_player_play()`

2. **Cable Detection**  
   `cable_isr()` → `handle_cable_event()` → `handshake_start()`

3. **Sleep/Wake Cycle**  
   Long press → `prepareSleepMode()` → Sleep → Wake → `exitSleepMode()`

---

## **7. Error Handling & Recovery**
- **SD Card Errors**:  
  - Auto-remount on failure (`toggle_sd_card_mount()`).
- **Handshake Failures**:  
  - Timeout detection (`RESPONSE_TIMEOUT`).
  - Automatic retry.
- **Memory Allocation**:  
  - Checks for `RT_NULL` returns.
  - Cleanup on failure.

---

## **8. Developer Notes**
### **Testing Considerations**
- **File System**:  
  - Test with deeply nested directories.
  - Verify natural sorting (`1, 2, 10` instead of `1, 10, 2`).
- **Audio Playback**:  
  - Test seek accuracy (±20s).
  - Verify volume clamping (1-100).
- **Cable Detection**:  
  - Test insertion/removal under 50ms debounce.
  - Verify handshake timeout (200ms).

### **Debugging Tips**
- Use `rt_kprintf()` for:
  - Keypad events (`PRESS_DOWN`, `LONG_PRESS_HOLD`).
  - Cable state changes (`CABLE_INSERTED`/`REMOVED`).
  - Handshake status (`HANDSHAKE_SUCCESS`/`FAILED`).

---

## **Conclusion**
This documentation provides a **deep dive** into each module, thread, and synchronization mechanism. Developers should:
1. **Follow mutex locking order** to avoid deadlocks.
2. **Test edge cases** (SD card removal during playback).
3. **Monitor RT-Thread logs** for runtime issues.



#include <dac_beep.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <rtconfig.h>
#include <drivers/pin.h>
#include <unistd.h>
#include <sys/_stdint.h>
#include <rtdef.h>
#include <ctype.h>
#include "handshake_protocol.h"
#include <mp3_player.h>
#include <dfs_posix.h>
#include "multi_button.h"
#include <stdbool.h>
#include"play_mode.h"
#include "cable.h"
//#include <dfs_posix.h>
#include <Gpio_Pins_Defines.h>
//#include <math.h>
#include "led.h"
#include "board.h"
#include "book_mark.h"
#include <drivers/pm.h>
#include <fal.h>
#include "timer1.h"
#include "drv_sdio.h"
#include "notify_clip.h"

volatile int Playoffcharge = 0;
#define KEY_COUNT 9
#define DEBOUNCE_DELAY_MS 25
#define LONG_PRESS_TIME_MS 1000
#define FAST_NAV_DELAY_MS 500
#define FAST_CHAPTER_DELAY_MS 100
#define CHAPTER_REWIND_THRESHOLD 5  // 5 seconds threshold for chapter rewind
#define HOLD_SEEK_STEP_SEC     10
#define HOLD_SEEK_INTERVAL_MS  400
#define ROOT_PATH "/"


volatile SLScombinations hk={0};
volatile bool suppress_playback = false;
volatile bool sd_switch_in_progress = false;
static bool play_pending = false;
volatile bool hold_browse_active = false;
static bool hold_boundary_played = false;
volatile bool firston=false;
volatile bool cableplay=false;
volatile bool sid=false;
volatile char sd_det_flag;
volatile bool poweroffflag=false;
/* Deferred bookmark save flag: set by button_play_pause() when pausing,
 * consumed by the keypad thread main loop where flash writes are safe. */
volatile bool bookmark_save_pending = false;
extern volatile bool battery_shutdown_request;
extern volatile bool low_battery_bookmark_mode;
extern struct mp3_player player;   /* from mp3_player.c */

uint32_t mp3_get_cur_seconds(void);
static void EXT_det_callback(void *args);
void save_current_bookmark(sd_slot_t target);


#define MAX_VOLUME        100
#define MIN_VOLUME         1
#define VOLUME_STEP        7
#define VOLUME_STEP_HOLD   14
#define VOL_HOLD_INTERVAL_MS  265
#define NAV_HOLD_INTERVAL_MS  500

static const char* row_pin_names[3] = { "PA.0", "PA.1", "PA.2" };
static const char* col_pin_names[3] = { "PA.3", "PA.4", "PF.1" };


#define  PE6_PIN rt_pin_get("PE.6")

static bool long_press_active = false;
static bool reached_limit = false;
static bool ff_rw_hold_active = false;
static int hold_seek_dir = 0;                 // +1 forward, -1 rewind
static int pending_seek_sec = 0;
static rt_tick_t last_hold_seek_tick = 0;
static bool hold_seek_wait_release = false;

static rt_uint8_t chapter_hold_prev_volume = 0;
static bool chapter_hold_muted = false;
extern rt_uint8_t current_volume;
uint16_t led;
struct key_button
{
    struct button btn;
    int index;
    int col_pin;
    int row_pin;
    rt_tick_t last_press;
    rt_tick_t hold_start_time;
    rt_tick_t last_jump_time;
    bool long_press_active;
};



// Earphone_port
typedef struct {
    bool earphone_inserted;
    bool pause_mode;
} audio_state_t;

rt_thread_t thread = RT_NULL;



bookmark_info_t bookmark_info;
bookmark_info_t bookmark_info2;
static volatile int autoplay_enabled = 0;
static uint32_t btn_event_val;
volatile bool block_autoplay = false;
volatile bool pause_mode_active = false;
static char  resetonce=0;
volatile uint32_t songseek=0;
static char led_correct_order=0;


// Initialize with default values

 volatile app_state_t state = { .chapter_index = 0, .book_index = 0, .section_index = 0,
        .last_button_press_time = 0, .button_pressed = false, .chapter_start_time = 0, .is_paused = false };

static struct key_button keys[KEY_COUNT];
static rt_mutex_t scan_mutex = RT_NULL;
/* ===========================================================================
 * Zero-RAM directory traversal  —  3-level per-slot cache edition
 * ---------------------------------------------------------------------------
 * RAM: ~1800 bytes of .bss.  dir_scratch[1000][64] is gone (saved 68 KB).
 *
 * The SD card hierarchy has exactly 3 levels:
 *   Slot 0  "/"                      — sections   (only_dirs=1)
 *   Slot 1  "/Section_XXXX"          — books       (only_dirs=1)
 *   Slot 2  "/Section_XXXX/Book_YYY" — chapters    (only_dirs=0)
 *
 * Slot is chosen by counting non-empty path segments (path_slot()).
 * Each slot keeps its own current-entry + last-entry + count cache.
 * All three levels stay warm simultaneously, so a repeated play_current()
 * call for the same position costs ZERO SD card reads.
 *
 * PASSES PER NAVIGATION ACTION (after first visit):
 *   play_current() same position : 0 passes  (all 3 slots cached)
 *   next / prev chapter          : 1 pass
 *   next / prev book             : 2 passes
 *   next / prev section          : 3 passes
 *   Jump to last entry           : 0 passes  (last-entry cache)
 *   Bookmark restore (cold)      : up to total/2 passes per level
 * ===========================================================================*/

#define DIR_NAME_LEN   64
#define DIR_SLOT_COUNT  3    /* root, section, book — one slot each */

/* ---------- case-insensitive .mp3 / .MP3 / .Mp3 extension check ---------- */
static int has_mp3_ext(const char *name)
{
    size_t len = strlen(name);
    if (len < 4) return 0;
    const char *e = name + len - 4;
    return (e[0] == '.' &&
            (e[1] == 'm' || e[1] == 'M') &&
            (e[2] == 'p' || e[2] == 'P') &&
            e[3] == '3');
}

/* ---------- choose cache slot by hierarchy depth ----------
 * Counts non-empty path segments:
 *   "/"                -> 0 segments -> slot 0  (root / sections)
 *   "/Section_0001"    -> 1 segment  -> slot 1  (books)
 *   "/Section/Book"    -> 2 segments -> slot 2  (chapters)       */
static int path_slot(const char *path)
{
    int n = 0;
    const char *p = path;
    while (*p)
    {
        if (*p == '/' && *(p + 1) != '/' && *(p + 1) != '\0')
            n++;
        p++;
    }
    return (n < DIR_SLOT_COUNT) ? n : DIR_SLOT_COUNT - 1;
}

/* ---------- direct string natural comparator ---------- */
static int natural_cmp(const char *s1, const char *s2)
{
    while (*s1 && *s2)
    {
        if (isdigit((unsigned char)*s1) && isdigit((unsigned char)*s2))
        {
            char *e1, *e2;
            long n1 = strtol(s1, &e1, 10);
            long n2 = strtol(s2, &e2, 10);
            if (n1 != n2) return (n1 > n2) ? 1 : -1;
            int l1 = (int)(e1 - s1), l2 = (int)(e2 - s2);
            if (l1 != l2) return l1 - l2;
            s1 = e1; s2 = e2;
        }
        else
        {
            int d = (unsigned char)*s1 - (unsigned char)*s2;
            if (d) return d;
            s1++; s2++;
        }
    }
    return (unsigned char)*s1 - (unsigned char)*s2;
}

/* ---------- one readdir pass ----------
 * find_min=1: smallest entry strictly > pivot (forward)
 * find_min=0: largest  entry strictly < pivot (backward)
 * Empty pivot = no bound (absolute min or max).                 */
static int dir_one_pass(const char *path, const char *pivot,
                        int find_min, int only_dirs, char *out_name)
{
    DIR *dir = opendir(path);
    if (!dir) return -1;

    char winner[DIR_NAME_LEN];
    winner[0] = '\0';

    struct dirent *ent;
    while ((ent = readdir(dir)))
    {
        if (strcmp(ent->d_name, ".")   == 0 ||
            strcmp(ent->d_name, "..")  == 0 ||
            strcmp(ent->d_name, "System Volume Information") == 0)
            continue;
        if ( only_dirs && ent->d_type != DT_DIR) continue;
        if (!only_dirs && ent->d_type != DT_REG) continue;
        if (!only_dirs && !has_mp3_ext(ent->d_name)) continue;

        const char *n = ent->d_name;
        if (find_min)
        {
            if (pivot[0] != '\0' && natural_cmp(n, pivot) <= 0) continue;
            if (winner[0] == '\0' || natural_cmp(n, winner) < 0)
            { rt_strncpy(winner, n, DIR_NAME_LEN-1); winner[DIR_NAME_LEN-1] = '\0'; }
        }
        else
        {
            if (pivot[0] != '\0' && natural_cmp(n, pivot) >= 0) continue;
            if (winner[0] == '\0' || natural_cmp(n, winner) > 0)
            { rt_strncpy(winner, n, DIR_NAME_LEN-1); winner[DIR_NAME_LEN-1] = '\0'; }
        }
    }
    closedir(dir);

    if (winner[0] == '\0') return -1;
    rt_strncpy(out_name, winner, DIR_NAME_LEN-1);
    out_name[DIR_NAME_LEN-1] = '\0';
    return 0;
}

/* ==========================================================================
 * Per-slot cache: one entry per hierarchy level (root / section / book).
 * Each slot stores:
 *   cur  — the current (most recently returned) entry + its index
 *   last — the absolute last (maximum) entry + total count
 *   cnt  — the total entry count (same as last.total when populated)
 *
 * Total size: 3 slots x (path128 + cur64 + last64 + 4+4+4 + flags) ~ 620 bytes
 * ========================================================================== */
/* ---------- DJB2 path hash — 4 bytes instead of 128 ----------
 * Replaces storing the full path string in each cache slot.
 * Saves 3 x 124 = 372 bytes of .bss, fixing the linker overflow.
 * Collision probability is 1/2^32 per lookup — negligible.
 * Worst case on collision: cache miss (one extra readdir pass), not corruption. */
static unsigned int path_hash(const char *p)
{
    unsigned int h = 5381u;
    while (*p)
        h = h * 33u ^ (unsigned char)*p++;
    return h;
}

typedef struct {
    unsigned int path_h;        /* DJB2 hash of the directory path (4 bytes) */
    char cur_name[DIR_NAME_LEN];
    int  cur_index;

    char last_name[DIR_NAME_LEN];
    int  last_total;            /* -1 = unknown */

    int  cnt;                   /* cached count_items result, -1 = unknown */

    char sd_slot;
    char only_dirs;
    char valid;                 /* 1 = this slot has been populated */
} dir_slot_t;
/* dir_slot_t size: 4+64+4+64+4+4+1+1+1+1(pad) = 148 bytes
 * g_slots[3]     = 444 bytes  (vs 816 with path[128] — saves 372 bytes) */

static dir_slot_t g_slots[DIR_SLOT_COUNT];

/* --------------------------------------------------------------------------
 * Fast root-section lookup
 * --------------------------------------------------------------------------
 * The SD content uses numbered folders such as Section_0000, Section_0001,
 * ... (or a one-based sequence starting at Section_0001). After every SD
 * remount the normal directory cache is cold. The generic natural-order
 * lookup below finds an arbitrary index by repeatedly scanning the complete
 * root directory; restoring Section_0050 can therefore require about 50 full
 * root scans and produces the observed 3-5 second switching delay.
 *
 * For the root section level only, detect whether numbering starts at 0 or 1
 * and open the expected Section_XXXX directory directly. Nonstandard folder
 * layouts still fall back to the existing natural-order code unchanged.
 */
#define SECTION_BASE_UNKNOWN      (-1)
#define SECTION_BASE_UNSUPPORTED  (-2)
static signed char g_section_number_base[2] = {
    SECTION_BASE_UNKNOWN, SECTION_BASE_UNKNOWN
};

static int section_dir_exists_and_copy(int number, char *out_name)
{
    char name[DIR_NAME_LEN];
    char full_path[DIR_NAME_LEN + 2];
    DIR *dir;

    if (number < 0)
        return -1;

    /* Normal project naming: Section_0000 ... Section_1000. */
    rt_snprintf(name, sizeof(name), "Section_%04d", number);
    rt_snprintf(full_path, sizeof(full_path), "/%s", name);
    dir = opendir(full_path);

    /* Also accept unpadded names such as Section_1. */
    if (!dir)
    {
        rt_snprintf(name, sizeof(name), "Section_%d", number);
        rt_snprintf(full_path, sizeof(full_path), "/%s", name);
        dir = opendir(full_path);
    }

    if (!dir)
        return -1;

    closedir(dir);
    rt_strncpy(out_name, name, DIR_NAME_LEN - 1);
    out_name[DIR_NAME_LEN - 1] = '\0';
    return 0;
}

static int get_root_section_fast(int index, char *out_name)
{
    int slot = sd_det_flag ? 1 : 0;
    int base = g_section_number_base[slot];

    if (base == SECTION_BASE_UNKNOWN)
    {
        char probe[DIR_NAME_LEN];

        if (section_dir_exists_and_copy(0, probe) == 0)
            base = 0;
        else if (section_dir_exists_and_copy(1, probe) == 0)
            base = 1;
        else
            base = SECTION_BASE_UNSUPPORTED;

        g_section_number_base[slot] = (signed char)base;
    }

    if (base == 0 || base == 1)
        return section_dir_exists_and_copy(index + base, out_name);

    return -1;
}

/* Reset one slot to empty state. */
static void slot_clear(dir_slot_t *s)
{
    s->path_h      = 0;
    s->cur_name[0] = '\0';
    s->cur_index   = -1;
    s->last_name[0]= '\0';
    s->last_total  = -1;
    s->cnt         = -1;
    s->valid       = 0;
}

/* Invalidate all slots — call after every SD card mount/remount. */
void get_nth_file_invalidate_cache(void)
{
    int i;
    for (i = 0; i < DIR_SLOT_COUNT; i++)
        slot_clear(&g_slots[i]);

    /* Re-detect the numbering base for the card that has just been mounted.
     * This also handles a card whose content was replaced while powered off. */
    g_section_number_base[sd_det_flag ? 1 : 0] = SECTION_BASE_UNKNOWN;
}

/* Check whether a slot is valid for the given path/sd/dirs combination. */
#define SLOT_MATCH(s, path, dirs) \
    ((s)->valid                           && \
     (s)->sd_slot    == (char)sd_det_flag && \
     (s)->only_dirs  == (char)(dirs)      && \
     (s)->path_h     == path_hash(path))

/* Write the current-entry fields into a slot. */
static void slot_set_cur(dir_slot_t *s, const char *path,
                         int index, const char *name, int only_dirs)
{
    s->path_h     = path_hash(path);
    rt_strncpy(s->cur_name, name, DIR_NAME_LEN-1);
    s->cur_name[DIR_NAME_LEN-1] = '\0';
    s->cur_index  = index;
    s->sd_slot    = (char)sd_det_flag;
    s->only_dirs  = (char)only_dirs;
    s->valid      = 1;
}

/* Write the last-entry fields into a slot (already matched). */
static void slot_set_last(dir_slot_t *s, const char *name, int total)
{
    rt_strncpy(s->last_name, name, DIR_NAME_LEN-1);
    s->last_name[DIR_NAME_LEN-1] = '\0';
    s->last_total = total;
    s->cnt        = total;
}

/* ---------- count_items — with per-slot cache ---------- */
int count_items(const char *path, int only_dirs)
{
    int si = path_slot(path);
    dir_slot_t *s = &g_slots[si];

    if (SLOT_MATCH(s, path, only_dirs) && s->cnt >= 0)
        return s->cnt;

    DIR *dir = opendir(path);
    if (!dir) return 0;

    struct dirent *ent;
    int count = 0;
    while ((ent = readdir(dir)))
    {
        if (strcmp(ent->d_name, ".")  == 0 ||
            strcmp(ent->d_name, "..") == 0 ||
            strcmp(ent->d_name, "System Volume Information") == 0)
            continue;
        if ((only_dirs  && ent->d_type == DT_DIR) ||
            (!only_dirs && ent->d_type == DT_REG && has_mp3_ext(ent->d_name)))
            count++;
    }
    closedir(dir);

    /* Store count into the slot (initialise slot if it's for a new path). */
    if (!SLOT_MATCH(s, path, only_dirs))
    {
        slot_clear(s);
        s->path_h    = path_hash(path);
        s->sd_slot   = (char)sd_det_flag;
        s->only_dirs = (char)only_dirs;
        s->valid     = 1;
    }
    s->cnt = count;
    return count;
}

/* ---------- get_nth_file ---------- */
int get_nth_file(const char *path, int index, char *out_name, int only_dirs)
{
    if (index < 0) return -1;

    /* Constant-time restore for the numbered root Section_XXXX folders.
     * If direct lookup fails, continue into the generic natural-sort path. */
    if (only_dirs && strcmp(path, ROOT_PATH) == 0)
    {
        dir_slot_t *root_slot = &g_slots[0];

        /* Preserve the zero-read cache hit for repeated play_current() calls. */
        if (SLOT_MATCH(root_slot, path, only_dirs) &&
            root_slot->cur_index == index && root_slot->cur_name[0] != '\0')
        {
            rt_strncpy(out_name, root_slot->cur_name, DIR_NAME_LEN - 1);
            out_name[DIR_NAME_LEN - 1] = '\0';
            return 0;
        }

        if (get_root_section_fast(index, out_name) == 0)
        {
            slot_set_cur(root_slot, path, index, out_name, only_dirs);
            return 0;
        }
    }

    int si = path_slot(path);
    dir_slot_t *s = &g_slots[si];

    /* ── Case 1: same index, same path — return cur directly (0 passes) ── */
    if (SLOT_MATCH(s, path, only_dirs) &&
        s->cur_index == index && s->cur_name[0] != '\0')
    {
        rt_strncpy(out_name, s->cur_name, DIR_NAME_LEN-1);
        out_name[DIR_NAME_LEN-1] = '\0';
        return 0;
    }

    /* ── Case 2: sequential FORWARD step (index = cur+1) — 1 pass ── */
    if (SLOT_MATCH(s, path, only_dirs) &&
        s->cur_index == index - 1 && s->cur_name[0] != '\0')
    {
        if (dir_one_pass(path, s->cur_name, 1, only_dirs, out_name) != 0)
            return -1;
        goto update;
    }

    /* ── Case 3: sequential BACKWARD step (index = cur-1) — 1 pass ── */
    if (SLOT_MATCH(s, path, only_dirs) &&
        s->cur_index == index + 1 && s->cur_name[0] != '\0')
    {
        if (dir_one_pass(path, s->cur_name, 0, only_dirs, out_name) != 0)
            return -1;
        goto update;
    }

    /* ── Case 4: jump to LAST entry — last-entry cache hit (0 passes) ── */
    if (SLOT_MATCH(s, path, only_dirs) &&
        s->last_total > 0 && s->last_name[0] != '\0' &&
        index == s->last_total - 1)
    {
        rt_strncpy(out_name, s->last_name, DIR_NAME_LEN-1);
        out_name[DIR_NAME_LEN-1] = '\0';
        goto update;
    }

    /* ── Case 5: backward step from last entry (index = last_total-2) ── */
    if (SLOT_MATCH(s, path, only_dirs) &&
        s->last_total > 0 && s->last_name[0] != '\0' &&
        index == s->last_total - 2)
    {
        if (dir_one_pass(path, s->last_name, 0, only_dirs, out_name) != 0)
            return -1;
        goto update;
    }

    /* ── Case 6: cache miss — approach from nearer end ──
     * Called only on bookmark restore or SD remount (rare).  */
    {
        int total = count_items(path, only_dirs);
        if (total <= 0 || index >= total) return -1;

        char pivot[DIR_NAME_LEN];
        pivot[0] = '\0';

        if (index <= total / 2)
        {
            /* forward from start */
            int pass;
            for (pass = 0; pass <= index; pass++)
            {
                if (dir_one_pass(path, pivot, 1, only_dirs, out_name) != 0)
                    return -1;
                rt_strncpy(pivot, out_name, DIR_NAME_LEN-1);
                pivot[DIR_NAME_LEN-1] = '\0';
            }
        }
        else
        {
            /* backward from end — first pass finds absolute max */
            int pass;
            for (pass = total - 1; pass >= index; pass--)
            {
                if (dir_one_pass(path, pivot, 0, only_dirs, out_name) != 0)
                    return -1;
                if (pass == total - 1)
                    slot_set_last(s, out_name, total); /* cache the absolute last */
                rt_strncpy(pivot, out_name, DIR_NAME_LEN-1);
                pivot[DIR_NAME_LEN-1] = '\0';
            }
        }

        /* if we just fetched the very last entry, store it in last-cache */
        if (index == total - 1)
            slot_set_last(s, out_name, total);
    }

update:
    /* Always keep cur-cache in sync */
    slot_set_cur(s, path, index, out_name, only_dirs);

    /* If this is the last entry and we know the count, update last-cache */
    if (SLOT_MATCH(s, path, only_dirs) && s->cnt > 0 && index == s->cnt - 1)
        slot_set_last(s, out_name, s->cnt);

    return 0;
}
static char g_section[64];
static char g_book[64];
static char g_chapter[64];

/* ==========================================================================
 * Navigation state cache
 * --------------------------------------------------------------------------
 * Stores the fully-resolved section/book/chapter paths AND the entry counts
 * for each level, indexed by (section_idx, book_idx, chapter_idx, sd_slot).
 *
 * play_current() checks this cache first. On a hit it skips all get_nth_file
 * and count_items calls — zero SD card operations.  On a miss it resolves
 * only the levels whose index changed, then updates the cache.
 *
 * next_chapter: only chapter_idx changes → 1 get_nth_file scan (book dir)
 * next_book:    book+chapter change      → 2 scans (section + book dirs)
 * next_section: all three change         → 3 scans
 *
 * RAM: 128+128+128 + 4+4+4 + 1 = ~400 bytes in .bss
 * ========================================================================== */
static struct {
    char section_path[128];   /* e.g. "/Section_0042"               */
    char book_path[128];      /* e.g. "/Section_0042/Book_001"      */
    char file_path[128];      /* e.g. "/Section_0042/Book_001/c.mp3"*/
    int  total_sections;      /* count_items(ROOT, 1)               */
    int  total_books;         /* count_items(section_path, 1)       */
    int  total_chapters;      /* count_items(book_path, 0)          */
    int  section_idx;         /* state.section_index when cached    */
    int  book_idx;            /* state.book_index when cached       */
    int  chapter_idx;         /* state.chapter_index when cached    */
    char sd_slot;             /* sd_det_flag when cached            */
    char valid;               /* 1 = cache is populated             */
} g_nav;

/* Wipe the navigation cache — call after SD remount or state reset. */
static void nav_cache_invalidate(void)
{
    g_nav.valid          = 0;
    g_nav.section_idx    = -1;
    g_nav.book_idx       = -1;
    g_nav.chapter_idx    = -1;
    g_nav.total_sections = -1;
    g_nav.total_books    = -1;
    g_nav.total_chapters = -1;
}

static int build_section_path(int section_index, char *out, size_t out_sz)
{
    char *section = g_section;
    memset(g_section, 0, sizeof(g_section));

    if (get_nth_file(ROOT_PATH, section_index, section, 1) != 0)
        return -1;

    rt_snprintf(out, out_sz, "/%s", section);
    return 0;
}

static int build_book_path(int section_index, int book_index, char *out, size_t out_sz)
{
    char *section = g_section;
    char *book    = g_book;
    char section_path[128];
    memset(g_section, 0, sizeof(g_section));
    memset(g_book, 0, sizeof(g_book));
    memset(section_path, 0, sizeof(section_path));

    if (get_nth_file(ROOT_PATH, section_index, section, 1) != 0)
        return -1;

    rt_snprintf(section_path, sizeof(section_path), "/%s", section);

    if (get_nth_file(section_path, book_index, book, 1) != 0)
        return -1;

    rt_snprintf(out, out_sz, "/%s/%s", section, book);
    return 0;
}







//#include <rtthread.h>
#include <string.h>

#ifndef DA_DEBUG
#define DA_DEBUG 1        /* 0=off, 1=failures+grows, 2=verbose */
#endif

/* grow-by-2 pointer array; store exact-size copy of name */
//#include <string.h>   // add this


static uint8_t read_button_state(struct key_button *key_btn)
{
    uint8_t state;
    rt_pin_write(key_btn->col_pin, PIN_LOW);
    rt_thread_mdelay(1);
    state = rt_pin_read(key_btn->row_pin);
    rt_pin_write(key_btn->col_pin, PIN_HIGH);
    return state;
}

static uint8_t button_read_pin(void *arg)
{
    struct key_button *key_btn = (struct key_button *) arg;
    return read_button_state(key_btn);
}

/* natural_sort: qsort comparator — delegates to natural_cmp */
static int natural_sort(const void *a, const void *b)
{
    return natural_cmp(*(const char **)a, *(const char **)b);
}

static int advance_to_next_playable(int wrap_once)
{
    int total_sections = count_items(ROOT_PATH, 1);
    if (total_sections <= 0)
        return -1;

    int start_section = state.section_index;
    int start_book = state.book_index;
    bool first_pass = true;

    for (;;)
    {
        char *section = g_section;       memset(g_section, 0, sizeof(g_section));
        char *book    = g_book;          memset(g_book, 0, sizeof(g_book));
        char section_path[128]; memset(section_path, 0, sizeof(section_path));
        char book_path[128];    memset(book_path, 0, sizeof(book_path));

        /* section valid? */
        if (state.section_index < 0 || state.section_index >= total_sections)
            state.section_index = 0;

        if (get_nth_file(ROOT_PATH, state.section_index, section, 1) != 0)
            goto next_section;

        rt_snprintf(section_path, sizeof(section_path), "/%s", section);

        int total_books = count_items(section_path, 1);
        if (total_books <= 0)
            goto next_section;

        if (state.book_index < 0 || state.book_index >= total_books)
            state.book_index = 0;

        /* scan books inside this section from current book onward */
        for (; state.book_index < total_books; state.book_index++)
        {
            if (get_nth_file(section_path, state.book_index, book, 1) != 0)
                continue;

            rt_snprintf(book_path, sizeof(book_path), "/%s/%s", section, book);

            int total_chapters = count_items(book_path, 0);
            if (total_chapters > 0)
            {
                if (state.chapter_index < 0 || state.chapter_index >= total_chapters)
                    state.chapter_index = 0;

                return 0;   /* found playable */
            }

            /* empty book -> try next book */
            state.chapter_index = 0;
        }

next_section:
        /* move to next section */
        state.section_index++;
        state.book_index = 0;
        state.chapter_index = 0;

        if (state.section_index >= total_sections)
        {
            if (!wrap_once)
                return -1;

            state.section_index = 0;
        }

        /* stop if we came back to starting point */
        if (!first_pass &&
            state.section_index == start_section &&
            state.book_index == start_book)
        {
            return -1;
        }

        first_pass = false;
    }
}

static int find_prev_playable_book_same_section(void)
{
    char *book    = g_book;         memset(g_book, 0, sizeof(g_book));
    char *section = g_section;       memset(g_section, 0, sizeof(g_section));
    char section_path[128]; memset(section_path, 0, sizeof(section_path));
    char book_path[128];    memset(book_path, 0, sizeof(book_path));

    if (get_nth_file(ROOT_PATH, state.section_index, section, 1) != 0)
        return -1;

    rt_snprintf(section_path, sizeof(section_path), "/%s", section);

    int total_books = count_items(section_path, 1);
    if (total_books <= 0)
        return -1;

    if (state.book_index >= total_books)
        state.book_index = total_books - 1;

    for (int b = state.book_index; b >= 0; b--)
    {
        if (get_nth_file(section_path, b, book, 1) != 0)
            continue;

        rt_snprintf(book_path, sizeof(book_path), "/%s/%s", section, book);

        if (count_items(book_path, 0) > 0)
        {
            state.book_index = b;
            state.chapter_index = 0;   /* first chapter */
            return 0;
        }
    }

    return -1;
}

static int find_prev_playable_section(void)
{
    int total_sections = count_items(ROOT_PATH, 1);
    char *section = g_section;       memset(g_section, 0, sizeof(g_section));
    char *book    = g_book;          memset(g_book, 0, sizeof(g_book));
    char section_path[128]; memset(section_path, 0, sizeof(section_path));
    char book_path[128];    memset(book_path, 0, sizeof(book_path));

    if (total_sections <= 0)
        return -1;

    int s = state.section_index - 1;
    if (s < 0)
        s = total_sections - 1;

    for (int scanned = 0; scanned < total_sections; scanned++)
    {
        if (get_nth_file(ROOT_PATH, s, section, 1) == 0)
        {
            rt_snprintf(section_path, sizeof(section_path), "/%s", section);

            int total_books = count_items(section_path, 1);
            if (total_books > 0)
            {
                for (int b = total_books - 1; b >= 0; b--)
                {
                    if (get_nth_file(section_path, b, book, 1) != 0)
                        continue;

                    rt_snprintf(book_path, sizeof(book_path), "/%s/%s", section, book);

                    if (count_items(book_path, 0) > 0)
                    {
                        state.section_index = s;
                        state.book_index = b;
                        state.chapter_index = 0;   /* first chapter */
                        return 0;
                    }
                }
            }
        }

        s--;
        if (s < 0)
            s = total_sections - 1;
    }

    return -1;
}
static int find_prev_playable_book_or_section_last_chapter(void)
{
    int total_sections = count_items(ROOT_PATH, 1);
    char *section = g_section;       memset(g_section, 0, sizeof(g_section));
    char *book    = g_book;          memset(g_book, 0, sizeof(g_book));
     char section_path[128]; memset(section_path, 0, sizeof(section_path));
     char book_path[128];    memset(book_path, 0, sizeof(book_path));

    if (total_sections <= 0)
        return -1;

    int s = state.section_index;
    int start_section = state.section_index;
    bool first_section = true;

    for (;;)
    {
        if (s < 0)
            s = total_sections - 1;
        if (s >= total_sections)
            s = 0;

        if (get_nth_file(ROOT_PATH, s, section, 1) == 0)
        {
            rt_snprintf(section_path, sizeof(section_path), "/%s", section);

            int total_books = count_items(section_path, 1);
            if (total_books > 0)
            {
                int start_book;

                if (first_section)
                    start_book = state.book_index - 1;   /* previous book in same section */
                else
                    start_book = total_books - 1;        /* last book of previous section */

                if (start_book >= total_books)
                    start_book = total_books - 1;

                for (int b = start_book; b >= 0; b--)
                {
                    int total_chapters;

                    if (get_nth_file(section_path, b, book, 1) != 0)
                        continue;

                    rt_snprintf(book_path, sizeof(book_path), "/%s/%s", section, book);

                    total_chapters = count_items(book_path, 0);
                    if (total_chapters > 0)
                    {
                        state.section_index = s;
                        state.book_index = b;
                        state.chapter_index = total_chapters - 1;   /* last chapter */
                        return 0;
                    }
                }
            }
        }

        /* move to previous section */
        s--;

        if (s < 0)
            s = total_sections - 1;

        if (!first_section && s == start_section)
            break;

        first_section = false;
    }

    return -1;
}

void play_current(void)
{
    rt_thread_mdelay(50);
//    rt_kprintf("*****************************playing current\n");

    if (paused == 100)
    {
//        rt_kprintf("paused == 100\n");
        return;
    }

    if (scan_mutex == RT_NULL)
    {
//        rt_kprintf("scan_mutex is NULL — skipping play_current()\n");
        return;
    }

    rt_mutex_take(scan_mutex, RT_WAITING_FOREVER);

    /* ------------------------------------------------------------------
     * Fast path: all three indices match the nav cache AND same SD slot.
     * Zero SD card operations — just call mp3_player_play with the cached
     * file path.  This is the common case for next/prev chapter.
     * ------------------------------------------------------------------ */
    if (g_nav.valid                                  &&
        g_nav.sd_slot      == sd_det_flag            &&
        g_nav.section_idx  == state.section_index    &&
        g_nav.book_idx     == state.book_index       &&
        g_nav.chapter_idx  == state.chapter_index    &&
        g_nav.file_path[0] != '\0')
    {
//        rt_kprintf("nav cache hit: %s\n", g_nav.file_path);
        hk.SD  = rt_pin_read(SD1_SD2);
        hk.INT = rt_pin_read(internal_Mosfet);
        hk.EXT = rt_pin_read(external_Mosfet);
        state.chapter_start_time = rt_tick_get();
        autoplay_enabled  = 1;
        pause_mode_active = false;
        mp3_player_volume_set(0);
        mp3_player_play(g_nav.file_path);
        rt_thread_mdelay(50);
        mp3_player_volume_set(state.volume);
        rt_mutex_release(scan_mutex);
        return;
    }

    /* ------------------------------------------------------------------
     * Slow path: resolve section → book → chapter from indices.
     * Only runs when an index changed (level change) or cache is cold
     * (first play, bookmark restore, SD switch).
     * ------------------------------------------------------------------ */
    char *section = g_section;
    char *book    = g_book;
    char *chapter = g_chapter;
    char  path[128];
    memset(g_section, 0, sizeof(g_section));
    memset(g_book,    0, sizeof(g_book));
    memset(g_chapter, 0, sizeof(g_chapter));
    memset(path, 0, sizeof(path));

    int total_sections = count_items(ROOT_PATH, 1);
    if (total_sections <= 0)
    {
//        rt_kprintf("No sections found!\n");
        play_5_beep();
//        rt_kprintf("Pausing playback\n");
        update_led_color();
        rt_thread_mdelay(50);
        mp3_player_pause();
        pause_mode_active = true;
        start_task(LED_MODE_PAUSE);
        rt_mutex_release(scan_mutex);
        return;
    }

    if (state.section_index < 0 || state.section_index >= total_sections)
        state.section_index = 0;

    int checked_sections = 0;

    while (checked_sections < total_sections)
    {
        int total_books = 0;
        int checked_books = 0;
        char section_path[128]; memset(section_path, 0, sizeof(section_path));
        char book_path[128];    memset(book_path, 0, sizeof(book_path));

        rt_memset(g_section, 0, sizeof(g_section));
        rt_memset(g_book,    0, sizeof(g_book));
        rt_memset(g_chapter, 0, sizeof(g_chapter));

        if (get_nth_file(ROOT_PATH, state.section_index, section, 1) != 0)
        {
            state.section_index++;
            if (state.section_index >= total_sections)
                state.section_index = 0;
            state.book_index   = 0;
            state.chapter_index = 0;
            checked_sections++;
            continue;
        }

        rt_snprintf(section_path, sizeof(section_path), "/%s", section);
        total_books = count_items(section_path, 1);

        if (total_books <= 0)
        {
//            rt_kprintf("No books found in section %s, skipping...\n", section);
            state.section_index++;
            if (state.section_index >= total_sections)
                state.section_index = 0;
            state.book_index   = 0;
            state.chapter_index = 0;
            checked_sections++;
            continue;
        }

        if (state.book_index < 0 || state.book_index >= total_books)
            state.book_index = 0;

        while (checked_books < total_books)
        {
            int total_chapters = 0;

            rt_memset(g_book,    0, sizeof(g_book));
            rt_memset(g_chapter, 0, sizeof(g_chapter));

            if (get_nth_file(section_path, state.book_index, book, 1) != 0)
            {
                state.book_index++;
                if (state.book_index >= total_books)
                    break;
                state.chapter_index = 0;
                checked_books++;
                continue;
            }

            rt_snprintf(book_path, sizeof(book_path), "/%s/%s", section, book);
            total_chapters = count_items(book_path, 0);

            if (total_chapters <= 0)
            {
//                rt_kprintf("No chapters found in book %s, skipping...\n", book);
                state.book_index++;
                state.chapter_index = 0;
                checked_books++;
                continue;
            }

            if (state.chapter_index < 0 || state.chapter_index >= total_chapters)
                state.chapter_index = 0;

            if (get_nth_file(book_path, state.chapter_index, chapter, 0) != 0)
            {
                state.chapter_index = 0;
                state.book_index++;
                checked_books++;
                continue;
            }

            rt_snprintf(path, sizeof(path), "/%s/%s/%s", section, book, chapter);

            /* ---- update nav cache with resolved result ---- */
            rt_strncpy(g_nav.section_path, section_path, sizeof(g_nav.section_path) - 1);
            g_nav.section_path[sizeof(g_nav.section_path) - 1] = '\0';
            rt_strncpy(g_nav.book_path, book_path, sizeof(g_nav.book_path) - 1);
            g_nav.book_path[sizeof(g_nav.book_path) - 1] = '\0';
            rt_strncpy(g_nav.file_path, path, sizeof(g_nav.file_path) - 1);
            g_nav.file_path[sizeof(g_nav.file_path) - 1] = '\0';
            g_nav.total_sections = total_sections;
            g_nav.total_books    = total_books;
            g_nav.total_chapters = total_chapters;
            g_nav.section_idx    = state.section_index;
            g_nav.book_idx       = state.book_index;
            g_nav.chapter_idx    = state.chapter_index;
            g_nav.sd_slot        = sd_det_flag;
            g_nav.valid          = 1;

            hk.SD  = rt_pin_read(SD1_SD2);
            hk.INT = rt_pin_read(internal_Mosfet);
            hk.EXT = rt_pin_read(external_Mosfet);

//            rt_kprintf("sd state=  %d %d %d\n", hk.SD, hk.INT, hk.EXT);
//            rt_kprintf("Playing: %s\n", path);

            state.chapter_start_time = rt_tick_get();
            autoplay_enabled  = 1;
            pause_mode_active = false;
            mp3_player_volume_set(0);
            mp3_player_play(path);
            rt_thread_mdelay(50);
            mp3_player_volume_set(state.volume);

            rt_mutex_release(scan_mutex);
            return;
        }

        /* no playable book in this section -> next section */
        state.section_index++;
        if (state.section_index >= total_sections)
            state.section_index = 0;
        state.book_index   = 0;
        state.chapter_index = 0;
        checked_sections++;
    }

//    rt_kprintf("No playable content found anywhere!\n");
    play_5_beep();
    update_led_color();
    rt_thread_mdelay(50);
    mp3_player_pause();
    pause_mode_active = true;
    start_task(LED_MODE_PAUSE);
    rt_mutex_release(scan_mutex);
}
static void chapter_hold_mute_on(void)
{
    if (!chapter_hold_muted)
    {
        chapter_hold_prev_volume = state.volume;
        mp3_player_volume_set(0);
        chapter_hold_muted = true;
    }
}

static void chapter_hold_mute_off(void)
{
    if (chapter_hold_muted)
    {
        mp3_player_volume_set(chapter_hold_prev_volume);
        chapter_hold_muted = false;
    }
}

static void hold_seek_led_pulse(void)
{
    led_beep_pulse_start();
    rt_thread_mdelay(40);
    led_beep_pulse_stop();
}

static void start_hold_seek(int dir)
{
    ff_rw_hold_active = true;
    hold_seek_dir = dir;
    pending_seek_sec = 0;
    last_hold_seek_tick = 0;

    chapter_hold_mute_on();

    if (mp3_player_state_get() == PLAYER_STATE_PLAYING)
    {
        mp3_player_pause();
    }
}

static void accumulate_hold_seek_step(void)
{
    rt_tick_t now = rt_tick_get();

    if (!ff_rw_hold_active)
        return;

    if ((now - last_hold_seek_tick) < rt_tick_from_millisecond(HOLD_SEEK_INTERVAL_MS))
        return;

    last_hold_seek_tick = now;

    if (hold_seek_dir > 0)
        pending_seek_sec += HOLD_SEEK_STEP_SEC;
    else if (hold_seek_dir < 0)
        pending_seek_sec -= HOLD_SEEK_STEP_SEC;

//    rt_kprintf("pending_seek_sec = %d\n", pending_seek_sec);

}

static void finish_hold_seek_and_resume(void)
{
    if (hold_seek_wait_release)
    {
        hold_seek_wait_release = false;
        ff_rw_hold_active = false;
        hold_seek_dir = 0;
        pending_seek_sec = 0;
        last_hold_seek_tick = 0;
        chapter_hold_mute_off();
        return;
    }
    uint32_t current_sec;
    uint32_t total_sec;
    int target_sec;

    if (!ff_rw_hold_active)
        return;

    current_sec = mp3_get_cur_seconds();
    total_sec   = player.mp3_info.total_seconds;

    target_sec = (int)current_sec + pending_seek_sec;

    if (target_sec < 0)
        target_sec = 0;

    if (total_sec > 0 && target_sec >= (int)total_sec)
        target_sec = total_sec - 1;

//    rt_kprintf("hold release: current=%d pending=%d target=%d total=%d\n",
//               current_sec, pending_seek_sec, target_sec, total_sec);

    if (pending_seek_sec != 0)
    {
        mp3_seek((uint32_t)target_sec);
        player.paused_position = ftell(player.fp);
        player.decode_oper.bytes_left = 0;
    }

    chapter_hold_mute_off();
    mp3_player_resume();

    ff_rw_hold_active = false;
    hold_seek_dir = 0;
    pending_seek_sec = 0;
    last_hold_seek_tick = 0;
}

static bool duration_warning_shown = false;

void fast_forward(void)
{
    uint32_t current_sec;
    uint32_t total_sec;

    if (hold_seek_wait_release)
        return;

    if (mp3_player_state_get() != PLAYER_STATE_PLAYING &&
        !(ff_rw_hold_active && hold_seek_dir == 1))
    {
        return;
    }

    if (!ff_rw_hold_active)
    {
        start_hold_seek(+1);
    }

    current_sec = mp3_get_cur_seconds();
    total_sec   = player.mp3_info.total_seconds;

    if (total_sec > 0 &&
        ((int)current_sec + pending_seek_sec + HOLD_SEEK_STEP_SEC) >= (int)total_sec)
    {
        hold_seek_wait_release = true;

        ff_rw_hold_active = false;
        pending_seek_sec = 0;
        hold_seek_dir = 0;
        last_hold_seek_tick = 0;

        chapter_hold_mute_off();

        uint32_t old_event = btn_event_val;
        btn_event_val = 0;
        next_chapter();
        btn_event_val = old_event;

        return;
    }

    accumulate_hold_seek_step();
}

void fast_rewind(void)
{
    uint32_t current_sec;

    if (hold_seek_wait_release)
        return;

    if (mp3_player_state_get() != PLAYER_STATE_PLAYING &&
        !(ff_rw_hold_active && hold_seek_dir == -1))
    {
        return;
    }

    if (!ff_rw_hold_active)
    {
        start_hold_seek(-1);
    }

    current_sec = mp3_get_cur_seconds();

    if (((int)current_sec + pending_seek_sec - HOLD_SEEK_STEP_SEC) <= 0)
    {
        hold_seek_wait_release = true;

        pending_seek_sec = 0;
        hold_seek_dir = 0;
        last_hold_seek_tick = 0;

        mp3_seek(0);
        player.paused_position = ftell(player.fp);
        player.decode_oper.bytes_left = 0;

        chapter_hold_mute_off();
        mp3_player_resume();

        ff_rw_hold_active = false;

        return;
    }

    accumulate_hold_seek_step();
}

static void next_chapter(void)
{
    char book_path[128]; memset(book_path, 0, sizeof(book_path));
    int total_chapters;

    if (build_book_path(state.section_index, state.book_index, book_path, sizeof(book_path)) != 0)
        return;

    total_chapters = count_items(book_path, 0);
    if (total_chapters <= 0)
        return;

    if (btn_event_val == LONG_PRESS_HOLD)
    {
        long_press_active = true;
        chapter_hold_mute_on();

        if (state.chapter_index < total_chapters - 1)
        {
//            play_beep();
//            rt_thread_mdelay(50);
            state.chapter_index++;
            reached_limit = false;
        }
        else
        {
            reached_limit = true;
        }
    }
    else if (btn_event_val == PRESS_UP && long_press_active)
    {
        long_press_active = false;
        chapter_hold_mute_off();
        if (reached_limit)
            return;
    }
    else
    {
        state.chapter_index++;

        if (state.chapter_index >= total_chapters)
        {
            state.chapter_index = 0;
            next_book();
            return;
        }
    }

    rt_thread_mdelay(100);
    songseek = 0;
    play_current();
}


static void prev_chapter(void)
{
    uint32_t cur_sec = mp3_get_cur_seconds();

    /* If current chapter has played past the threshold, restart from 0 */
    if (cur_sec > CHAPTER_REWIND_THRESHOLD && btn_event_val != LONG_PRESS_HOLD)
    {
    //        rt_kprintf("Restarting current chapter\n");
        songseek = 0;
        play_current();
        return;
    }

    if (btn_event_val == LONG_PRESS_HOLD)
    {
        long_press_active = true;
        chapter_hold_mute_on();

        /* previous chapter in same book */
        if (state.chapter_index > 0)
        {
//            play_beep();
//            rt_thread_mdelay(50);
            state.chapter_index--;
            reached_limit = false;
        }
        else
        {
            /* first chapter -> move to previous playable book/section last chapter */
            if (find_prev_playable_book_or_section_last_chapter() != 0)
            {
//                rt_kprintf("No previous playable chapter found\n");
                reached_limit = true;
                return;
            }

            reached_limit = false;
        }
    }
    else if (btn_event_val == PRESS_UP && long_press_active)
    {
        long_press_active = false;
        chapter_hold_mute_off();
        if (reached_limit)
            return;
    }
    else
    {
        /* Single press previous chapter */
        if (state.chapter_index > 0)
        {
            state.chapter_index--;
        }
        else
        {
            /* first chapter -> move to previous playable book/section last chapter */
            if (find_prev_playable_book_or_section_last_chapter() != 0)
            {
//                rt_kprintf("No previous playable chapter found\n");
                return;
            }
        }
    }

    rt_thread_mdelay(100);
    songseek = 0;
    play_current();
}
//*********************************************************//

void enter_hold_browse_mode(void)
{
    if (!hold_browse_active)
    {
        hold_browse_active = true;
        suppress_playback = true;

        if (mp3_player_state_get() == PLAYER_STATE_PLAYING)
        {
            mp3_player_pause();
            rt_thread_mdelay(20);
        }
    }
}

void exit_hold_browse_mode(bool should_play)
{
    hold_browse_active = false;
    suppress_playback = false;

    if (should_play)
    {
        rt_base_t saved_pin = rt_pin_read(AUDIO_SWITCH_PIN);
        rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);

        stop_beep_playback();
        rt_thread_mdelay(200);   /* pipeline drains silently behind the mute */

        rt_pin_write(AUDIO_SWITCH_PIN, saved_pin);

        songseek = 0;
        play_current();
    }
}


static void next_book(void)
{
    char section_path[128]; memset(section_path, 0, sizeof(section_path));
    int total_books;

    if (build_section_path(state.section_index, section_path, sizeof(section_path)) != 0)
        return;

    total_books = count_items(section_path, 1);
    if (total_books <= 0)
        return;

//    if (reached_limit)
//        return;
    if (reached_limit && btn_event_val == LONG_PRESS_HOLD)
        return;

//    if (btn_event_val == LONG_PRESS_HOLD)
//    {
//        long_press_active = true;
////        suppress_playback = true;
//        enter_hold_browse_mode();
//
//        if (state.book_index < total_books - 1)
//        {
//            rt_thread_mdelay(10);
//            play_beep();
//            rt_thread_mdelay(50);
//            state.book_index++;
//            state.chapter_index = 0;
//            play_pending = true;
//        }
//        else
//        {
//            reached_limit = true;
////            long_press_active = false;
////            suppress_playback = false;
//            play_pending = true;
//            state.chapter_index = 0;
////            play_current();
//            return;
//        }
//        return;
//    }
    if (btn_event_val == LONG_PRESS_HOLD)
    {
        long_press_active = true;

        if (reached_limit)
            return;

        enter_hold_browse_mode();

        if (state.book_index < total_books - 1)
        {
            rt_thread_mdelay(10);
            play_beep();
            rt_thread_mdelay(50);

            state.book_index++;
            state.chapter_index = 0;
            /* Prime the section-slot cache so play_current() on release
             * gets a 0-pass hit instead of N forward passes. */
            { char _b[DIR_NAME_LEN];
              get_nth_file(section_path, state.book_index, _b, 1); }
            play_pending = true;
            reached_limit = false;
        }
        else
        {
            reached_limit = true;
            state.chapter_index = 0;

            if (!hold_boundary_played)
            {
                hold_boundary_played = true;
                play_pending = false;
                exit_hold_browse_mode(true);   // play immediately while still holding
            }
            return;
        }
        return;
    }

//    else if (btn_event_val == PRESS_UP && long_press_active)
//    {
//        long_press_active = false;
//
//        if (play_pending)
//        {
//            suppress_playback = false;
//            play_pending = false;
//            state.chapter_index = 0;
//            play_current();
//        }
//        return;
//    }
    else if (btn_event_val == PRESS_UP && long_press_active)
    {
        long_press_active = false;

        if (hold_boundary_played)
        {
            reached_limit = false;
            hold_boundary_played = false;
            play_pending = false;
            return;
        }

        if (play_pending)
        {
            play_pending = false;
            state.chapter_index = 0;
            exit_hold_browse_mode(true);
        }
        else
        {
            exit_hold_browse_mode(false);
        }

        reached_limit = false;
        hold_boundary_played = false;
        return;
    }

    else
    {
        state.book_index++;
        if (state.book_index >= total_books)
        {
            state.book_index = 0;
            next_section();
            return;
        }

        state.chapter_index = 0;
        suppress_playback = false;
        songseek = 0;
        play_current();
    }
}

static void prev_book(void)
{
    char section_path[128]; memset(section_path, 0, sizeof(section_path));
    int total_books = 0;
    int total_sections = 0;

    total_sections = count_items(ROOT_PATH, 1);
    if (total_sections <= 0)
        return;

    if (build_section_path(state.section_index, section_path, sizeof(section_path)) != 0)
        return;

    total_books = count_items(section_path, 1);
    if (total_books <= 0)
        return;

//    if (reached_limit)
//        return;
    if (reached_limit && btn_event_val == LONG_PRESS_HOLD)
        return;

//    if (btn_event_val == LONG_PRESS_HOLD)
//    {
//        long_press_active = true;
////        suppress_playback = true;
//        enter_hold_browse_mode();
//
//        if (state.book_index > 0)
//        {
//            rt_thread_mdelay(10);
//            play_beep();
//            rt_thread_mdelay(50);
//            state.book_index--;
//            state.chapter_index = 0;
//            play_pending = true;
//            reached_limit = false;
//        }
//        else
//        {
//            /* Go to previous section's last book */
//            if (state.section_index > 0)
//                state.section_index--;
//            else
//                state.section_index = total_sections - 1;
//
//            if (build_section_path(state.section_index, section_path, sizeof(section_path)) != 0)
//                return;
//
//            total_books = count_items(section_path, 1);
//            if (total_books <= 0)
//                return;
//
//            state.book_index = total_books - 1;
//            state.chapter_index = 0;
//            play_pending = true;
//            reached_limit = false;
//        }
//
//        return;
//    }
    if (btn_event_val == LONG_PRESS_HOLD)
    {
        long_press_active = true;

        if (reached_limit)
            return;

        enter_hold_browse_mode();

        if (state.book_index > 0)
        {
            rt_thread_mdelay(10);
            play_beep();
            rt_thread_mdelay(50);

            state.book_index--;
            state.chapter_index = 0;
            /* Prime the section-slot cache so play_current() on release
             * gets a 0-pass hit instead of N backward passes. */
            { char _b[DIR_NAME_LEN];
              get_nth_file(section_path, state.book_index, _b, 1); }
            play_pending = true;
            reached_limit = false;
        }
        else
        {
            reached_limit = true;
            state.chapter_index = 0;

            if (!hold_boundary_played)
            {
                hold_boundary_played = true;
                play_pending = false;
                exit_hold_browse_mode(true);   // play immediately while still holding
            }
            return;
        }

        return;
    }

//    else if (btn_event_val == PRESS_UP && long_press_active)
//    {
//        long_press_active = false;
//
//        if (play_pending)
//        {
//            suppress_playback = false;
//            play_pending = false;
//            play_current();
//        }
//        return;
//    }
    else if (btn_event_val == PRESS_UP && long_press_active)
    {
        long_press_active = false;

        if (hold_boundary_played)
        {
            reached_limit = false;
            hold_boundary_played = false;
            play_pending = false;
            return;
        }

        if (play_pending)
        {
            play_pending = false;
            exit_hold_browse_mode(true);
        }
        else
        {
            exit_hold_browse_mode(false);
        }

        reached_limit = false;
        hold_boundary_played = false;
        return;
    }

    else
    {
        /* Single press previous book behavior:
           1. If currently inside a book but not at chapter 0,
              go to the same book's first chapter.
           2. If already at first chapter, go to previous playable book.
           3. If no previous playable book in this section, go to previous playable section.
           4. Always land on first chapter.
        */

        if (state.chapter_index > 0)
        {
            state.chapter_index = 0;
        }
        else if (state.book_index > 0)
        {
            state.book_index--;

            if (find_prev_playable_book_same_section() != 0)
            {
                if (find_prev_playable_section() != 0)
                    return;
            }
        }
        else
        {
            if (find_prev_playable_section() != 0)
                return;
        }

        suppress_playback = false;
        songseek = 0;
        play_current();
    }
}

static void next_section(void)
{
    if (count_items(ROOT_PATH, 1) == 0)
        return;

//    if (reached_limit)
//        return;
    if (reached_limit && btn_event_val == LONG_PRESS_HOLD)
        return;

//    if (btn_event_val == LONG_PRESS_HOLD)
//    {
//        long_press_active = true;
////        suppress_playback = true;
//        enter_hold_browse_mode();
//
//
//        if (state.section_index < count_items(ROOT_PATH, 1) - 1)
//        {
//            rt_thread_mdelay(10);
//            play_beep();
//            rt_kprintf("playing beep section forward\n");
//            rt_thread_mdelay(50);
//            state.section_index++;
//            play_pending = true;
//        }
//        else
//        {
//            // At last section
//            rt_kprintf("suppress false\n");
//            reached_limit = true;
////            long_press_active = false;
////            suppress_playback = false;
//            play_pending = true;
//
////            state.book_index = 0;
////            state.chapter_index = 0;
////            scan_books();
////            scan_chapters();
//            state.book_index = 0;
//            state.chapter_index = 0;
//
//
////            scan_books();
////            scan_chapters();
//
////            play_current(); // Final one-time playback
//            return;
//        }
//
//        // Load books/chapters for new section without playing
////        state.book_index = 0;
////        state.chapter_index = 0;
////        scan_books();
////        scan_chapters();
//
//        // Load books/chapters for new section without playing
//        state.book_index = 0;
//        state.chapter_index = 0;
//
//        // 🔥 FIX
//
//
////        scan_books();
////        scan_chapters();
//        return;
//    }
    if (btn_event_val == LONG_PRESS_HOLD)
    {
        int total_sections = count_items(ROOT_PATH, 1);

        long_press_active = true;

        if (reached_limit)
            return;

        enter_hold_browse_mode();

        if (state.section_index < total_sections - 1)
        {
            rt_thread_mdelay(10);
            play_beep();
//            rt_kprintf("playing beep section forward\n");
            rt_thread_mdelay(50);

            state.section_index++;
            state.book_index = 0;
            state.chapter_index = 0;
            /* Prime the root-slot cache so play_current() on release
             * gets a 0-pass hit instead of N forward passes. */
            { char _s[DIR_NAME_LEN];
              get_nth_file(ROOT_PATH, state.section_index, _s, 1); }
            play_pending = true;
            reached_limit = false;
        }
        else
        {
            /* absolute last section reached */
            state.book_index = 0;
            state.chapter_index = 0;
            reached_limit = true;

            if (!hold_boundary_played)
            {
                hold_boundary_played = true;
                play_pending = false;
                exit_hold_browse_mode(true);   /* play first book of last section */
            }
            return;
        }

        return;
    }

//    else if (btn_event_val == PRESS_UP && long_press_active)
//    {
//        long_press_active = false;
//
//        if (play_pending)
//        {
//            suppress_playback = false;
//            play_pending = false;
//
////            state.book_index = 0;
////            state.chapter_index = 0;
////
////            scan_books();
////            scan_chapters();
//            state.book_index = 0;
//            state.chapter_index = 0;
//
//
//
////            scan_books();
////            scan_chapters();
//
//            play_current();
//        }
//
//        return;
//    }
    else if (btn_event_val == PRESS_UP && long_press_active)
    {
        long_press_active = false;

        if (hold_boundary_played)
        {
            reached_limit = false;
            hold_boundary_played = false;
            play_pending = false;
            return;
        }

        if (play_pending)
        {
            play_pending = false;
            state.book_index = 0;
            state.chapter_index = 0;
            exit_hold_browse_mode(true);
        }
        else
        {
            exit_hold_browse_mode(false);
        }

        reached_limit = false;
        hold_boundary_played = false;
        return;
    }
    else
    {
        // Single press behavior
        int total = count_items(ROOT_PATH, 1);

        state.section_index++;

        if (state.section_index >= total)
            state.section_index = 0;

//        state.book_index = 0;
//        state.chapter_index = 0;
//
//        scan_books();
//        scan_chapters();
        state.book_index = 0;
        state.chapter_index = 0;


//        scan_books();
//        scan_chapters();

        suppress_playback = false;
        songseek = 0;
        play_current();
    }
}

static void prev_section(void)
{
    if (count_items(ROOT_PATH, 1) == 0)
        return;

//    if (reached_limit)
//        return;
    if (reached_limit && btn_event_val == LONG_PRESS_HOLD)
        return;

//    if (btn_event_val == LONG_PRESS_HOLD)
//    {
//        long_press_active = true;
////        suppress_playback = true;
//        enter_hold_browse_mode();
//
//        if (state.section_index > 0)
//        {
//            rt_thread_mdelay(10);
//            play_beep();
//            rt_thread_mdelay(50);
//            state.section_index--;
//            play_pending = true;
//        }
//        else
//        {
//            // At first section
//            reached_limit = true;
////            long_press_active = false;
////            suppress_playback = false;
//            play_pending = true;
//
//            state.book_index = 0;
//          state.chapter_index = 0;
////            scan_books();
////            scan_chapters():
//
////            scan_books();
////            scan_chapters();
//
//
////            play_current(); // Final one-time playback
//            return;
//        }
//
//        // Load books/chapters without playing
//        state.book_index = 0;
//        state.chapter_index = 0;
////        scan_books();
////        scan_chapters();
//
////        scan_books();
////        scan_chapters();
//        return;
//    }
    if (btn_event_val == LONG_PRESS_HOLD)
    {
        long_press_active = true;

        if (reached_limit)
            return;

        enter_hold_browse_mode();

        if (state.section_index > 0)
        {
            rt_thread_mdelay(10);
            play_beep();
            rt_thread_mdelay(50);

            state.section_index--;
            state.book_index = 0;
            state.chapter_index = 0;
            /* Prime the root-slot cache so play_current() on release
             * gets a 0-pass hit instead of N backward passes. */
            { char _s[DIR_NAME_LEN];
              get_nth_file(ROOT_PATH, state.section_index, _s, 1); }
            play_pending = true;
            reached_limit = false;
        }
        else
        {
            /* absolute first section reached */
            state.section_index = 0;
            state.book_index = 0;
            state.chapter_index = 0;
            reached_limit = true;

            if (!hold_boundary_played)
            {
                hold_boundary_played = true;
                play_pending = false;
                exit_hold_browse_mode(true);   /* play first book of first section */
            }
            return;
        }

        return;
    }
//    else if (btn_event_val == PRESS_UP && long_press_active)
//    {
//        long_press_active = false;
//
//        if (play_pending)
//        {
//            suppress_playback = false;
//            play_pending = false;
//
//            state.book_index = 0;
//            state.chapter_index = 0;
//
////            scan_books();
////            scan_chapters();
//
//            play_current();
//        }
//
//        return;
//    }
    else if (btn_event_val == PRESS_UP && long_press_active)
    {
        long_press_active = false;

        if (hold_boundary_played)
        {
            reached_limit = false;
            hold_boundary_played = false;
            play_pending = false;
            return;
        }

        if (play_pending)
        {
            play_pending = false;
            state.book_index = 0;
            state.chapter_index = 0;
            exit_hold_browse_mode(true);
        }
        else
        {
            exit_hold_browse_mode(false);
        }

        reached_limit = false;
        hold_boundary_played = false;
        return;
    }
    else
        {
            /* Single press previous section behavior:
               1. If not already at the start of the current section,
                  reset to current section's first book, first chapter.
               2. If already at the start, move to previous section's first book, first chapter.
            */

            int total_sections = count_items(ROOT_PATH, 1);
            if (total_sections <= 0)
                return;

            if (state.book_index > 0 || state.chapter_index > 0)
            {
                state.book_index = 0;
                state.chapter_index = 0;
            }
            else
            {
                /* Move to previous section, skipping any empty sections */
                int target = (state.section_index > 0) ? state.section_index - 1 : total_sections - 1;
                int scanned = 0;
                bool found = false;

                while (scanned < total_sections)
                {
                    char sec_name[64]; memset(sec_name, 0, sizeof(sec_name));
                    char sec_path[128]; memset(sec_path, 0, sizeof(sec_path));

                    if (get_nth_file(ROOT_PATH, target, sec_name, 1) == 0)
                    {
                        rt_snprintf(sec_path, sizeof(sec_path), "/%s", sec_name);
                        if (count_items(sec_path, 1) > 0)
                        {
                            state.section_index = target;
                            found = true;
                            break;
                        }
                    }

                    target = (target > 0) ? target - 1 : total_sections - 1;
                    scanned++;
                }

                if (!found)
                    return;

                state.book_index = 0;
                state.chapter_index = 0;
            } //...

            reached_limit = false;
            suppress_playback = false;
            songseek = 0;
            play_current();
        }
}
static bool max_level_reach = false;

extern void saia_volume_set_immediate(rt_uint8_t volume);
static void volume_up(int step)
{
    if (mp3_player_state_get() == PLAYER_STATE_STOPED)
    {
        return;  // Don't adjust volume when stopped
    }

    /* Increase volume if not at max */
    if (state.volume < MAX_VOLUME)
    {
        state.volume += step;

        if (state.volume > MAX_VOLUME)
            state.volume = MAX_VOLUME;

        saia_volume_set_immediate((rt_uint8_t)state.volume);
        mp3_player_volume_set(state.volume);
        current_volume = state.volume;

        rt_kprintf("Volume = %d\n", state.volume);
        if (state.volume < MAX_VOLUME)
            max_level_reach = false;
    }
    else
    {
        if (!max_level_reach)
        {
        /* Already at max → play warning beep EVERY press */
//        rt_kprintf("Max volume reached\n");
        mp3_player_pause();
        play_double_beep();
//        rt_thread_mdelay(50);
        mp3_player_resume();
        mp3_player_volume_set(100);
        max_level_reach = true;
        }
        if (pause_mode_active)
                     {
                         start_task(LED_MODE_PAUSE);
                     }
                     else
                     {
                         stop_task();
                         update_led_color();
                     }
    }
}


static bool min_level_reach = false;


static void volume_down(int step)
{
    if (mp3_player_state_get() == PLAYER_STATE_STOPED)
    {
        return;
    }

    /* If already at minimum volume */
    if (state.volume <= MIN_VOLUME)
    {
        state.volume = MIN_VOLUME;
        current_volume = MIN_VOLUME;

        if (!min_level_reach)
                {
//                    rt_kprintf("Min volume reached\n");
                    mp3_player_pause();
                    rt_thread_mdelay(20);
                    mp3_player_volume_set(50);
                    play_double_beep_with_volume(1);
                    rt_thread_mdelay(200);
                    mp3_player_volume_set(MIN_VOLUME);
                    current_volume = MIN_VOLUME;
                    mp3_player_resume();
                    min_level_reach = true;
                }
        if (pause_mode_active)
                   start_task(LED_MODE_PAUSE);
               else
               {
                   stop_task();
                   update_led_color();
               }
        return;
    }

    /* If next step would go below minimum */
    if (state.volume <= (MIN_VOLUME + step))
    {
        state.volume = MIN_VOLUME;
    }
    else
    {
        state.volume -= step;
    }

    saia_volume_set_immediate((rt_uint8_t)state.volume);
    mp3_player_volume_set(state.volume);
    current_volume = state.volume;

    rt_kprintf("Volume = %d\n", state.volume);
    if (state.volume > MIN_VOLUME)
        min_level_reach = false;
    if (pause_mode_active)
       {
           start_task(LED_MODE_PAUSE);
       }
       else
       {
           stop_task();
           update_led_color();
       }
}

//****************************flash************************//

void save_current_bookmark(sd_slot_t target)
{
    int b = 0, c = 0, d = 0;
    unsigned char tempo;

        char section_path[128];
        char book_path[128];
        memset(section_path, 0, sizeof(section_path));
        memset(book_path, 0, sizeof(book_path));

    int total_sections = 0;
    int total_books = 0;
    int total_chapters = 0;

    b = rt_pin_read(SD1_SD2);          // pe3
    c = rt_pin_read(internal_Mosfet);
    d = rt_pin_read(external_Mosfet);

    if ((state.volume < 0) || (state.volume > 105))
    {
        state.volume = 20;
        songseek = 0;
    }

    tempo = ((b << 2) | (c << 1) | (d));   // later state

    total_sections = count_items(ROOT_PATH, 1);

    if (build_section_path(state.section_index, section_path, sizeof(section_path)) == 0)
    {
        total_books = count_items(section_path, 1);
    }
    else
    {
        total_books = 0;
    }

    if (build_book_path(state.section_index, state.book_index, book_path, sizeof(book_path)) == 0)
    {
        total_chapters = count_items(book_path, 0);
    }
    else
    {
        total_chapters = 0;
    }

    /* IMPORTANT: when this function is called from the cable-removal recovery
         * path (switch_mount_and_play -> save_current_bookmark), the live SD-mux
         * pins (`tempo`) have been temporarily flipped by button_plus_cable() to
         * route the SD card to the GL823K USB bridge. They no longer reflect
         * which card the playback was actually coming from. The `target` argument,
         * however, is passed by the caller and IS reliable — it is `current_slot`,
         * i.e. the slot that owns this playback session.
         *
         * We therefore decide the bookmark slot from `target` first; `tempo` is
         * only consulted as a fallback when `target` is something out of range
         * (which never happens with the current callers, but is left for safety).
         */
        if ((target == SLOT_EXTERNAL) ||
            ((target != SLOT_INTERNAL) && (tempo == 0x06)))
        {
            bookmark_info_t bookmark_info2 = {
                .volume = state.volume,
                .section = state.section_index,
                .book = state.book_index,
                .chapter = state.chapter_index,
                .sdcard = 6,
                .seektime = songseek,
                .total_sections = total_sections,
                .total_books = total_books,
                .total_chapters = total_chapters
            };

            bookmark_info.sdcard = 6;
            bookmark_info.volume = state.volume;
            bookmark_info.seektime = songseek;
            bookmark_info.total_sections = total_sections;
            bookmark_info.total_books = total_books;
            bookmark_info.total_chapters = total_chapters;

//            rt_kprintf("Saving bookmark external: V=%d, S=%d, B=%d, C=%d SD=%d, cur_sec = %ld (target=%d, tempo=0x%02X)\n",
//                       bookmark_info2.volume,
//                       bookmark_info2.section,
//                       bookmark_info2.book,
//                       bookmark_info2.chapter,
//                       bookmark_info2.sdcard,
//                       bookmark_info2.seektime,
//                       target, tempo);

            bookmark_update_cache(total_sections, total_books,
                                  total_chapters, bookmark_info2.sdcard);
            if (save_bookmark_state(&bookmark_info2, 1) != 0)
            {
//                rt_kprintf("Failed to save bookmark!\n");
                return;
            }

            if (poweroffflag)
            {
                if (save_bookmark_state(&bookmark_info, 0) != 0)
                {
//                    rt_kprintf("Failed to save bookmark!\n");
                    return;
                }
            }
        }
        else if ((target == SLOT_INTERNAL) ||
                 ((target != SLOT_EXTERNAL) && (tempo == 0x01)))
        {
            bookmark_info_t bookmark_info = {
                .volume = state.volume,
                .section = state.section_index,
                .book = state.book_index,
                .chapter = state.chapter_index,
                .sdcard = 1,
                .seektime = songseek,
                .total_sections = total_sections,
                .total_books = total_books,
                .total_chapters = total_chapters
            };

            bookmark_info2.sdcard = 1;
            bookmark_info2.volume = state.volume;
            bookmark_info2.seektime = songseek;
            bookmark_info2.total_sections = total_sections;
            bookmark_info2.total_books = total_books;
            bookmark_info2.total_chapters = total_chapters;

//            rt_kprintf("Saving bookmark internal: V=%d, S=%d, B=%d, C=%d SD=%d, cur_sec = %ld (target=%d, tempo=0x%02X)\n",
//                       bookmark_info.volume,
//                       bookmark_info.section,
//                       bookmark_info.book,
//                       bookmark_info.chapter,
//                       bookmark_info.sdcard,
//                       bookmark_info.seektime,
//                       target, tempo);

        bookmark_update_cache(total_sections, total_books,
                              total_chapters, bookmark_info.sdcard);
        if (save_bookmark_state(&bookmark_info, 0) != 0)
        {
//            rt_kprintf("Failed to save bookmark!\n");
            return;
        }

        if (poweroffflag)
        {
            if (save_bookmark_state(&bookmark_info2, 1) != 0)
            {
//                rt_kprintf("Failed to save bookmark!\n");
                return;
            }
        }
    }


}



void reset_current_bookmark(sd_slot_t target)
{
    // Hardcoded test bookmark values
    int b=0,c=0,d=0;
    b=rt_pin_read(SD1_SD2); // pe3
    c=rt_pin_read(internal_Mosfet);
    d=rt_pin_read(external_Mosfet);
    if ((state.volume < 0) || (state.volume > 105)){
        state.volume=50;
        songseek=0;
    }
    unsigned char tempo = (( b<<2) | (c<<1) | (d) );  // later state
    if((tempo == 0x06) || (target == SLOT_EXTERNAL)){
        //external
        bookmark_info_t bookmark_info2 = {
            .volume = 0,
            .section = 0,
            .book =0,
            .chapter = 0,
            .sdcard=6,
            .seektime= 0
        };

        bookmark_info.sdcard=6;
        bookmark_info.volume=state.volume;
        bookmark_info.seektime=0;

//        rt_kprintf("Saving bookmark external: V=%d, S=%d, B=%d, C=%d SD=%d, cur_sec = %ld\n",
//                   bookmark_info2.volume,
//                   bookmark_info2.section,
//                   bookmark_info2.book,
//                   bookmark_info2.chapter,bookmark_info2.sdcard,bookmark_info2.seektime);

        // Save the bookmark to slot 1
        if (save_bookmark_state(&bookmark_info2, 1) != 0)
        {
//            rt_kprintf("Failed to save bookmark!\n");
            return;
        }
        if(poweroffflag){
        if (save_bookmark_state(&bookmark_info, 0) != 0)
        {
//            rt_kprintf("Failed to save bookmark!\n");
            return;
        }
        }
    }
    else if((tempo == 0x01) || (target == SLOT_INTERNAL)){
        //internal
        bookmark_info_t bookmark_info = {
            .volume =0,
            .section = 0,
            .book = 0,
            .chapter = 0,
            .sdcard=1,
            .seektime=0
        };

        bookmark_info2.sdcard=1;
        bookmark_info2.volume=state.volume;
        bookmark_info2.seektime=0;

//        rt_kprintf("Saving bookmark internal: V=%d, S=%d, B=%d, C=%d SD=%d, cur_sec = %ld\n",
//                   bookmark_info.volume,
//                   bookmark_info.section,
//                   bookmark_info.book,
//                   bookmark_info.chapter,bookmark_info.sdcard,bookmark_info.seektime);

        // Save the bookmark to slot 0
        if (save_bookmark_state(&bookmark_info, 0) != 0)
        {
//            rt_kprintf("Failed to save bookmark!\n");
            return;
        }
        if(poweroffflag){
        if (save_bookmark_state(&bookmark_info2, 1) != 0)
        {
//            rt_kprintf("Failed to save bookmark!\n");
            return;
        }
        }
    }




    // Verify by reading and printing all slots
    test_flash_verify();
}

void load_last_bookmark(void)
{
    char section_path[128]; memset(section_path, 0, sizeof(section_path));
    char book_path[128];    memset(book_path, 0, sizeof(book_path));

    int total_sections = 0;
    int total_books = 0;
    int total_chapters = 0;

    bool sd_changed = false;

    if (load_bookmark_state(&bookmark_info, 0) != 0)
    {
//        rt_kprintf("Failed to load bookmark from flash\n");
        return;
    }

    total_sections = count_items(ROOT_PATH, 1);

    if (bookmark_info.section < total_sections)
    {
        state.section_index = bookmark_info.section;

        if (build_section_path(state.section_index, section_path, sizeof(section_path)) == 0)
            total_books = count_items(section_path, 1);
        else
            total_books = 0;

        if (bookmark_info.book < total_books)
        {
            state.book_index = bookmark_info.book;

            if (build_book_path(state.section_index, state.book_index, book_path, sizeof(book_path)) == 0)
                total_chapters = count_items(book_path, 0);
            else
                total_chapters = 0;

            if (bookmark_info.chapter < total_chapters)
                state.chapter_index = bookmark_info.chapter;
            else
                state.chapter_index = 0;
        }
        else
        {
            state.book_index = 0;
            state.chapter_index = 0;
            total_chapters = 0;
        }
    }
    else
    {
        state.section_index = 0;
        state.book_index = 0;
        state.chapter_index = 0;
        total_books = 0;
        total_chapters = 0;
    }

    if (bookmark_info.total_sections > 0 && bookmark_info.total_sections != total_sections)
        sd_changed = true;
    else if (bookmark_info.total_books > 0 && bookmark_info.total_books != total_books)
        sd_changed = true;
    else if (bookmark_info.total_chapters > 0 && bookmark_info.total_chapters != total_chapters)
        sd_changed = true;

    if (sd_changed)
    {
//        rt_kprintf("SD content changed -> Resetting bookmark\n");

        state.section_index = 0;
        state.book_index = 0;
        state.chapter_index = 0;
        bookmark_info.seektime = 0;
    }

    if ((bookmark_info.volume > 105) || (bookmark_info.volume <= 0))
    {
        bookmark_info.volume = 20;
        bookmark_info.seektime = 0;
    }

    state.volume = bookmark_info.volume;
    songseek = bookmark_info.seektime;

#ifdef EXTERNAL_START_SD
    if ((bookmark_info.sdcard != 0x06) && (bookmark_info.sdcard != 0x01))
    {
        bookmark_info.sdcard = 0x06;
//        rt_kprintf("external_sd_card\n");
    }
#else
    if ((bookmark_info.sdcard != 0x06) && (bookmark_info.sdcard != 0x01))
    {
        bookmark_info.sdcard = 0x01;
    }
#endif

//    rt_kprintf("Loaded bookmark internal: V=%d, S=%d, B=%d, C=%d SD=%d, cur_sec = %ld\n",
//               bookmark_info.volume,
//               state.section_index,
//               state.book_index,
//               state.chapter_index,
//               bookmark_info.sdcard,
//               bookmark_info.seektime);
}


void load_last_bookmark2(void)
{
    char section_path[128]; memset(section_path, 0, sizeof(section_path));
    char book_path[128];    memset(book_path, 0, sizeof(book_path));

    int total_sections = 0;
    int total_books = 0;
    int total_chapters = 0;

    bool sd_changed = false;

    if (load_bookmark_state(&bookmark_info2, 1) != 0)
    {
//        rt_kprintf("Failed to load bookmark from flash\n");
        return;
    }

    total_sections = count_items(ROOT_PATH, 1);

    if (bookmark_info2.section < total_sections)
    {
        state.section_index = bookmark_info2.section;

        if (build_section_path(state.section_index, section_path, sizeof(section_path)) == 0)
            total_books = count_items(section_path, 1);
        else
            total_books = 0;

        if (bookmark_info2.book < total_books)
        {
            state.book_index = bookmark_info2.book;

            if (build_book_path(state.section_index, state.book_index, book_path, sizeof(book_path)) == 0)
                total_chapters = count_items(book_path, 0);
            else
                total_chapters = 0;

            if (bookmark_info2.chapter < total_chapters)
                state.chapter_index = bookmark_info2.chapter;
            else
                state.chapter_index = 0;
        }
        else
        {
            state.book_index = 0;
            state.chapter_index = 0;
            total_chapters = 0;
        }
    }
    else
    {
        state.section_index = 0;
        state.book_index = 0;
        state.chapter_index = 0;
        total_books = 0;
        total_chapters = 0;
    }

    /* Only flag sd_changed if the stored counts are non-zero.
         * When the bookmark was saved during an eject (filesystem already
         * dead), count_items() returns 0 and those zeros are persisted.
         * Comparing 0 against the real card counts would always trigger a
         * false reset and wipe the valid S/B/C indices.
         * If stored counts are 0 it means the save happened under a filesystem
         * error — trust the S/B/C indices (they are bounds-checked below)
         * and skip the content-change reset. */
        if (bookmark_info2.total_sections > 0 && bookmark_info2.total_sections != total_sections)
            sd_changed = true;
        else if (bookmark_info2.total_books > 0 && bookmark_info2.total_books != total_books)
            sd_changed = true;
        else if (bookmark_info2.total_chapters > 0 && bookmark_info2.total_chapters != total_chapters)
            sd_changed = true;

        if (sd_changed)
        {
//            rt_kprintf("SD content changed -> Resetting external bookmark\n");

            state.section_index = 0;
            state.book_index = 0;
            state.chapter_index = 0;
            bookmark_info2.seektime = 0;
        }

    if ((bookmark_info2.volume > 105) || (bookmark_info2.volume <= 0))
    {
        bookmark_info2.volume = 20;
        bookmark_info2.seektime = 0;
    }

    state.volume = bookmark_info2.volume;
    songseek = bookmark_info2.seektime;

#ifdef EXTERNAL_START_SD
    if ((bookmark_info2.sdcard != 0x06) && (bookmark_info2.sdcard != 0x01))
    {
        bookmark_info2.sdcard = 0x06;
//        rt_kprintf("external_sd_card\n");
    }
#else
    if ((bookmark_info2.sdcard != 0x06) && (bookmark_info2.sdcard != 0x01))
    {
        bookmark_info2.sdcard = 0x01;
    }
#endif

//    rt_kprintf("Loaded bookmark external: V=%d, S=%d, B=%d, C=%d SD=%d, cur_sec = %ld\n",
//               bookmark_info2.volume,
//               state.section_index,
//               state.book_index,
//               state.chapter_index,
//               bookmark_info2.sdcard,
//               bookmark_info2.seektime);
}

//*****************************************************************************//



// *********************** Earphone + Speaker **********************************//

static audio_state_t Audio_state = {0};
static rt_mutex_t audio_state_mutex = RT_NULL;

static int init_audio_state(void)
{
    audio_state_mutex = rt_mutex_create("audio_mtx", RT_IPC_FLAG_FIFO);
    if (audio_state_mutex == RT_NULL) {
//        rt_kprintf("Failed to create audio state mutex\n");
        return -RT_ERROR;
    }
    return RT_EOK;
}

// Update speaker state based on audio state
void update_speaker(void)
{
    rt_mutex_take(audio_state_mutex, RT_WAITING_FOREVER);
    bool mute = Audio_state.pause_mode || Audio_state.earphone_inserted;
    rt_mutex_release(audio_state_mutex);

//    rt_kprintf("Speaker %s (Pause: %d, Earphone: %d)\n",
//              mute ? "MUTED" : "UNMUTED",
//              Audio_state.pause_mode,
//              Audio_state.earphone_inserted);

    rt_pin_write(AUDIO_SWITCH_PIN, Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);
}

void set_pause_mode(bool paused)
{
    rt_mutex_take(audio_state_mutex, RT_WAITING_FOREVER);
    Audio_state.pause_mode = paused;
    rt_mutex_release(audio_state_mutex);
    update_speaker();
}

//************************* SD Card Switching with Button Combination*************************//
// Keypad variables
#define ROWS 3
#define COLS 3
static int row_pins[ROWS];
static int col_pins[COLS];
static volatile bool keys_pressed[ROWS * COLS + 1] = {false}; // Keys 1-9
static volatile rt_tick_t key_press_time[ROWS * COLS + 1] = {0};

// sd_slot_t is initialised on the top

static volatile rt_uint8_t sd_mounted = 0;
static volatile sd_slot_t current_slot = SLOT_INTERNAL;
static volatile rt_uint8_t is_switching = 0;
static volatile bool combo_release_guard = false;
static const char* mount_candidates[] = {"sd0p0", "sd0p1", "sd0"};
#define SD_MOUNT_POINT "/"
// System states

const int combo_mask_1_7 = (1 << (1 - 1)) | (1 << (7 - 1));  // 0x041
const int combo_mask_3_9 = (1 << (3 - 1)) | (1 << (9 - 1));  // 0x104
const int combo_mask_1_3 = (1 << (1 - 1)) | (1 << (3 - 1));  // 0x005 S3+S4 NOTIFY

static const rt_tick_t DEBOUNCE_TIME = 50;    // ms
static const rt_tick_t COMBO_TIME = 500;      // ms for combination detection
bool is_in_pause_mode = false;

uint16_t key_mask = 0;  // 16 bits to hold 9 keys
uint16_t scan_keypad(void) {
    uint16_t key_mask = 0;

    for (int c = 0; c < COLS; c++) {
        /* Float ALL columns to break contention paths.
         * Without this, a non-scanned column driven HIGH feeds current
         * back through any pressed key that shares a row with the key
         * being scanned -- e.g. S3 (row0,col0) and S4 (row0,col2)
         * fight each other and only one bit appears in the mask. */
        for (int k = 0; k < COLS; k++)
            rt_pin_mode(col_pins[k], PIN_MODE_INPUT);

        /* Drive only the active column LOW, then wait for the line
         * to settle through the 10K row pull-ups before reading. */
        rt_pin_mode(col_pins[c], PIN_MODE_OUTPUT);
        rt_pin_write(col_pins[c], PIN_LOW);
        rt_hw_us_delay(20);          /* 20 µs -- safe for 10K + trace cap */

        for (int r = 0; r < ROWS; r++) {
            int pin_state = rt_pin_read(row_pins[r]);
            uint8_t key_num = r * COLS + c + 1;
            if (pin_state == PIN_LOW)
                key_mask |= (1 << (key_num - 1));
        }
    }

    /* Restore all columns to output HIGH (idle state) so the pin
     * modes are consistent between scans. */
    for (int k = 0; k < COLS; k++) {
        rt_pin_mode(col_pins[k], PIN_MODE_OUTPUT);
        rt_pin_write(col_pins[k], PIN_HIGH);
    }

    return key_mask;
}

static void update_key_states(uint16_t key_mask) {
    rt_tick_t current_time = rt_tick_get();

    for (int i = 1; i <= (ROWS * COLS); i++) {
        bool is_pressed = (key_mask & (1 << (i-1))) != 0;

        if (is_pressed && !keys_pressed[i]) {
            keys_pressed[i] = true;
            key_press_time[i] = current_time;
        } else if (!is_pressed && keys_pressed[i]) {
            keys_pressed[i] = false;
        }
    }
}
static void clear_combo_key_state(void)
{
    for (int i = 0; i < KEY_COUNT; i++)
    {
        keys[i].hold_start_time = 0;
        keys[i].long_press_active = false;
        keys[i].last_jump_time = 0;
    }

    for (int i = 0; i <= ROWS * COLS; i++)
    {
        keys_pressed[i] = false;
        key_press_time[i] = 0;
    }

    long_press_active = false;
    ff_rw_hold_active = false;
    hold_seek_wait_release = false;
    play_pending = false;
    hold_boundary_played = false;
    reached_limit = false;
}
extern void ab32_mmcsd_change(void);

static void slot_power_off_all(void) {

    rt_pin_write(internal_Mosfet, PIN_HIGH);
    rt_pin_write(external_Mosfet, PIN_HIGH);

}

static void slot_power_on(sd_slot_t slot) {
    if (slot == SLOT_INTERNAL)
        rt_pin_write(internal_Mosfet, PIN_LOW);
    else
        rt_pin_write(external_Mosfet, PIN_LOW);
}
static int do_mount(void) {
    for (size_t i = 0; i < sizeof(mount_candidates)/sizeof(mount_candidates[0]); i++) {
        if (dfs_mount(mount_candidates[i], SD_MOUNT_POINT, "elm", 0, 0) == RT_EOK) {
            return RT_EOK;
        }
    }
    return -RT_ERROR;
}



static int cleanup_filesystem(void)
{
    if (mp3_player_wait_closed(200) != RT_EOK)
    {
        rt_kprintf("Player still owns SD resources; unmount cancelled\n");
        return -RT_ETIMEOUT;
    }

    if (sd_mounted) {
        int result = dfs_unmount(SD_MOUNT_POINT);
        if (result != RT_EOK)
        {
            rt_kprintf("SD unmount failed: %d\n", result);
            return result;
        }
        sd_mounted = 0;
        rt_thread_mdelay(20);
    }

    return RT_EOK;
}

static void player_stop_and_wait_stopped(rt_int32_t timeout_ms)
{
    /* Request stop if not already stopped */
    if (mp3_player_state_get() != PLAYER_STATE_STOPED)
        mp3_player_stop();

    /* Wait until the player reports STOPPED (or timeout) */
    rt_tick_t deadline = rt_tick_get() + rt_tick_from_millisecond(timeout_ms);
    while (mp3_player_state_get() != PLAYER_STATE_STOPED)
    {
        if ((rt_tick_get() - deadline) > 0) break;
        rt_thread_mdelay(5);
    }
}

// int switch_mount_and_play(sd_slot_t target)
int switch_mount_and_play(sd_slot_t target, bool auto_play, bool source_lost)
{
//    if (target == SLOT_EXTERNAL)
//    {
//        rt_kprintf("External SD disabled\n");
//        return -RT_ERROR;
//    }
    if (is_switching) return -RT_EBUSY;
    is_switching = 1;
    sd_switch_in_progress = true;
    suppress_playback = true;
    autoplay_enabled = 0;
    (void)mp3_player_take_natural_end();

    block_autoplay = true;  //  play_current during switch
    rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);

    rt_kprintf("Switching to %s SD card...\n", target == SLOT_INTERNAL ? "INTERNAL" : "EXTERNAL");

    if (source_lost) {
            /* Source card has been physically removed.
             *
             * Two distinct hazards we MUST handle here:
             *
             *  (1) If the player was PLAYING, it is blocked inside fread() on the
             *      dead SD. After the SDIO 5s timeout, fread returns <= 0 and the
             *      player jumps to its __exit label WITHOUT processing MSG_STOP and
             *      WITHOUT acking, so mp3_player_stop()'s RT_WAITING_FOREVER would
             *      hang -> watchdog reboot.
             *
             *  (2) If the player was PAUSED, mp3_player_stop() returns as soon as
             *      MSG_STOP is acked, but acking happens BEFORE the player calls
             *      fclose(). If we unmount immediately, dfs_unmount frees the FS
             *      mutex while the player still holds a file handle into it, and
             *      the player's later fclose trips the rt_mutex_release assertion.
             *
             * Both hazards reduce to "don't unmount until the player has no open
             * file handle". The player publishes that via player.fp == NULL after
             * mp3_player_close(). We poll that flag with a bounded timeout, then
             * force-clear it ourselves if the player exited abnormally.
             */
            rt_kprintf("Source card lost - draining player\n");

            /* Kick the player so it leaves PAUSED state if it was paused.
             * For PLAYING state this is harmless (the player is blocked in fread
             * and will unblock on the SDIO timeout regardless). */
            if (mp3_player_state_get() == PLAYER_STATE_PAUSED) {
                        /* Inline equivalent of the player's static play_msg_send().
                         * struct play_msg, MSG_STOP, and `player` are all public via
                         * mp3_player.h, so we can post directly to player.mq. */
                        struct play_msg msg = { .type = MSG_STOP, .data = RT_NULL };
                        (void)rt_mq_send(player.mq, &msg, sizeof(msg));
                    }

            /* Wait up to ~6s for the player to release its file handle.
             * 5s covers the worst-case SDIO timeout, plus a margin for fclose. */
            rt_tick_t deadline = rt_tick_get() + rt_tick_from_millisecond(6000);
            while (player.fp != RT_NULL) {
                if ((rt_int32_t)(rt_tick_get() - deadline) >= 0) {
                    rt_kprintf("Player did not release fp in time - forcing\n");
                    break;
                }
                rt_thread_mdelay(20);
            }

            /* If the player bailed via __exit without closing (PLAYING-on-eject
             * case), close the leaked handle now, before any dfs_unmount touches
             * the FS mutexes. fclose on a dead card may itself fail, but it MUST
             * happen with the FS still mounted so the mutex is still alive. */
            if (player.fp != RT_NULL) {
                rt_kprintf("Player did not release fp - aborting switch safely\n");

                is_switching = 0;
                block_autoplay = false;
                suppress_playback = false;
                sd_switch_in_progress = false;

                return -RT_ETIMEOUT;
            }

            /* Mark state stopped so subsequent code doesn't try to pause/resume. */
            player.state = PLAYER_STATE_STOPED;

            rt_kprintf("Source card lost - skipping bookmark save\n");

            /* Now safe to detach the dead filesystem. */
            if (sd_mounted) {
                dfs_unmount(SD_MOUNT_POINT);
                sd_mounted = 0;
            }
    } else {
                /* Capture seek position before stopping the player, so the
                 * bookmark saved below has a fresh seektime regardless of
                 * whether the caller already called pause/save or not. */
                uint32_t cur_sec = mp3_get_cur_seconds();
                if (cur_sec > 0)
                    songseek = cur_sec;

                if (mp3_player_stop() != RT_EOK)
                {
                    rt_kprintf("SD switch aborted: player close timeout\n");
                    is_switching = 0;
                    block_autoplay = false;
                    suppress_playback = false;
                    sd_switch_in_progress = false;
                    return -RT_ETIMEOUT;
                }

                save_current_bookmark(current_slot);

                if (cleanup_filesystem() != RT_EOK)
                {
                    rt_kprintf("SD switch aborted: filesystem still busy\n");
                    is_switching = 0;
                    block_autoplay = false;
                    suppress_playback = false;
                    sd_switch_in_progress = false;
                    return -RT_EBUSY;
                }
            }


    // Hardware switching
    slot_power_off_all();
    rt_thread_mdelay(10);
    rt_pin_write(GL_Soc, PIN_HIGH);
    rt_kprintf("sd card cleaning %d\n",target);
    rt_pin_write(SD1_SD2, (target == SLOT_INTERNAL) ? PIN_LOW : PIN_HIGH);
    rt_thread_mdelay(3);
    slot_power_on(target);
//    if((current_mode == 3) || (current_mode == 2)){
//
//        current_mode=1;
//        update_led_color();
//        rt_kprintf("LED COLOR UPDATED = %d %d\n",current_mode,sd_det_flag);
//
//    }

    rt_thread_mdelay(10);


    int mount_success = 0;
    for (int i = 0; i < 5; i++) {
        ab32_mmcsd_change();
        rt_thread_mdelay(100 + i * 50);

        if (do_mount() == RT_EOK) {
            mount_success = 1;
            break;
        }
    }

    if (!mount_success) {
        slot_power_off_all();
        rt_thread_mdelay(100);
        slot_power_on(target);
        rt_thread_mdelay(300);
        ab32_mmcsd_change();
        rt_thread_mdelay(300);

        if (do_mount() != RT_EOK) {
//            rt_kprintf("SD card mount failed after all attempts!\n");
            play_beep();
//            rt_pin_write(AUDIO_SWITCH_PIN,PIN_LOW);
//            play_5_beep();
//            rt_pin_write(AUDIO_SWITCH_PIN,PIN_HIGH);

            is_switching = 0;
            block_autoplay = false;  // Unlock autoplay before exit
            suppress_playback = false;
            sd_switch_in_progress = false;
            return -RT_ERROR;
        }
        mount_success = 1;
    }

    if (mount_success) {
            sd_mounted = 1;
            current_slot = target;
            /* Keep sd_det_flag aligned with the slot we just mounted, so the
             * LED thread (and any update_led_color() caller) shows green for
             * INTERNAL / red for EXTERNAL. Otherwise this gets out of sync
             * after switches that don't go through the manual key-combo path. */
            sd_det_flag = (target == SLOT_INTERNAL) ? 0 : 1;
            /* Discard any cached directory entry from the old SD card so the
             * first get_nth_file() call on the new card does a clean scan. */
            get_nth_file_invalidate_cache();
            nav_cache_invalidate();
//            rt_kprintf("SD card mounted successfully\n");
            current_mode = LED_MODE_SOLID;
            update_led_color();

        /* Reset indices and load the target slot's bookmark so state.*
         * matches what is actually on this card before play_current() runs.
         * Without this, stale indices from the previous slot make the player
         * open non-existent paths and the watchdog resets the device. */
        state.section_index = 0;
        state.book_index    = 0;
        state.chapter_index = 0;
        nav_cache_invalidate();

        if (current_slot == SLOT_INTERNAL) {
            load_last_bookmark();
        } else {
            load_last_bookmark2();
        }

//        if (dynamic_array_init(&sections) != RT_EOK ||
//            dynamic_array_init(&books) != RT_EOK ||
//            dynamic_array_init(&chapters) != RT_EOK) {
//            rt_kprintf("Failed to initialize dynamic arrays\n");
//            is_switching = 0;
//            block_autoplay = false;
//            return -RT_ERROR;
//        }

//        if (scan_sections() <= 0) {
//            rt_kprintf("No sections found after SD switch!\n");
////            rt_pin_write(AUDIO_SWITCH_PIN,PIN_LOW);
////            play_5_beep();
//            is_switching = 0;
//            block_autoplay = false;
//            return -RT_ERROR;
//        }
//
//        state.section_index = 0;
//        state.book_index = 0;
//        state.chapter_index = 0;
//
//        scan_books();
//        scan_chapters();
//        if(current_slot==0){
//            load_last_bookmark();
//        }
//        else{
//            load_last_bookmark2();
//        }

        // Enforce pause

        if((current_mode == 3) || (current_mode == 2)){

            current_mode=1;
            update_led_color();
//            rt_kprintf("LED COLOR UPDATED = %d %d\n",current_mode,sd_det_flag);

        }
        rt_pin_write(AUDIO_SWITCH_PIN, PIN_LOW);
//        play_triple_beep();
//        rt_thread_mdelay(50);
//        if (!g_in_switch) {
//            play_triple_beep_no_led();
//            rt_thread_mdelay(50);
//        }
        /* For source_lost (SD-eject) switches the PAUSE state was set
         * immediately at the ejection site and must stay on until just
         * before play_current() fires.  Only clear it for normal
         * (non-eject) slot switches. */
        if (!source_lost) {
            pause_mode_active = false;    // clear pause mode
            set_pause_mode(false);        // Unmute speaker if needed
        }
        autoplay_enabled = 1;         // Allow autoplay
        block_autoplay = false;
//        is_switching = 0;



//        play_current();               // <<< Start playback from new SD

        block_autoplay = false;  // Allow play_current again
        suppress_playback = false;
        sd_switch_in_progress = false;
        is_switching = 0;
        if (auto_play)
        {
            autoplay_enabled = 1;

            /* When switching due to SD card removal (source_lost=true), briefly
             * enter PAUSE state before starting playback on the new card.
             * This gives a visible PAUSE -> PLAY transition instead of jumping
             * directly from external to internal playback.
             *
             * NOTE: pause_mode_activate() is NOT called here because the player
             * is already STOPPED at this point (drained in the source_lost block
             * above), so there is no need for the blocking mp3_player_pause().
             * We simply set the flag and update the LED directly. */
            if (source_lost)
            {
                /* pause_mode_active is already true (set at the ejection site).
                 * Hold the pause state for a brief moment so the user can
                 * perceive the transition before playback starts on internal. */
//                rt_kprintf("source_lost switch: PAUSE mode active, brief hold before auto-play\n");
                rt_thread_mdelay(300);        /* brief pause before playing    */
                pause_mode_active = false;
                set_pause_mode(false);        /* unmute speaker                */
//                rt_kprintf("source_lost switch: starting internal playback\n");
            }

            /* If there is a saved bookmark position, prime start_offset_seconds
             * before play_current() sends MSG_START.  The player thread reads
             * it after fopen()+mp3_get_info() and seeks in one shot — no second
             * stop/reopen/seek cycle needed.  play_current() still resolves the
             * file path via the nav cache; the seek happens transparently inside
             * the player thread before the first fread(). */
            /* Save bookmark position but do NOT prime start_offset_seconds.
             * Instead, start playing from 0 so the player opens the file and
             * populates mp3_info.total_seconds before we decide whether it is
             * safe to seek.  VBR files without a Xing header report total_seconds=0
             * when queried before the file is open, causing the old approach to
             * miss the near-EOF check entirely. */
            uint32_t primed_seek = songseek;
            songseek = 0;

            block_autoplay = true;
            play_current();   /* starts from position 0 */

            if (primed_seek > 0)
            {
                /* Wait for the player to open the file — total_seconds is only
                 * valid once PLAYER_STATE_PLAYING is reached. */
                for (int _i = 0; _i < 20; _i++)   /* up to 1 s */
                {
                    rt_thread_mdelay(50);
                    if (mp3_player_state_get() == PLAYER_STATE_PLAYING)
                        break;
                }

                if (mp3_player_state_get() == PLAYER_STATE_PLAYING)
                {
                    uint32_t total = player.mp3_info.total_seconds;
                    /* Seek to bookmark only if enough file remains.
                     * If total==0 (VBR, no header) or seektime is within
                     * CHAPTER_REWIND_THRESHOLD of EOF, stay at 0 — safer
                     * than risking a 1-second play and an unwanted next_chapter(). */
                    if (total > 0 && primed_seek + CHAPTER_REWIND_THRESHOLD < total)
                    {
                        mp3_player_pause();
                        rt_thread_mdelay(20);
                        mp3_seek(primed_seek);
                        player.paused_position = ftell(player.fp);
                        player.decode_oper.bytes_left = 0;
                        mp3_player_resume();
                    }
                    /* else: total==0 or near EOF → already playing from 0, do nothing */
                }
            }

            block_autoplay = false;

            if (mp3_player_state_get() == PLAYER_STATE_PLAYING)
            {
                current_mode = LED_MODE_SOLID;
                pause_mode_active = false;
                update_led_color();
            }
        }
        else
        {
            autoplay_enabled = 0;
            pause_mode_active = true;
            mp3_player_stop();
            current_mode = LED_MODE_PAUSE;
            update_led_color();
        }

//        rt_kprintf("Auto-play started after SD switch. %d\n",current_mode);
    }


      return RT_EOK;
  }




//void handle_combinations(uint16_t key_mask)
//{
//    static rt_tick_t last_combo_time = 0;
//    rt_tick_t current_time = rt_tick_get();
//
//    if (!pause_mode_active) return;
//
//    if ((current_time - last_combo_time) > COMBO_TIME) {
//        if ((key_mask & combo_mask_1_7) == combo_mask_1_7) {
//            rt_kprintf("Combo 1+7 detected - Switching to INTERNAL SD\n");
//            mp3_player_pause();
//            switch_mount_and_play(SLOT_INTERNAL);
//            sd_det_flag = false;
//            update_led_color();
//
//
//            last_combo_time = current_time;
//
//
//        } else if ((key_mask & combo_mask_3_9) == combo_mask_3_9) {
//            rt_kprintf("Combo 3+9 detected - Switching to EXTERNAL SD\n");
//            mp3_player_pause();
//            sd_det_flag = true;
//            update_led_color();
//
//            switch_mount_and_play(SLOT_EXTERNAL);
//            last_combo_time = current_time;
//
//        }
//    }
//}


 void handle_combinations(uint16_t key_mask)
 {
     static rt_tick_t last_combo_time = 0;
     rt_tick_t current_time = rt_tick_get();

     if (!pause_mode_active)
         return;

     if ((current_time - last_combo_time) <= COMBO_TIME)
         return;
     if ((key_mask & combo_mask_1_3) == combo_mask_1_3)
       {
           combo_release_guard = true;
//           rt_kprintf("Combo 1+3 (S3+S4) detected - playing notify clip\n");
           play_notify_clip();
           last_combo_time = current_time;
           return;
       }

     /* INTERNAL combo */
     if ((key_mask & combo_mask_1_7) == combo_mask_1_7)
     {
         if (current_slot == SLOT_INTERNAL) {
             // Same SD + paused -> do nothing
             return;
         }

         combo_release_guard = true;
//         rt_kprintf("Combo 1+7 detected - Switching to INTERNAL SD\n");
         mp3_player_pause();
         /* Only enable speaker if no earphone; earphone path stays active */
         rt_pin_write(AUDIO_SWITCH_PIN, Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);
         play_beep_no_led();
         beep_wait_done();
         rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);
         //         save_current_bookmark(current_slot);   // removed - switch_mount_and_play does the save
         switch_mount_and_play(SLOT_INTERNAL, true, false);

         sd_det_flag = false;
         update_led_color();
         last_combo_time = current_time;
     }

     /* EXTERNAL combo */
     else if ((key_mask & combo_mask_3_9) == combo_mask_3_9)
     {
         if (current_slot == SLOT_EXTERNAL) {
             // Same SD + paused -> do nothing
             return;
         }
         rt_pin_mode(SD_EXT, PIN_MODE_INPUT_PULLUP);
                  if (rt_pin_read(SD_EXT) == PIN_HIGH) {
//                      rt_kprintf("Combo 3+9: no external SD present — staying on current slot.\n");
                      return;
                  }

         combo_release_guard = true;
//         rt_kprintf("Combo 3+9 detected - Switching to EXTERNAL SD\n");
         mp3_player_pause();
         sd_det_flag = true;
         update_led_color();
         /* Only enable speaker if no earphone; earphone path stays active */
         rt_pin_write(AUDIO_SWITCH_PIN, Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);
         play_beep_no_led();
         beep_wait_done();
         rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);
         //         save_current_bookmark(current_slot);   // removed - switch_mount_and_play does the save
         //         reset_current_bookmark(1);
         switch_mount_and_play(SLOT_EXTERNAL, true, false);

//         reset_current_bookmark(1);
         last_combo_time = current_time;
     }
 }

//************************************************************************************//


bool in_pause_mode;
void button_play_pause(void)
{


    if (mp3_player_state_get() == PLAYER_STATE_PLAYING)
        {
            start_5min_timer();
            rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);
//            rt_kprintf("Pausing playback\n");
             update_led_color();          // Update LED immediately
             rt_thread_mdelay(50);
             mp3_player_pause();          // Pause playback
             pause_mode_active = true;

             /* Persist current position for the active storage source so that
              * any subsequent SD removal or manual SD switch has a fresh seektime
              * to restore from. */
             uint32_t cur_sec = mp3_get_cur_seconds();
             if (cur_sec > 0)
                 songseek = cur_sec;
             /* Do NOT call save_current_bookmark() here: it calls fal_partition_erase()
              * which stalls the SPI flash bus. Any IRQ whose handler lives in flash will
              * fault during that window (IRQ in Flash: 1 0 - ...).
              * Defer to the keypad thread main loop where flash writes are safe. */
             bookmark_save_pending = true;

             start_task(LED_MODE_PAUSE);  //  Start LED blinking in PAUSE mode
        }
    else if (mp3_player_state_get() == PLAYER_STATE_PAUSED)
    {
        stopwatchflag=false;
//        rt_pin_write(AUDIO_SWITCH_PIN, PIN_LOW);
        rt_pin_write(AUDIO_SWITCH_PIN, Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);

//        rt_kprintf("Resuming playback\n");
        stop_timer();
        stop_task();                 // Stop LED blinking
        rt_thread_mdelay(10);
        update_led_color();         // Update LED immediately
        rt_thread_mdelay(80);
        mp3_player_resume();        // Resume playback
        pause_mode_active = false;
    }
    else if (mp3_player_state_get() == PLAYER_STATE_STOPED)
    {

        dac_start();
        uint32_t timestamp=0;
        int cat = rt_pin_read(CABLE_PIN);

        rt_pin_write(AUDIO_SWITCH_PIN, Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);


            if((firston == true ) || cat == PIN_LOW){
                cableplay=true;
                if (current_slot == SLOT_EXTERNAL) {
                               load_last_bookmark2();
                               timestamp = bookmark_info2.seektime;
                           }
                           else {
                               load_last_bookmark();
                               timestamp = bookmark_info.seektime;
                           }
                mp3_player_volume_set(state.volume);


//                rt_kprintf("Starting playback volume = %d\n",state.volume);
                static bool tp=false;
                if(tp == false){
                    tp=true;
//                    rt_thread_mdelay(100);

//                    play_beep_with_volume(state.volume);
                    mp3_player_volume_set(BEEP_NOTIFY_HW_VOL);
                    play_beep_with_volume_no_led(30);
                    beep_wait_done();
                    mp3_player_volume_set(state.volume);
//                    rt_thread_mdelay(1000);
                }
                if( timestamp > 0){


                    play_current();

                    rt_thread_mdelay(20);
                    mp3_player_pause();
                    mp3_seek(timestamp);
                    player.paused_position = ftell(player.fp);   // so resume won't undo the seek
                    player.decode_oper.bytes_left = 0;
                    mp3_player_resume();
                    mp3_disp_time();




                }
                else{
                    play_current();
                }



            }

    }
}

static uint8_t Play_button_read_pin(void)
{
    return rt_pin_read(power_play);
}

static uint8_t SD_BUTTON_READ_PIN(void){
    return rt_pin_read(SD_EXT);
}

// Power management callback

static volatile int wakup=0;


// Power management callback

static void wakeup_callback(void *args)
{
//    rt_kprintf("wakeup_callback\n");
    LPMCON = 0x00;
//    rt_kprintf("Hello system woke up\n");
//    rt_kprintf("WKUPCPND = 0x%08x\n", WKUPCPND);  // Read here
//    rt_hw_board_init();


//    keypad_matrix_init();
    WKUPCPND |= (1 << 3);// Clear again just in case
    rt_pin_irq_enable(power_play, PIN_IRQ_DISABLE);
    rt_pin_detach_irq(power_play);
   // exitSleepMode();


    // function which will resume all the mutex and semaphores

}


// Wakeup initialization
static void wakeup_init(void)
{

    // Set PB3 as input pull-up
    // Enable wakeup source PB3
    WKUPCON |= (1 << 3);     // Enable PB3 wakeup
    WKUPCON |= (1 << 16);             // Global wakeup enable

    // Falling edge trigger
    WKUPEDG |= (1 << 3);

    // Clear any previous wakeup flag (MUST use = not |=)
    WKUPCPND = (1 << 3);
}


bool cable_BTN_flag = false;
bool btn_flag = false;

void device_stop(){
    //power off device
    //prepareSleepMode();
    //button_play_pause();
    /* Mute speaker only if no earphone; if earphone inserted, keep speaker off */
    rt_pin_write(AUDIO_SWITCH_PIN, Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);
    poweroffflag=true;

    songseek = mp3_get_cur_seconds();
        int slots = rt_pin_read(external_Mosfet);
        if (slots == PIN_LOW)
            current_slot = SLOT_EXTERNAL;
        else
            current_slot = SLOT_INTERNAL;
        if (rt_pin_read(CABLE_PIN) == PIN_HIGH)
        {
            charging = 1;
            Playoffcharge = 0;      // device off + charger connected
            ledflag = true;         // keep LED blinking active
            current_mode = LED_MODE_CHARGE;
        }
        else
        {
            charging = 0;
            Playoffcharge = 0;
            /* LED stays ON until after beep — turned off below */
        }
    mp3_player_stop();
    rt_thread_mdelay(20);

    save_current_bookmark(current_slot);
//    rt_kprintf("BOOKMARK SAVED\n");

    play_double_beep_no_led();   /* beep while LED is still visible */
    beep_wait_done();

    if (!charging)               /* NOW turn off LED — after beep finishes */
    {
        ledflag = false;
        stop_task();
        led_OFF();
    }
    rt_thread_mdelay(20);
    rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);  /* mute speaker (powering off) */
    dac_stop();
//    rt_kprintf("PB.3 long press -> PE.6 LOW (permanent)\n");
    rt_thread_mdelay(10);
    if (rt_pin_read(CABLE_PIN) == PIN_LOW)
    {
    rt_enter_critical();
    rt_pin_write(PE6_PIN, PIN_LOW);
    rt_exit_critical();
    while (1)
    {
        ;
    }
    }
    //power off
}
//void device_stop(void)
//{
//    rt_pin_write(AUDIO_SWITCH_PIN, PIN_LOW);
//    poweroffflag = true;
//
//    songseek = mp3_get_cur_seconds();
//
//    int slots = rt_pin_read(external_Mosfet);
//    current_slot = (slots == 0) ? SLOT_EXTERNAL : SLOT_INTERNAL;
//
//    ledflag = false;
//    stop_task();
//
//    /* stop audio/player first */
//    mp3_player_stop();
//    rt_thread_mdelay(50);
//
//    /* then save bookmark */
//    save_current_bookmark(current_slot);
//    rt_kprintf("BOOKMARK SAVED\n");
//
//    play_double_beep_no_led();
//    rt_thread_mdelay(80);
//
//    rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);
//    rt_pin_write(PE6_PIN, PIN_LOW);
//}

void play_pause_callback(void* p)
{
    uint32_t btn_event;
    int playerstate=100;
    static int var=0;
    int cat = rt_pin_read(CABLE_PIN);
    if((var == 0) && (cat == PIN_HIGH)){
        var=1;
        btn_event=3;
//        rt_kprintf("singlepress\n");
    }
    else{
    btn_event = get_button_event((struct button *) p);
//    rt_kprintf("press\n");
    var=1;
    }

    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);
    rt_pin_write(Red_led, PIN_HIGH);
    static int once=0;
    static int twice=0;
    static int thrice=0;
    static int four=0;
    switch (btn_event)
    {
    case SINGLE_CLICK:
//        rt_kprintf("playing************************\n");
        four=1;
        int current_state1 = rt_pin_read(PE6_PIN);
        int current_state2 = rt_pin_read(CABLE_PIN);
        if(current_state2 && !cable_charge_only){
//            rt_kprintf("single click start cable status %d\n",current_state2);
            thrice=1; // first on
            ledflag=true; // led light
            typec=true;
            Playoffcharge=0;
            charging=1;
            battery_full=0;
            cable_BTN_flag=true;
            rt_thread_mdelay(30);
            HandShake_setup();
        }
        else if(current_state2 && cable_charge_only){
//            rt_kprintf("single click in charge-only mode - skipping HandShake_setup\n");
            typec=true;
            Playoffcharge=0;
            charging=1;
            battery_full=0;
        }

        button_play_pause();
        pause_mode_active = (mp3_player_state_get() == PLAYER_STATE_PAUSED);
        cable_BTN_flag = pause_mode_active;
        if (pause_mode_active) Playoffcharge = 1;

        if( (current_state1 == PIN_HIGH && (thrice == 0)))
        {

//            rt_kprintf("PB.3 single press -> PE.6 LOW (permanent) %d\n",thrice);

            if (rt_pin_read(CABLE_PIN) == PIN_LOW)
            {
            rt_pin_write(PE6_PIN, PIN_LOW);
            }
            return;

            //power off
        }


        break;

    case LONG_PRESS_HOLD:
        if (rt_pin_read(CABLE_PIN) == PIN_HIGH)
        {
            /* Cable connected.
             * If in GLIC mode (stopped, cable inserted while device was off):
             * 2-sec press → start playback from internal SD.
             * If already playing/paused (cable_charge_only==true): do nothing. */
            if (!cable_charge_only &&
                mp3_player_state_get() == PLAYER_STATE_STOPED &&
                twice == 0)
            {
                ledflag       = true;
                Playoffcharge = 1;
                twice         = 1;   /* arm power-off for next long-press */
                thrice        = 1;

                rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
                rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);
                update_led_color();

                /* cable-removal uses charge-only teardown — no GLIC remount */
                cable_charge_only = true;

                rt_pin_write(GL_Soc, PIN_HIGH);   /* park GL823K, SD back to SOC */
                dac_start();
                rt_pin_write(AUDIO_SWITCH_PIN,
                             Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);
                mp3_player_volume_set(BEEP_NOTIFY_HW_VOL);
                play_beep_with_volume_no_led(30);
                beep_wait_done();
                switch_mount_and_play(SLOT_INTERNAL, true, false);
                four++;
            }
            return;
        }


        ledflag       = true;
        Playoffcharge = 1;
        thrice        = 1;
        rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
        rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);
        update_led_color();

        if (twice == 0 && mp3_player_state_get() == PLAYER_STATE_STOPED)
        {
            /* Fresh boot, not yet started: first long-press starts playback.
             * A subsequent long-press will then power off. */
            rt_pin_write(PE6_PIN, PIN_HIGH);
            twice = 1;
            button_play_pause();
            four++;
            return;
        }

        /* Playing or paused: power off immediately on the first long-press.
         * No second fire needed — device_stop() handles stop + save + beep. */
        {
            static rt_tick_t last_poweroff_tick = 0;
            rt_tick_t now_tick = rt_tick_get();

            if (last_poweroff_tick != 0 &&
                (rt_int32_t)(now_tick - last_poweroff_tick) <
                (rt_int32_t)rt_tick_from_millisecond(3000))
            {
                return;   /* re-entry guard (if device_stop returned, e.g. cable in) */
            }

            if (four > 0 && rt_pin_read(PE6_PIN) == PIN_HIGH)
            {
                twice = 1;
                last_poweroff_tick = now_tick;
                device_stop();
            }
        }

    }
}



//
//void stopwatchfunc(){
//    int current_state = rt_pin_read(PE6_PIN);
//    if(current_state == PIN_HIGH)
//    {
//        //button_play_pause();
//        poweroffflag=true;
//        int slots= rt_pin_read(external_Mosfet);
//        if(slots == 0){
//            current_slot=SLOT_EXTERNAL;
//        }
//        else{
//            current_slot=SLOT_INTERNAL;
//        }
//        rt_enter_critical();
//
//        rt_pin_write(AUDIO_SWITCH_PIN, PIN_LOW);
//
//        save_current_bookmark(current_slot);
//        //load_last_bookmark();
//        rt_exit_critical();
//
//        mp3_player_stop();
////        rt_thread_mdelay(500);
//        rt_kprintf("BOOKMARK SAVED\n");
//        //volume_up();
////        mp3_player_stop();
//        play_double_beep();
////        mp3_player_stop();
//        rt_thread_mdelay(300);
////        rt_exit_critical();
////        rt_kprintf("PB.3 long press -> PE.6 LOW (permanent)\n");
////        poweroff_in_progress = RT_FALSE;
//        rt_pin_write(PE6_PIN, PIN_LOW);
//        //power off
//    }
//}




void stopwatchfunc()
{
    /* Only shutdown if player is PAUSED */
    if (mp3_player_state_get() != PLAYER_STATE_PAUSED)
    {
        return;   // Ignore if playing
    }
    /* Block auto-shutoff when the charging cable is connected */
     if (rt_pin_read(CABLE_PIN) == PIN_HIGH)
     {
//         rt_kprintf("Auto-shutoff blocked: cable connected\n");
         return;
     }

    int current_state = rt_pin_read(PE6_PIN);

    if(current_state == PIN_HIGH)
    {
        poweroffflag = true;

        int slots = rt_pin_read(external_Mosfet);
        if(slots == 0)
            current_slot = SLOT_EXTERNAL;
        else
            current_slot = SLOT_INTERNAL;

        rt_enter_critical();
        /* Only enable speaker if no earphone; earphone path stays active */
        rt_pin_write(AUDIO_SWITCH_PIN, Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);
        rt_exit_critical();

        save_current_bookmark(current_slot);

        mp3_player_stop();
//        rt_kprintf("BOOKMARK SAVED\n");

        play_double_beep_no_led();
        beep_wait_done();
        rt_thread_mdelay(300);

        rt_pin_write(AUDIO_SWITCH_PIN, PIN_HIGH);  /* mute speaker (powering off) */
        rt_pin_write(PE6_PIN, PIN_LOW);
    }
}

void prepareSleepMode()
{
    mp3_player_stop();
    if (scan_mutex != RT_NULL)
    {
//        rt_mutex_release(scan_mutex);
        rt_mutex_delete(scan_mutex);
        scan_mutex = RT_NULL;
    }
    if (audio_state_mutex != RT_NULL)
    {
//        rt_mutex_release(audio_state_mutex);
        rt_mutex_delete(audio_state_mutex);
        audio_state_mutex = RT_NULL;
    }
//    cable_detect_deinit();
//    handshake_deinit();

}

void exitSleepMode()
{
    // 1. Re-create mutexes
    scan_mutex = rt_mutex_create("key_mtx", RT_IPC_FLAG_FIFO);
    if (scan_mutex == RT_NULL) {
//        rt_kprintf("Failed to create scan mutex\n");
        return;
    }

    audio_state_mutex = rt_mutex_create("audio_mtx", RT_IPC_FLAG_FIFO);
    if (audio_state_mutex == RT_NULL) {
//        rt_kprintf("Failed to create audio state mutex\n");
        rt_mutex_delete(scan_mutex);
        return;
    }

    // 2. Re-init dynamic arrays
//    if (dynamic_array_init(&sections) != RT_EOK ||
//        dynamic_array_init(&books) != RT_EOK ||
//        dynamic_array_init(&chapters) != RT_EOK)
//    {
//        rt_kprintf("Failed to initialize dynamic arrays\n");
//        return;
//    }

    // 3. Scan filesystem
//    if (scan_sections() <= 0) {
//        rt_kprintf("No sections found!\n");
//        return;
//    }

//    if (scan_books() <= 0) {
//        rt_kprintf("No books found!\n");
//        return;
//    }

//    if (scan_chapters() <= 0) {
//        rt_kprintf("No chapters found!\n");
//        return;
//    }

    // 4. Load bookmark AFTER scan (so arrays are valid)
    load_last_bookmark();

    // 5. Resume playback
    play_current();
}




static void button_callback(void *btn)
{
    if (combo_release_guard)
       {
           return;
       }
    if (charging && mp3_player_state_get() == PLAYER_STATE_STOPED)
    {
//        rt_kprintf("button_callback: ignored, device in power-off charging mode\n");
        return;
    }

    struct key_button *key_btn = (struct key_button *) btn;
    rt_tick_t now = rt_tick_get();
    rt_tick_t debounce_time = rt_tick_from_millisecond(DEBOUNCE_DELAY_MS);
    rt_tick_t long_press_time = rt_tick_from_millisecond(LONG_PRESS_TIME_MS);



    btn_event_val = get_button_event(&key_btn->btn);
    if(!pause_mode_active){
    update_led_color();
    }
    // Debounce check
    if (now - key_btn->last_press < debounce_time)
        return;


    uint32_t btn_event;
   // int playerstate=100;
    btn_event = get_button_event((struct button *) btn);


    // Special handling for button index 2 when cable_BTN_flag is true
//    if (key_btn->index == 2 && cable_BTN_flag && (typec) )
//    {
//        //rt_thread_mdelay(10);
//        rt_kprintf("external SDCRD DETECT WTIH sls");
//        btn_flag = true;
//        sdswitch=false;
//        static int tap=0;
//        if(tap==0){
//            sid=true;
//        }
////        button_plus_cable();
//        static int press1=0;
//        rt_kprintf("key_btn->index == 2 %d %d\n",cable_BTN_flag,sdswitch);
//        if(((key_btn->index == 2) && (cable_BTN_flag) )  || (sdswitch==1)){
//            //rt_kprintf("SOC Ready to connect\n");
//            rt_kprintf("EXTERNAL %d %d\n",sdswitch,cable_BTN_flag);
//          //  switch_mount_and_play(SLOT_EXTERNAL);
//            slot_power_off_all();
//            rt_thread_mdelay(20);
//          //  rt_pin_write(GL_Soc, PIN_LOW);
//            rt_pin_write(SD1_SD2, PIN_HIGH);
//            rt_thread_mdelay(5);
//            slot_power_on(1);
//            rt_thread_mdelay(50);
//            sdswitch=false;
//            a=rt_pin_read(GL_Soc); // pe5
//            b=rt_pin_read(SD1_SD2); // pe3
//            c=rt_pin_read(internal_Mosfet);
//            d=rt_pin_read(external_Mosfet);
//            rt_kprintf("sls sd switch = %d %d %d %d\n",a,b,c,d);
//
//
//        }
//        key_btn->last_press = now;
//        return;
//    }
    if(key_btn->index == 0 && cable_BTN_flag && sdswitch)

    {
       // rt_pin_write(GL_Soc, PIN_LOW);
       // rt_kprintf("GL_ic Ready to connect\n");
    }


    switch (btn_event_val)
    {
    case PRESS_DOWN:
        key_btn->hold_start_time = now;
        key_btn->last_jump_time  = 0;
        reached_limit = false;
        hold_boundary_played = false;
        hold_seek_wait_release = false;
        break;

    case PRESS_UP:
    {
        rt_tick_t press_duration = now - key_btn->hold_start_time;


        // Only process short presses for button 2 in pause mode
//        if (pause_mode_active && key_btn->index == 2 && !key_btn->long_press_active && press_duration < long_press_time)
//        {
//            rt_kprintf("key_btn->index == 2 \n");
//        }
        // Normal operation for all buttons when not in pause mode
//         if (!pause_mode_active && !key_btn->long_press_active && press_duration < long_press_time)
//        {
//            switch (key_btn->index)
//            {
//            case 0: prev_section(); break;
//            case 1: prev_book(); break;
//            case 2: prev_chapter(); break;
//            case 3: /* play_pause(); */ break;
//            case 4: volume_up(); break;
//            case 5: volume_down(); break;
//            case 6: next_section(); break;
//            case 7: next_book(); break;
//            case 8: next_chapter(); break;
//            default:
//                rt_kprintf("Unknown button index: %d\n", key_btn->index);
//                break;
//            }
//        }
        if (pause_mode_active &&
             press_duration >= long_press_time &&
             (key_btn->index == 0 ||   /* prev section */
              key_btn->index == 1 ||   /* prev book    */
              key_btn->index == 6 ||   /* next section */
              key_btn->index == 7))    /* next book    */
         {
             key_btn->hold_start_time = 0;
             key_btn->long_press_active = false;
             long_press_active = false;
             play_pending = false;
             hold_boundary_played = false;
             reached_limit = false;
             break;
         }

        if (press_duration >= long_press_time)
        {
            switch (key_btn->index)
            {
            case 0:
                prev_section();
                break;

            case 1:
                prev_book();
                break;

            case 2:
                finish_hold_seek_and_resume();
                break;

            case 6:
                next_section();
                break;

            case 7:
                next_book();
                break;

            case 8:
                finish_hold_seek_and_resume();
                break;

            default:
                break;
            }
        }
        else if (!pause_mode_active)
        {
            switch (key_btn->index)
            {
            case 0: prev_section(); break;
            case 1: prev_book(); break;
            case 2: prev_chapter(); break;
            case 3: /* play_pause(); */ break;
            case 4: volume_up(VOLUME_STEP); break;
            case 5: volume_down(VOLUME_STEP); break;
            case 6: next_section(); break;
            case 7: next_book(); break;
            case 8: next_chapter(); break;
            default:
//                rt_kprintf("Unknown button index: %d\n", key_btn->index);
                break;
            }
        }

        if (press_duration >= long_press_time)
         {
             rt_pin_write(AUDIO_SWITCH_PIN,
                          Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);
         }

        // Reset press state
         if (key_btn->index == 4)   // volume up
             max_level_reach = false;

         if (key_btn->index == 5)   // volume down
             min_level_reach = false;
        key_btn->hold_start_time = 0;
        key_btn->long_press_active = false;
        long_press_active = false;
        break;
    }

    case LONG_PRESS_HOLD:

        rt_pin_write(AUDIO_SWITCH_PIN, Audio_state.earphone_inserted ? PIN_HIGH : PIN_LOW);

        if(pause_mode_active && key_btn->index == 5){

            if(resetonce==0){
            resetonce=1;
            pause_mode_active=true;
            rt_enter_critical();

            reset_current_bookmark(0);
            reset_current_bookmark(1);
            rt_exit_critical();
            rt_thread_mdelay(30);
            mp3_player_stop();
//            dac_stop();
//            device_stop();

            play_triple_beep();
//            dac_stop();

            rt_thread_mdelay(300);

//            dac_stop();
//            rt_pin_write(AUDIO_SWITCH_PIN, PIN_LOW);
//            rt_kprintf("PB.3 long press -> PE.6 LOW (permanent)\n");
            rt_thread_mdelay(30);
//            rt_enter_critical();
//            rt_kprintf("BOARD_RESET\n");
            if (rt_pin_read(CABLE_PIN) == PIN_LOW)
            {
            rt_pin_write(PE6_PIN, PIN_LOW);
            }

            }
        }

//        start_task(LED_MODE_OFF);  // led OFF
//        rt_thread_mdelay(300);
        if (!pause_mode_active || key_btn->index == 2)  // Allow long press for button 2 even in pause mode
        {
            key_btn->long_press_active = true;

            switch (key_btn->index)
            {
            case 0: /* nav hold — driven by scan-loop poller, same fix as volume */ break;
            case 1: /* nav hold — driven by scan-loop poller, same fix as volume */ break;
            case 2: /* FF/RW driven by scan-loop poller — same fix as volume */ break;
            case 4: /* volume driven by scan-loop poller */ break;
            case 5: /* volume driven by scan-loop poller */ break;
            case 6: /* nav hold — driven by scan-loop poller, same fix as volume */ break;
            case 7: /* nav hold — driven by scan-loop poller, same fix as volume */ break;
            case 8: /* FF/RW driven by scan-loop poller — same fix as volume */ break;
            default: break;
            }
        }
        if (pause_mode_active)
        {
            start_task(LED_MODE_PAUSE);   // restore blinking
        }
        else
        {
            stop_task();                 // restore normal LED
        }
        break;

    default:
        break;
    }
        if(!pause_mode_active){
         stop_task();                 //  LED ON
        }
         rt_thread_mdelay(20);
    key_btn->last_press = now;
}



static void EXT_det_callback(void *args)
{
//    rt_kprintf("EXT DET CALLBACK\n");
//    static rt_tick_t last = 0;
    rt_tick_t now = rt_tick_get();
//    if (now - last < rt_tick_from_millisecond(5)) return;  // debounce
//    last = now;

    int v = rt_pin_read(SD_EXT);
//    rt_kprintf("EXT IRQ on PE2, val=%d, tick=%u\n", v, (unsigned)now);
}

void keypad_scan_thread_entry(void* p)
{
   // Set PE2 as input pull-up
   rt_pin_mode(SD_EXT, PIN_MODE_INPUT_PULLUP);
//

    while (1) {


        /* -----------------------------------------------------------------
                 * External SD-card hot-plug detection
                 *   PIN_HIGH = card EJECTED   PIN_LOW = card INSERTED
                 *   Insert -> beep only
                 *   Eject  -> beep + (if external active) auto-switch to INTERNAL
                 *   50 ms debounce. First stable read after boot = baseline (no beep).
                 * ---------------------------------------------------------------- */
                {
                    #define SD_DEBOUNCE_TICKS  10        /* 10 * 5ms = 50 ms */

                    static int last_sd_ext      = -1;
                    static int sd_candidate     = -1;
                    static int sd_stable_count  = 0;

                    int now = rt_pin_read(SD_EXT);

                    if (now == last_sd_ext)
                    {
                        sd_candidate    = -1;
                        sd_stable_count = 0;
                    }
                    else if (now == sd_candidate)
                    {
                        if (++sd_stable_count >= SD_DEBOUNCE_TICKS)
                        {
                            int prev = last_sd_ext;
                            last_sd_ext     = now;
                            sd_candidate    = -1;
                            sd_stable_count = 0;

                            if (prev == -1)
                            {
//                                rt_kprintf("SD_EXT initial state = %s\n",
//                                           (now == PIN_HIGH) ? "EJECTED" : "INSERTED");
                            }
                            else if (now == PIN_LOW)
                            {
//                                rt_kprintf("EXT SD inserted - beep\n");
                                play_beep_with_volume_no_led(40);
                            }
                            else
                            {
//                                rt_kprintf("EXT SD ejected - beep\n");
                                if ((current_slot == SLOT_EXTERNAL) && !is_switching)
                                  {
                                      sd_switch_in_progress = true;
                                      suppress_playback = true;
                                  }
                                play_beep_with_volume_no_led(40);

                                if ((current_slot == SLOT_EXTERNAL) && !is_switching)
                                {
//                                    rt_kprintf("External SD active -> auto-switch to INTERNAL\n");

                                    /* Show PAUSE on the LED immediately so the user gets visual
                                     * feedback right at card removal, before the SDIO drain
                                     * (~5-7 s) that precedes the actual switch to internal.
                                     * pause_mode_activate() cannot be used here because it calls
                                     * mp3_player_pause() which blocks on a dead card; we set the
                                     * flag and update the LED directly instead. */
                                    pause_mode_active = true;
                                    current_mode = LED_MODE_PAUSE;  /* LED thread blinks active_led */
//                                    rt_kprintf("EXT SD ejected: PAUSE LED mode set\n");

                                    /* AFTER */
                                                                        /* Capture position while player is alive. */
                                                                        if (mp3_player_state_get() == PLAYER_STATE_PLAYING ||
                                                                            mp3_player_state_get() == PLAYER_STATE_PAUSED)
                                                                        {
                                                                            uint32_t cur = mp3_get_cur_seconds();
                                                                            if (cur > 0) songseek = cur;
                                                                        }

                                                                        /* Cut power and abort FIRST — player.fp becomes NULL in ~1 ms.
                                                                         * Bookmark save (flash erase+write, ~300 ms) then runs while
                                                                         * the player is already done rather than racing against it. */
                                                                        rt_pin_write(external_Mosfet, PIN_HIGH);
                                                                        sdio_signal_abort();
                                                                        rt_thread_mdelay(5);

                                                                        save_current_bookmark(SLOT_EXTERNAL);

                                                                        switch_mount_and_play(SLOT_INTERNAL, false, true);

                                    sd_det_flag = false;
                                    update_led_color();
                                }
                            }
                        }
                    }
                    else
                    {
                        sd_candidate    = now;
                        sd_stable_count = 1;
                        if (now == PIN_HIGH && current_slot == SLOT_EXTERNAL && !is_switching)
                        {
                            sd_switch_in_progress = true;
                            suppress_playback     = true;
                        }
                    }
                }
        rt_err_t result = rt_mutex_take(scan_mutex, RT_WAITING_FOREVER);
        if (result != RT_EOK) {
//            rt_kprintf("Failed to take scan mutex: %d\n", result);
            rt_thread_mdelay(100);
            continue;
        }

        // Check earphone state
        bool earphone_state = (rt_pin_read(EARPHONE_DETECT_PIN) == PIN_LOW);

        // Update audio state
        rt_mutex_take(audio_state_mutex, RT_WAITING_FOREVER);
        bool prev_state = Audio_state.earphone_inserted;
        Audio_state.earphone_inserted = earphone_state;
        rt_mutex_release(audio_state_mutex);

        // Only update if state changed
        if (prev_state != earphone_state) {
            update_speaker();
        }


        // Rest of the keypad scanning logic
        // Rest of the keypad scanning logic
        uint16_t key = scan_keypad();

        if (combo_release_guard)
        {
            if (key == 0)
            {
                /*
                 * All combo keys are released.
                 * Run button_ticks once while button_callback() is blocked,
                 * so MultiButton clears its internal PRESS_UP state.
                 */
                button_ticks();

                clear_combo_key_state();
                combo_release_guard = false;
            }

            rt_mutex_release(scan_mutex);
            rt_thread_mdelay(5);
            continue;
        }

        update_key_states(key);

        if (pause_mode_active) {
//            rt_kprintf("pause_mode_active=1 key=0x%04X\n", key);
            handle_combinations(key);
        }

        /*
         * If handle_combinations() started SD switching,
         * do not allow the same key press/release to become normal navigation.
         */
        if (combo_release_guard || is_switching)
        {
            rt_mutex_release(scan_mutex);
            rt_thread_mdelay(5);
            continue;
        }

        /*
         * button_ticks() already checks all registered buttons.
         * Do not call it inside a KEY_COUNT loop.
         */
        button_ticks();
        /* ── Volume hold poller ────────────────────────────────────────────────
         * LONG_PRESS_HOLD fires at LONG_HOLD_CYC scan-loop ticks, but the
         * scan loop runs ~60 ms/iteration (not 5 ms) when the MP3 decoder
         * thread pre-empts it.  That makes each LONG_HOLD_CYC ≈ 1 s, giving
         * the 15 s sweep the user observed.  This poller uses rt_tick_get()
         * (true wall-clock time), so it hits the target interval regardless
         * of how slow or fast the scan loop actually runs.                   */
        {
            static rt_tick_t vol_next_fire = 0;
            rt_tick_t now_v = rt_tick_get();

            bool vol_up_held   = (keys[4].hold_start_time > 0 &&
                                  (now_v - keys[4].hold_start_time) >=
                                   rt_tick_from_millisecond(LONG_PRESS_TIME_MS));
            bool vol_down_held = (keys[5].hold_start_time > 0 &&
                                  (now_v - keys[5].hold_start_time) >=
                                   rt_tick_from_millisecond(LONG_PRESS_TIME_MS));

            if ((vol_up_held || vol_down_held) && !pause_mode_active)
            {
                if (vol_next_fire == 0 ||
                    (rt_int32_t)(now_v - vol_next_fire) >= 0)
                {
                    vol_next_fire = now_v +
                                    rt_tick_from_millisecond(VOL_HOLD_INTERVAL_MS);
                    if (vol_up_held)   volume_up(VOLUME_STEP_HOLD);
                    else               volume_down(VOLUME_STEP_HOLD);
                }
            }
            else
            {
                vol_next_fire = 0;   /* button not held / pause mode — reset */
            }
        }
        {
            rt_tick_t now_f = rt_tick_get();

            bool rw_held = (keys[2].hold_start_time > 0 &&
                            (now_f - keys[2].hold_start_time) >=
                             rt_tick_from_millisecond(LONG_PRESS_TIME_MS));
            bool ff_held = (keys[8].hold_start_time > 0 &&
                            (now_f - keys[8].hold_start_time) >=
                             rt_tick_from_millisecond(LONG_PRESS_TIME_MS));

            /* Mirror the LONG_PRESS_HOLD condition: fast_rewind allowed even
             * in pause mode (index-2 exception); fast_forward only when playing. */
            if (rw_held)
                fast_rewind();
            if (ff_held && !pause_mode_active)
                fast_forward();

            /* ── FF/RW LED blink — 100 ms toggle ──────────────────────────
             * Independent of the seek-step rate so the LED blinks at a fixed
             * 100 ms interval (ON 100 ms, OFF 100 ms) for the full hold
             * duration.  Non-blocking: just drives the GPIO on each fire.   */
            {
                static rt_tick_t ff_rw_led_next = 0;
                static bool      ff_rw_led_on   = false;

                if (ff_rw_hold_active)
                {
                    if (ff_rw_led_next == 0 ||
                        (rt_int32_t)(now_f - ff_rw_led_next) >= 0)
                    {
                        ff_rw_led_next = now_f +
                                         rt_tick_from_millisecond(100);
                        if (ff_rw_led_on)
                        {
                            led_beep_pulse_stop();
                            ff_rw_led_on = false;
                        }
                        else
                        {
                            led_beep_pulse_start();
                            ff_rw_led_on = true;
                        }
                    }
                }
                else
                {
                    /* Hold ended — make sure LED is off and timer is reset. */
                    if (ff_rw_led_on)
                    {
                        led_beep_pulse_stop();
                        ff_rw_led_on = false;
                    }
                    ff_rw_led_next = 0;
                }
            }
        }
        /* ── Section / Book hold poller ─────────────────────────────────────
         * Same fix as volume and FF/RW: MultiButton's LONG_HOLD_CYC counts
         * scan-loop iterations (~60 ms each), not real milliseconds, so hold
         * fires once per ~1 s instead of 85 ms.  This poller uses rt_tick_get()
         * (wall-clock) to fire at a predictable interval regardless of how
         * long each scan-loop iteration actually takes.
         * keys: 0=prev_section  1=prev_book  6=next_section  7=next_book   */
        {
            static rt_tick_t nav_next_fire[KEY_COUNT];
            static bool      nav_fire_inited = false;
            rt_tick_t        now_n = rt_tick_get();

            if (!nav_fire_inited) {
                memset(nav_next_fire, 0, sizeof(nav_next_fire));
                nav_fire_inited = true;
            }

            static const int nav_keys[] = {0, 1, 6, 7};
            for (int ni = 0; ni < 4; ni++)
            {
                int ki = nav_keys[ni];
                bool held = (keys[ki].hold_start_time > 0 &&
                             (rt_int32_t)(now_n - keys[ki].hold_start_time) >=
                              (rt_int32_t)rt_tick_from_millisecond(LONG_PRESS_TIME_MS));

                if (held && !pause_mode_active &&
                    !is_switching && !combo_release_guard)
                {
                    if (nav_next_fire[ki] == 0 ||
                        (rt_int32_t)(now_n - nav_next_fire[ki]) >= 0)
                    {
                        nav_next_fire[ki] = now_n +
                            rt_tick_from_millisecond(NAV_HOLD_INTERVAL_MS);

                        /* Tell the nav functions this is a hold-fire,
                         * and mark long_press_active so PRESS_UP commits. */
                        btn_event_val        = LONG_PRESS_HOLD;
                        keys[ki].long_press_active = true;
                        long_press_active    = true;

                        switch (ki) {
                        case 0: prev_section(); break;
                        case 1: prev_book();    break;
                        case 6: next_section(); break;
                        case 7: next_book();    break;
                        }
                    }
                }
                else if (!held)
                {
                    nav_next_fire[ki] = 0;  /* button released — reset */
                }
            }
        }

        bool do_autoplay_next = false;

                /* Don't auto-advance while a cable-driven SD switch is still
                 * unwinding. cable.c sets g_in_switch=1 before calling
                 * switch_mount_and_play() and clears it only AFTER the resume
                 * (pause_mode_deactivate -> play_current) has actually started
                 * playback. Without this guard, there is a window in which the
                 * player is in STOPED state, autoplay_enabled is already 1
                 * (set near the end of switch_mount_and_play), but cable.c
                 * hasn't yet called play_current to resume — and the autoplay
                 * loop wins the race, calls next_chapter(), and the device
                 * resumes one file ahead of the bookmark. */
                if (mp3_player_state_get() == PLAYER_STATE_STOPED &&
                    autoplay_enabled && !block_autoplay &&
                    !long_press_active && !g_in_switch &&
                    !sd_switch_in_progress)
                {
                    /* Consume EOF only when navigation is allowed.  A STOP
                     * caused by a key press or SD switch never advances. */
                    if (mp3_player_take_natural_end())
                        do_autoplay_next = true;
                }

        rt_mutex_release(scan_mutex);

        if (do_autoplay_next)
        {
            next_chapter();
        }

//        rt_mutex_release(scan_mutex);

        if (stopwatchflag)
        {
            stopwatchflag = false;
            stopwatchfunc();
        }
        /* Deferred bookmark save from button_play_pause() — runs here where the
         * keypad thread has a full stack and flash writes are safe.
         * Guard: player must not be playing when we hit fal_partition_erase. */
        if (bookmark_save_pending)
        {
            bookmark_save_pending = false;
            if (mp3_player_state_get() == PLAYER_STATE_PLAYING)
            {
                /* Shouldn't happen (pause fires before flag set) but be safe.
                 * No mdelay: mdelay causes full decoder wind-down, making
                 * resume trigger an 8-9s re-seek instead of a clean unpause. */
                mp3_player_pause();
            }
            save_current_bookmark(current_slot);
        }
        if (low_battery_bookmark_mode)
        {
            static rt_tick_t last_bm_save_tick = 0;
            rt_tick_t now_tick = rt_tick_get();
            rt_tick_t elapsed  = now_tick - last_bm_save_tick;

            if (elapsed >= rt_tick_from_millisecond(10000))
            {
                last_bm_save_tick = now_tick;
                int slots = rt_pin_read(external_Mosfet);
                uint8_t bm_index = (slots == PIN_LOW) ? 1u : 0u;

                /* Compute live playback position from elapsed ticks + resume offset.
                 * mp3_get_cur_seconds() returns the seek target set by mp3_seek() and
                 * does not advance during playback on this platform — it always returns
                 * the value last passed to mp3_seek() (i.e. the bookmark restore position).
                 * Using chapter_start_time gives the correct advancing position:
                 *   live = songseek (resume offset) + seconds elapsed since play_current().
                 *
                 * IMPORTANT: do NOT write live_sec back into songseek here.
                 * chapter_start_time is fixed for the entire chapter, so elapsed_sec
                 * grows every cycle.  If songseek were updated each save, the next
                 * cycle would add elapsed_sec again on top of the already-advanced
                 * value, causing saves to compound (e.g. +10, +20, +30 ... instead
                 * of +10, +10, +10).  Keep songseek as the stable resume offset and
                 * only pass the local live_sec to the flash save. */
                uint32_t elapsed_sec = 0;
                if (!pause_mode_active && state.chapter_start_time > 0)
                {
                    rt_tick_t now_ticks = rt_tick_get();
                    rt_tick_t delta = now_ticks - state.chapter_start_time;
                    elapsed_sec = (uint32_t)(delta / RT_TICK_PER_SECOND);
                }
                uint32_t live_sec = songseek + elapsed_sec;

                /* MUST pause the MP3 player before calling fal_partition_erase().
                 * The AB32VG1 SPI flash is shared between XIP (code execution) and
                 * FAL data storage. While the flash chip is executing a sector erase
                 * (~20 ms), it cannot serve instruction fetches. Any thread still
                 * running from flash during that window triggers:
                 *   ERR: c0000004 (Load Access Fault / XIP stall)
                 * The mdelay(30) after pause gives the decoder thread time to drain
                 * its pipeline and block, so the flash bus is idle before we erase. */
                bool was_playing = (mp3_player_state_get() == PLAYER_STATE_PLAYING);
                if (was_playing)
                {
                    mp3_player_pause();
                    /* No mdelay here: the mdelay(30) caused the decoder to fully
                     * wind down, making mp3_player_resume() behave like a restart
                     * with a full 8-9 second re-seek instead of a clean unpause.
                     * mp3_player_pause() puts the decoder in a blocking wait;
                     * in that state it holds no flash references, so the erase
                     * window (~20ms) is safe without any extra delay. */
                }

//                rt_kprintf("Low-battery direct bookmark save (slot=%d seek=%lu)\n",
//                           bm_index, (unsigned long)live_sec);
                save_bookmark_direct(bm_index,
                                     (uint8_t)state.volume,
                                     (uint16_t)state.section_index,
                                     (uint16_t)state.book_index,
                                     (uint16_t)state.chapter_index,
                                     live_sec);

                if (was_playing)
                {
                    mp3_player_resume();
                }
            }
        }
        /* Battery-critical shutdown: adc1.c has confirmed ADC <= 850
         * for SHUTDOWN_CONFIRM_COUNT consecutive samples. Run the full
         * clean-shutdown sequence from HERE so it has enough stack.
         * device_stop() saves the bookmark, plays the double beep, and
         * pulls PE6 low -- it never returns. */
        if (battery_shutdown_request)
        {
            battery_shutdown_request = false;  /* avoid re-entry */
//            rt_kprintf("Battery shutdown request received -- running device_stop()\n");
            device_stop();
        }


        rt_thread_mdelay(5);
    }
}


static struct button power_play_btn;
static struct button power_play_btn1;

void init_pins(void)
{
    /*
     for version8 PINMODE PULLUP, PLAYBTN PIN LOW
     */

    /*
     * for version 9.3 PINMODE PULLDOWN , PIN HIGH
     */
    rt_pin_mode(power_play, PIN_MODE_INPUT_PULLDOWN);
    button_init(&power_play_btn, Play_button_read_pin, PIN_HIGH);






    button_attach(&power_play_btn, SINGLE_CLICK, play_pause_callback);
    button_attach(&power_play_btn, LONG_PRESS_HOLD, play_pause_callback);
    button_start(&power_play_btn);



    for (int i = 0; i < 3; i++)
    {
        row_pins[i] = rt_pin_get(row_pin_names[i]);
        col_pins[i] = rt_pin_get(col_pin_names[i]);
    }


    for (int i = 0; i < 3; i++)
    {
        rt_pin_mode(row_pins[i], PIN_MODE_INPUT_PULLUP);
    }

    for (int i = 0; i < 3; i++)
    {
        rt_pin_mode(col_pins[i], PIN_MODE_OUTPUT);
        rt_pin_write(col_pins[i], PIN_HIGH);
    }

    for (int i = 0; i < KEY_COUNT; i++)
    {
        int col = i / 3;
        int row = i % 3;

        keys[i].index = i;
        keys[i].col_pin = col_pins[col];
        keys[i].row_pin = row_pins[row];
        keys[i].last_press = 0;
        keys[i].hold_start_time = 0;
        keys[i].last_jump_time = 0;
        keys[i].long_press_active = false;

        button_init(&keys[i].btn, (uint8_t (*)(void)) button_read_pin, PIN_LOW);

             button_attach(&keys[i].btn, PRESS_DOWN, button_callback);
               button_attach(&keys[i].btn, PRESS_UP, button_callback);
               button_attach(&keys[i].btn, LONG_PRESS_HOLD, button_callback);

        button_start(&keys[i].btn);
    }
}


// Initialize all mutexes early in keypad_matrix_init()
int keypad_matrix_init(void)
{
//    rt_kprintf("keypad_matrix_init start\n");
    // Initialize hardware pins


    rt_pin_mode(SD_EXT, PIN_MODE_INPUT_PULLDOWN);


    rt_pin_mode(EARPHONE_DETECT_PIN, PIN_MODE_INPUT_PULLUP);


    rt_pin_mode(MOS_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(MOS_PIN, PIN_LOW);
    rt_pin_mode(CABLE_PIN,PIN_MODE_INPUT);

    if (rt_pin_read(CABLE_PIN) == PIN_HIGH)
        {
            rt_pin_write(MOS_PIN, PIN_HIGH);
//            rt_kprintf("Boot with cable in: PE.6 forced HIGH for battery sense\n");
        }
    rt_pin_mode(GL_Soc, PIN_MODE_OUTPUT);
      rt_pin_mode(SD1_SD2, PIN_MODE_OUTPUT);
      rt_pin_mode(internal_Mosfet, PIN_MODE_OUTPUT);
      rt_pin_mode(external_Mosfet, PIN_MODE_OUTPUT);

      rt_pin_write(GL_Soc, PIN_HIGH);
//      load_last_bookmark();
//      if(bookmark_info.sdcard == 0x06){
//          sd_det_flag = true;
////          update_led_color();
//          rt_pin_write(SD1_SD2, PIN_HIGH);
//          slot_power_off_all();
//          slot_power_on(SLOT_EXTERNAL);
//          rt_kprintf("EXTERNAL SD CARD OPEND %d\n",bookmark_info.sdcard);
//      }
//      else {
//          rt_pin_write(SD1_SD2, PIN_LOW);
//          slot_power_off_all();
//          slot_power_on(SLOT_INTERNAL);
//          rt_kprintf("INTERNAL SD CARD OPEND %d\n",bookmark_info.sdcard);
//      }

//
//      if(bookmark_info.sdcard == 0x06){
//          sd_det_flag = true;
//          current_slot = SLOT_EXTERNAL;
//          rt_pin_write(SD1_SD2, PIN_HIGH);
//          slot_power_on(SLOT_EXTERNAL);
//      }
//      else {
//          current_slot = SLOT_INTERNAL;
//          rt_pin_write(SD1_SD2, PIN_LOW);
//          slot_power_on(SLOT_INTERNAL);
//      }


      // Load both bookmarks first
//      load_bookmark_state(&bookmark_info, 0);
//      load_bookmark_state(&bookmark_info2, 1);
//
//      // Decide last used SD
//      sd_slot_t boot_slot = SLOT_INTERNAL;
////
////      if (bookmark_info2.sdcard == 0x06)
////      {
////          boot_slot = SLOT_EXTERNAL;
////      }
////      else if (bookmark_info.sdcard == 0x01)
////      {
////          boot_slot = SLOT_INTERNAL;
////      }
//
//      // Set current slot
//      current_slot = boot_slot;
//
//      // Configure hardware properly
//      slot_power_off_all();
//      rt_thread_mdelay(10);
//
//      if (boot_slot == SLOT_EXTERNAL)
//      {
//          sd_det_flag = true;
//          rt_pin_write(SD1_SD2, PIN_HIGH);
//          slot_power_on(SLOT_EXTERNAL);
//      }
//      else
//      {
//          sd_det_flag = false;
//          rt_pin_write(SD1_SD2, PIN_LOW);
//          slot_power_on(SLOT_INTERNAL);
//      }
      load_bookmark_state(&bookmark_info, 0);

            slot_power_off_all();
            rt_thread_mdelay(10);


                    if (bookmark_info.sdcard == 0x06)
                    {
                        /* Last session was on EXTERNAL SD — check card is still present
                         * (same detection method used by Combo 3+9 at runtime). */
                        rt_pin_mode(SD_EXT, PIN_MODE_INPUT_PULLUP);
                        rt_thread_mdelay(5);                           /* settle pull-up */
                        bool ext_present = (rt_pin_read(SD_EXT) == PIN_LOW);
                        rt_pin_mode(SD_EXT, PIN_MODE_INPUT_PULLDOWN);  /* restore default */

                        if (ext_present)
                        {
                            current_slot = SLOT_EXTERNAL;
                            sd_det_flag  = true;
                            rt_pin_write(SD1_SD2, PIN_HIGH);
                            slot_power_on(SLOT_EXTERNAL);
//                            rt_kprintf("Boot: resuming on EXTERNAL SD\n");
                        }
                        else
                        {
                            /* External card absent — fall back to INTERNAL */
                            current_slot = SLOT_INTERNAL;
                            sd_det_flag  = false;
                            rt_pin_write(SD1_SD2, PIN_LOW);
                            slot_power_on(SLOT_INTERNAL);
//                            rt_kprintf("Boot: external SD absent — falling back to INTERNAL\n");
                        }
                    }
                    else
                    {
                        /* Default / last session was INTERNAL */
                        current_slot = SLOT_INTERNAL;
                        sd_det_flag  = false;
                        rt_pin_write(SD1_SD2, PIN_LOW);
                        slot_power_on(SLOT_INTERNAL);
//                        rt_kprintf("Boot: resuming on INTERNAL SD\n");
                    }
            rt_thread_mdelay(200);


//      rt_thread_mdelay(200);
//    fal_init();


    // Initialize mutexes first
    scan_mutex = rt_mutex_create("key_mtx", RT_IPC_FLAG_FIFO);
    if (scan_mutex == RT_NULL) {
//        rt_kprintf("Failed to create scan mutex\n");
        return -RT_ERROR;
    }

    audio_state_mutex = rt_mutex_create("audio_mtx", RT_IPC_FLAG_FIFO);
    if (audio_state_mutex == RT_NULL) {
//        rt_kprintf("Failed to create audio state mutex\n");
        rt_mutex_delete(scan_mutex);
        return -RT_ERROR;
    }
//    rt_kprintf("Audio state mutex created successfully\n");

    // Initialize dynamic arrays
//    if (dynamic_array_init(&sections) != RT_EOK ||
//        dynamic_array_init(&books) != RT_EOK ||
//        dynamic_array_init(&chapters) != RT_EOK) {
//        rt_kprintf("Failed to initialize dynamic arrays\n");
//        rt_mutex_delete(scan_mutex);
//        rt_mutex_delete(audio_state_mutex);
//        return -RT_ENOMEM;
//    }


    // Scan filesystem BEFORE loading bookmark
//    if (scan_sections() <= 0)
//    {
//        rt_kprintf("No sections found during boot\n");
//    }
//    else
//    {
////        scan_books();
////        scan_chapters();
//
//        // 🔥 NOW load correct bookmark
//        if (current_slot == SLOT_INTERNAL)
//            load_last_bookmark();
//        else
//            load_last_bookmark2();
//    }

    init_pins();

    thread = rt_thread_create("keypad", keypad_scan_thread_entry, RT_NULL, 4096, 11, 10);    /* stack: was 3072, increased for flash+fs call chain */

    if (thread == RT_NULL) {
//        rt_kprintf("Failed to create keypad thread\n");
        rt_mutex_delete(scan_mutex);
        rt_mutex_delete(audio_state_mutex);
        return -RT_ERROR;
    }

    if (rt_thread_startup(thread) != RT_EOK) {
//        rt_kprintf("Failed to start keypad thread\n");
        rt_thread_delete(thread);
        rt_mutex_delete(scan_mutex);
        rt_mutex_delete(audio_state_mutex);
        return -RT_ERROR;
    }

//    rt_kprintf("Keypad matrix initialized\n");
    // When powering ON to directly play Audio
    rt_pin_mode(power_play, PIN_MODE_INPUT_PULLUP);
    rt_pin_write(power_play, PIN_HIGH);
    rt_thread_mdelay(30);
    rt_pin_mode(power_play, PIN_MODE_INPUT_PULLDOWN);
    rt_pin_write(power_play, PIN_LOW);
    int var=3;


//    rt_kprintf("Keypad matrix initialized2\n");
    rt_thread_mdelay(30);

    //dac_start();

    play_pause_callback(&var);
    rt_pin_mode(AUDIO_SWITCH_PIN, PIN_MODE_OUTPUT);
    return RT_EOK;
}



static void keypad_matrix_cleanup(void)
{
//    rt_kprintf("keypad_matrix_cleanup\n");

    if (scan_mutex)
    {
        rt_mutex_delete(scan_mutex);
        scan_mutex = RT_NULL;
    }
}

INIT_APP_EXPORT(keypad_matrix_init);

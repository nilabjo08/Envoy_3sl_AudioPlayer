#include <rtthread.h>

typedef enum {
    PAUSE_MODE_INACTIVE = 0,
    PAUSE_MODE_ACTIVE,
} pause_mode_state_t;

// Lock/unlock APIs
int pause_mode_lock(void);
int pause_mode_unlock(void);
int play_mode_lock(void);
int play_mode_unlock(void);
int pause_mode_activate(void);
int pause_mode_deactivate(void);

// Pause mode control
void pause_mode_trigger(void);
pause_mode_state_t pause_mode_get_state(void);

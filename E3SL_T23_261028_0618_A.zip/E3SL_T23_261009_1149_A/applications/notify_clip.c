/*
 * notify_clip.c
 *
 * Plays the MP3 baked into notify_audio_data[] (notify_audio.c) when
 * the S3+S4 combo is pressed while the device is in pause mode.
 *
 * Memory -- why this costs almost nothing
 * ----------------------------------------
 * Helix on this BSP defines `static_buffers`, so MP3InitDecoder()
 * allocates ZERO heap. The decoder state lives in static/BSS inside
 * buffers.c, shared across all callers.
 *
 * The only per-decode buffer needed is the PCM output (4608 bytes).
 * The audiobook player (mp3_player) already has one: player.out_buffer.
 * While the player is PAUSED it is idle, so we borrow it directly.
 * No additional heap, no additional BSS.
 *
 * BSS cost of this entire file: ~5 pointers + 1 bool = ~22 bytes.
 */

#include <rtthread.h>
#include <rtdevice.h>
#include <stdint.h>
#include <string.h>

#include "mp3_player.h"     /* extern struct mp3_player player; */
#include "mp3dec.h"
#include "notify_clip.h"
#include "Gpio_Pins_Defines.h"  /* EARPHONE_DETECT_PIN, AUDIO_SWITCH_PIN */

#define LOG_TAG  "notify"
#define LOG_LVL  DBG_INFO
#include <ulog.h>

#define SOUND_DEV_NAME   "sound0"

/* Same size as the player's own output buffer (rtconfig.h). */
#define OUT_BUF_SAMPLES  (MP3_OUTPUT_BUFFER_SIZE / sizeof(int16_t))

extern const uint8_t  notify_audio_data[];
extern const uint32_t notify_audio_size;
extern void saia_frequency_set(uint32_t frequency);

/* Module state -- only pointers/bool in BSS (~22 bytes) */
static rt_device_t  snd_dev    = RT_NULL;
static rt_sem_t     notify_sem = RT_NULL;
static rt_thread_t  notify_tid = RT_NULL;
static volatile rt_bool_t notify_busy = RT_FALSE;

rt_bool_t notify_clip_is_present(void)
{
    return (notify_audio_size > 0) ? RT_TRUE : RT_FALSE;
}

static void audio_set_channels(uint16_t ch)
{
    struct rt_audio_caps caps;
    rt_memset(&caps, 0, sizeof(caps));
    caps.main_type = AUDIO_TYPE_OUTPUT;
    caps.sub_type  = AUDIO_DSP_CHANNELS;
    caps.udata.config.channels = ch;
    rt_device_control(snd_dev, AUDIO_CTL_CONFIGURE, &caps);
}

static void audio_flush_silence(int16_t *buf, int buf_shorts)
{
    rt_memset(buf, 0, buf_shorts * sizeof(int16_t));
    for (int i = 0; i < 4; i++)
        rt_device_write(snd_dev, 0, buf, buf_shorts * sizeof(int16_t));
}

/* Expand mono frame to stereo in place (backwards pass). */
static int expand_mono_to_stereo(int16_t *buf, int n)
{
    for (int i = n - 1; i >= 0; i--) {
        int16_t s = buf[i];
        buf[2 * i]     = s;
        buf[2 * i + 1] = s;
    }
    return n * 2;
}

static void notify_play_once(void)
{
    if (notify_audio_size == 0) {
//        LOG_W("no clip (regenerate notify_audio.c)");
        return;
    }

    /* Borrow the audiobook player's output buffer.
     * Safe because the player is PAUSED -- its decode loop is blocked
     * waiting for a command and is not touching out_buffer. */
    int16_t *out_buf = (int16_t *)player.out_buffer;
    if (!out_buf) {
//        LOG_E("player.out_buffer is NULL");
        return;
    }

    /* MP3InitDecoder uses static storage (static_buffers defined in
     * buffers.c), so this costs zero heap. */
    HMP3Decoder dec = MP3InitDecoder();
    if (!dec) {
//        LOG_E("MP3InitDecoder failed");
        return;
    }

//    LOG_I("playing %u bytes", (unsigned)notify_audio_size);

        /* Enable speaker only when no earphone is inserted.
         * EARPHONE_DETECT_PIN is active-LOW (PIN_LOW = earphone present).
         * AUDIO_SWITCH_PIN: PIN_LOW = speaker on, PIN_HIGH = speaker off.
         * If earphone is inserted, keep speaker muted so audio comes only
         * from earphone; otherwise unmute speaker as before. */
        bool earphone_in = (rt_pin_read(EARPHONE_DETECT_PIN) == PIN_LOW);
        int audio_sw = rt_pin_get("PB.4");
        if (!earphone_in) {
            rt_pin_write(audio_sw, PIN_LOW);   /* unmute speaker */
        }
        rt_thread_mdelay(10);   /* amp settle time */

        uint32_t saved_sr = player.mp3_info.samplerate;
        if (saved_sr == 0) saved_sr = 44100;

    /* Point Helix directly at the flash array -- no copy needed. */
    unsigned char *read_ptr  = (unsigned char *)notify_audio_data;
    int            bytes_left = (int)notify_audio_size;
    rt_bool_t configured  = RT_FALSE;
    int       decode_errs = 0;

    while (bytes_left > 0)
    {
        int sync = MP3FindSyncWord(read_ptr, bytes_left);
        if (sync < 0) break;
        read_ptr   += sync;
        bytes_left -= sync;

        if (!configured) {
            MP3FrameInfo fi;
            if (MP3GetNextFrameInfo(dec, &fi, read_ptr) == 0
                && fi.samprate > 0)
            {
//                LOG_I("sr=%d ch=%d br=%d", fi.samprate, fi.nChans, fi.bitrate);
                audio_set_channels(2);
                saia_frequency_set(fi.samprate);
                configured = RT_TRUE;
            } else {
                read_ptr++; bytes_left--;
                continue;
            }
        }

        int err = MP3Decode(dec, &read_ptr, &bytes_left, out_buf, 0);
        if (err) {
            if (++decode_errs > 8) { break; }
            if (bytes_left > 0) { read_ptr++; bytes_left--; }
            continue;
        }
        decode_errs = 0;

        MP3FrameInfo fi;
        MP3GetLastFrameInfo(dec, &fi);

        int n = fi.outputSamps;
        if (fi.nChans == 1)
            n = expand_mono_to_stereo(out_buf, n);

        rt_device_write(snd_dev, 0, out_buf, n * sizeof(int16_t));
    }

    audio_flush_silence(out_buf, OUT_BUF_SAMPLES);
        saia_frequency_set(saved_sr);
        MP3FreeDecoder(dec);

        /* Restore speaker switch: always mute after clip playback,
         * regardless of earphone state (we're returning to pause mode). */
        rt_thread_mdelay(10);
        rt_pin_write(audio_sw, PIN_HIGH);
}

static void notify_thread_entry(void *arg)
{
    (void)arg;
    while (1) {
        rt_sem_take(notify_sem, RT_WAITING_FOREVER);
        notify_busy = RT_TRUE;
        notify_play_once();
        notify_busy = RT_FALSE;
    }
}

void play_notify_clip(void)
{
    if (!notify_sem)   { return; }
    if (notify_busy)   { return; }
    rt_sem_release(notify_sem);
}

int notify_clip_init(void)
{
    if (notify_sem) return RT_EOK;

    snd_dev = rt_device_find(SOUND_DEV_NAME);
    if (!snd_dev) { return -RT_ERROR; }

    if (rt_device_open(snd_dev, RT_DEVICE_OFLAG_WRONLY) != RT_EOK) {
//        LOG_E("open sound device failed");
        return -RT_ERROR;
    }

    notify_sem = rt_sem_create("notify_sem", 0, RT_IPC_FLAG_FIFO);
    if (!notify_sem) {return -RT_ERROR; }

    notify_tid = rt_thread_create("notify",
                                  notify_thread_entry, RT_NULL,
                                  756, 14, 10);
    if (!notify_tid) {
//        LOG_E("thread create failed");
        rt_sem_delete(notify_sem); notify_sem = RT_NULL;
        return -RT_ERROR;
    }
    rt_thread_startup(notify_tid);

//    LOG_I("ready — %s (%u bytes)",
//          notify_clip_is_present() ? "clip present" : "NO CLIP",
//          (unsigned)notify_audio_size);
    return RT_EOK;
}
INIT_APP_EXPORT(notify_clip_init);

static int cmd_notify_info(int argc, char **argv)
{
    (void)argc; (void)argv;
//    rt_kprintf("clip   : %u bytes %s\n",
//               (unsigned)notify_audio_size,
//               notify_audio_size ? "(present)" : "(MISSING)");
//    rt_kprintf("outbuf : borrowing player.out_buffer (%u bytes)\n",
//               (unsigned)MP3_OUTPUT_BUFFER_SIZE);
    return 0;
}
MSH_CMD_EXPORT_ALIAS(cmd_notify_info, notify_info, "Show notify clip info");

static int cmd_notify_play(int argc, char **argv)
{
    (void)argc; (void)argv;
    play_notify_clip();
    return 0;
}
MSH_CMD_EXPORT_ALIAS(cmd_notify_play, notify_play, "Play the baked-in notify clip");

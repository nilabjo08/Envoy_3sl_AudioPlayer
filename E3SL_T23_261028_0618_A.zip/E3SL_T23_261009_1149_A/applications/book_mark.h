#ifndef BOOK_MARK_H
#define BOOK_MARK_H

#include "board.h"
#include <rtthread.h>
#include <rtdevice.h>
#include <fal.h>
#define FAL_PART_HAS_TABLE_CFG
#define NUM_BOOKMARK_SLOTS       2
#define MAX_NAME_LEN             256   // Set to 256 for alignment

// Individual bookmark info (state)
//typedef struct {
//    uint8_t volume;
//    uint8_t section;   // index into `sections.items`
//    uint8_t book;      // index into `books.items`
//    uint8_t chapter;   // index into `chapters.items`
//    uint8_t sdcard;
//    uint32_t seektime;  //mp3 song current sec stored
//} bookmark_info_t;

typedef struct {
    uint8_t  volume;
    uint16_t section;
    uint16_t book;
    uint16_t chapter;
    uint8_t  sdcard;
    uint32_t seektime;

    /* SD content signature */
    uint16_t total_sections;
    uint16_t total_books;
    uint16_t total_chapters;

} bookmark_info_t;

// Flash-stored bookmark structure (multiple slots)
typedef struct {
    uint32_t magic;  // Used to validate flash content
    bookmark_info_t bookmarks[NUM_BOOKMARK_SLOTS];
} bookmark_flash_data_t;

// Flash management functions
int clear_bookmark_flash(void);
int load_bookmark_state(bookmark_info_t *info, uint8_t index);
int save_bookmark_state(const bookmark_info_t *info, uint8_t index);
int write_flash_data(const bookmark_flash_data_t *flash_data);
int read_flash_data(bookmark_flash_data_t *flash_data);
void test_flash_verify(void);

/* Lean write path: no SD directory scanning, safe from stack-constrained contexts.
 * Call bookmark_update_cache() after every normal save to keep totals current. */
void bookmark_update_cache(uint16_t sections, uint16_t books,
                           uint16_t chapters, uint8_t sdcard);
int  save_bookmark_direct(uint8_t  index,
                          uint8_t  volume,
                          uint16_t section,
                          uint16_t book,
                          uint16_t chapter,
                          uint32_t seektime);
#endif // BOOK_MARK_H

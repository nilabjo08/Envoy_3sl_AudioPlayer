/*
 * notify_clip.h
 *
 * Plays a short MP3 stored in the on-chip flash 'audio' partition.
 * Used as a one-shot notification when the S3+S4 combo is pressed
 * while the device is in pause mode.
 *
 * Storage layout (start of 'audio' partition):
 *   offset 0x00 .. 0x03  : magic "NTFY"
 *   offset 0x04 .. 0x07  : payload size in bytes (uint32 little-endian)
 *   offset 0x08 .. 0x0B  : reserved (0)
 *   offset 0x0C .. 0x0F  : reserved (0)
 *   offset 0x10 ..       : MP3 payload bytes (raw .mp3 file contents)
 */

#ifndef __NOTIFY_CLIP_H__
#define __NOTIFY_CLIP_H__

#include <rtthread.h>
#include <stdint.h>

#define NOTIFY_MAGIC          0x5946544Eu   /* 'N','T','F','Y' little-endian */
#define NOTIFY_HEADER_BYTES   16
#define NOTIFY_PART_NAME      "audio"

/* Initialise the notify subsystem. Wired to INIT_APP_EXPORT in notify_clip.c
 * so it is called automatically at boot. Safe to call again. */
int notify_clip_init(void);

/* Fire-and-forget request to play the stored clip. Returns immediately.
 * Does nothing if no clip is flashed or playback is already in flight. */
void play_notify_clip(void);

/* True if a valid clip is flashed at the start of the audio partition. */
rt_bool_t notify_clip_is_present(void);

#endif /* __NOTIFY_CLIP_H__ */

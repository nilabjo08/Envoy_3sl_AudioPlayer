#ifndef APPLICATIONS_DAC_BEEP_H_
#define APPLICATIONS_DAC_BEEP_H_
#include <rtthread.h>
#define BEEP_NOTIFY_HW_VOL   30
void update_sine_table(rt_uint8_t volume);
void beep_control_thread(void *parameter);
void play_beep(void);
void play_beep_no_led(void);
void stop_beep_playback(void);
void beep_wait_done(void);
void play_beep_with_volume(rt_uint8_t volume);
void play_beep_with_volume_no_led(rt_uint8_t volume);
int  beeper_init(void);
void play_double_beep(void);
void play_double_beep_no_led(void);
void play_double_beep_with_volume(rt_uint8_t volume);   /* used by play_mode.c */
void play_triple_beep(void);
void play_triple_beep_no_led(void);
void play_5_beep(void);
void beep_deinit(void);

#endif /* APPLICATIONS_DAC_BEEP_H_ */


#include <rtthread.h>
#include "board.h"
#include <rtdevice.h>
#include <stdint.h>


typedef enum {
    LED_MODE_SOLID = 1,
    LED_MODE_OFF,
    LED_MODE_PAUSE,
    LED_MODE_CHARGE
} led_mode_t;
extern led_mode_t current_mode;

extern volatile bool ledflag;
extern rt_bool_t battery_full;
/* API to start LED task with a specific mode */
void start_task(led_mode_t mode);
void led_beep_pulse_start(void);
void led_beep_pulse_stop(void);

/* API to stop LED task */
void stop_task(void);

/* Initializes LED control system (event + thread) */
int led_init(void);

/* Manually trigger color update based on sd_det_flag (optional use) */
void update_led_color(void);
void led_OFF(void);
void led_PAUSE_blink(void);
void playerOFF_Charging(void);
void playerON_Charging(void);
void battery_fullcharge(void);
void battery_lowcharge(void);
void USBdata_tranfer(void);
void update_led_off(void);





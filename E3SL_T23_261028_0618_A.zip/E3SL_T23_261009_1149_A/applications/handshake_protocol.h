#ifndef HANDSHAKE_PROTOCOL_H
#define HANDSHAKE_PROTOCOL_H

#include <rtthread.h>
#include <rtdevice.h>
#include <stdbool.h>
#include <stdint.h>

// Handshake states
typedef enum {
    HANDSHAKE_IDLE = 0,
    HANDSHAKE_IN_PROGRESS,
    HANDSHAKE_SUCCESS,
    HANDSHAKE_FAILED
} handshake_status_t;

// Public API
void HandShake_setup(void);
uint8_t receiveResponseByte(void);
void sendHandshakeSignal(void);

// Exposed status
extern volatile handshake_status_t handshake_status;
extern bool sdswitch;
extern volatile int PLY_resume;
#endif // HANDSHAKE_PROTOCOL_H

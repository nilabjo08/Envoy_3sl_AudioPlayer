#include <dac_beep.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <string.h>
#include "mp3_player.h"
#include "play_mode.h"
#include "Gpio_Pins_Defines.h"
#include "timer1.h"
#include "led.h"

#define CLAMP(x, min, max) ((x) < (min) ? (min) : ((x) > (max) ? (max) : (x)))

/* ---- Configuration ---- */
#define DAC_INT16_MAX        32767
#define DAC_AMPLITUDE_CAP   (DAC_INT16_MAX * 70 / 100)   /* ~70 % of full scale     */
#define BEEP_FADE_MS         8                            /* 8 ms fade-in/out        */

/* Fallback rate used only at boot, before any MP3 has ever reported a
 * samplerate (player.mp3_info.samplerate == 0) — i.e. for the power-on
 * beep, which fires before play_current() has opened a file. 44100 matches
 * what mp3_player.c normalizes every track to internally, and matches the
 * same fallback notify_clip.c already uses for the identical situation
 * (saved_sr == 0 -> 44100). Without this, the power-on beep was the only
 * beep in the app still running at a different underlying DAC rate than
 * every other beep. */
#define BEEP_DEFAULT_SAMPLE_RATE  44100                    /* Hz                      */
#define BEEP_FREQ_HZ         1000                         /* desired tone: 1 kHz     */
#define BEEP_DURATION_MS     250                          /* beep length in ms       */
#define SOUND_DEV_NAME       "sound0"
#define SINE_TABLE_SIZE      64                           /* LUT entries per cycle   */
#define SINE_TABLE_SIZE_LOG2 6                             /* log2(64)                */

/* ---- DDS (direct digital synthesis) phase accumulator ----
 * The old build used a fixed integer phase step (SINE_TABLE_SIZE ×
 * BEEP_FREQ_HZ / BEEP_SAMPLE_RATE) that only lands on an exact 1 kHz tone
 * for sample rates that divide evenly into it (e.g. 16000). Since the beep
 * now runs at whatever rate the MP3 decoder is using (44100, 22050, 48000,
 * ...), that no longer holds. A 32-bit phase accumulator produces an
 * accurate BEEP_FREQ_HZ tone at ANY sample rate:
 *   phase_step = round(2^32 × BEEP_FREQ_HZ / samplerate)
 *   lut_index  = phase_acc >> (32 - SINE_TABLE_SIZE_LOG2)
 * phase_acc wraps naturally on 32-bit overflow. */
#define PHASE_ACC_BITS       32

static rt_uint32_t beep_phase_step_for_rate(rt_uint32_t samplerate)
{
    if (samplerate == 0) samplerate = BEEP_DEFAULT_SAMPLE_RATE;
    return (rt_uint32_t)(((rt_uint64_t)BEEP_FREQ_HZ << PHASE_ACC_BITS) / samplerate);
}

/* The rate to beep at: whatever the player is currently using, so the
 * beep tone and the audio playback are always the same sample rate and
 * the DAC never needs to be switched away from the track's rate. */
static rt_uint32_t beep_rate_get(void)
{
    /* `player` is declared extern in mp3_player.h, already included above. */
    rt_uint32_t rate = player.mp3_info.samplerate;
    return (rate != 0) ? rate : BEEP_DEFAULT_SAMPLE_RATE;
}

/* Precomputed full-amplitude sine LUT: 64 samples, Q1.15.
 * One complete cycle; scaled by volume in update_sine_table(). */
static const int16_t sine_lut[SINE_TABLE_SIZE] = {
         0,   3212,   6393,   9512,  12539,  15446,  18204,  20787,
     23170,  25329,  27245,  28898,  30273,  31356,  32137,  32609,
     32767,  32609,  32137,  31356,  30273,  28898,  27245,  25329,
     23170,  20787,  18204,  15446,  12539,   9512,   6393,   3212,
         0,  -3212,  -6393,  -9512, -12539, -15446, -18204, -20787,
    -23170, -25329, -27245, -28898, -30273, -31356, -32137, -32609,
    -32767, -32609, -32137, -31356, -30273, -28898, -27245, -25329,
    -23170, -20787, -18204, -15446, -12539,  -9512,  -6393,  -3212,
};

/* ---- Shared volume (0–100) ---- */
rt_uint8_t current_volume;

rt_thread_t beep_thread = RT_NULL;

/* Volume-scaled stereo LUT — NEVER modified during playback.
 * update_sine_table() rebuilds it once at the start of each beep. */
static rt_int16_t sine_table[SINE_TABLE_SIZE * 2];

/* ---- RT-Thread handles ---- */
static rt_sem_t    beep_sem      = RT_NULL;
static rt_mutex_t  beep_mutex    = RT_NULL;
static rt_device_t snd_dev       = RT_NULL;
static volatile rt_bool_t beep_active     = RT_FALSE;
static volatile rt_bool_t beep_led_enable = RT_TRUE;

extern volatile bool hold_browse_active;

/* ---- Rebuild sine_table for the given volume (0–100) ---- */
void update_sine_table(rt_uint8_t volume)
{
    if (volume > 100) volume = 100;
    /* Scale Q1.15 LUT values by volume. amp256 is amplitude × 256. */
    rt_int32_t amp256 = ((rt_int32_t)volume * (DAC_AMPLITUDE_CAP * 256 / 32767)) / 100;
    if (volume > 0 && amp256 < 4)
        amp256 = 4;  /* minimum audible floor */
    for (int i = 0; i < SINE_TABLE_SIZE; i++)
    {
        rt_int32_t s = ((rt_int32_t)sine_lut[i] * amp256) >> 8;
        s = CLAMP(s, -32768, 32767);
        sine_table[i * 2]     = (rt_int16_t)s;
        sine_table[i * 2 + 1] = (rt_int16_t)s;
    }
}

/* ---- Beep playback thread ---- */
void beep_control_thread(void *parameter)
{
    /* Last samplerate actually written to the audio device. Starts at 0 so
     * the very first beep always configures it once. */
    static rt_uint32_t configured_rate = 0;

    /* Local output buffer — lives on this thread's 1536-byte stack (256 B used).
     * NOT static: keeping it global would cost 256 bytes of the already-tight
     * .bss region; a per-call stack allocation is the right trade-off here. */
    rt_int16_t write_buf[SINE_TABLE_SIZE * 2];

    struct rt_audio_caps caps;

    while (1)
    {
        rt_sem_take(beep_sem, RT_WAITING_FOREVER);

        if (sd_switch_in_progress) {
//            rt_kprintf("beep skipped: sd_switch_in_progress\n");
            continue;
        }

        /* Pause MP3 playback if active. */
        rt_bool_t paused_mp3_for_beep = RT_FALSE;
        if (!sd_switch_in_progress &&
            !suppress_playback &&
            mp3_player_state_get() == PLAYER_STATE_PLAYING)
        {
            mp3_player_pause();
            paused_mp3_for_beep = RT_TRUE;
            rt_thread_mdelay(5);
        }
        rt_base_t saved_audio_sw = rt_pin_read(AUDIO_SWITCH_PIN);
        int earphone_now = (rt_pin_read(EARPHONE_DETECT_PIN) == PIN_LOW);
        rt_pin_write(AUDIO_SWITCH_PIN, earphone_now ? PIN_HIGH : PIN_LOW);

        rt_mutex_take(beep_mutex, RT_WAITING_FOREVER);
        beep_active = RT_TRUE;
        rt_mutex_release(beep_mutex);

        /* Force the SAME hardware mixer gain for every beep, regardless of
         * whether the call site remembered to set it. Previously only some
         * call sites (e.g. the power-on beep) did
         * mp3_player_volume_set(BEEP_NOTIFY_HW_VOL) first; others (e.g. the
         * SD-mount-fail beep) didn't, so their loudness silently depended on
         * whatever state.volume the user happened to have set. Doing it
         * here means that can never happen again, and callers no longer
         * need to do it themselves. */
        int saved_hw_vol = mp3_player_volume_get();
        mp3_player_volume_set(BEEP_NOTIFY_HW_VOL);

        /* Beep at the SAME sample rate the player is currently using (0 ==
         * nothing has ever been loaded yet, so fall back to the default).
         * Only touch the device if that rate actually differs from what's
         * already configured — normally it won't, since the MP3 decoder set
         * it when the track opened, so most beeps need no reconfigure at
         * all and there is nothing to restore afterwards. */
        rt_uint32_t beep_rate  = beep_rate_get();
        rt_uint32_t phase_step = beep_phase_step_for_rate(beep_rate);

        if (configured_rate != beep_rate)
        {
            memset(&caps, 0, sizeof(caps));
            caps.main_type = AUDIO_TYPE_MIXER;
            caps.sub_type  = AUDIO_DSP_SAMPLERATE;
            caps.udata.config.samplerate = beep_rate;
            rt_device_control(snd_dev, AUDIO_CTL_CONFIGURE, &caps);
            configured_rate = beep_rate;
        }

        /* Duration/fade windows in samples, at the rate just chosen above. */
        int total_samples = (int)(((rt_uint64_t)beep_rate * BEEP_DURATION_MS) / 1000);
        int cycles        = total_samples / SINE_TABLE_SIZE;   /* whole write_buf writes */
        int total_render  = cycles * SINE_TABLE_SIZE;           /* samples actually rendered */
        int fade_samples  = (int)(((rt_uint64_t)beep_rate * BEEP_FADE_MS) / 1000);
        if (fade_samples < 1) fade_samples = 1;

        /* Build clean sine_table ONCE — never touch it during playback. */
        update_sine_table(current_volume);

        if (beep_led_enable)
            led_beep_pulse_start();

        /* ----------------------------------------------------------------
         * Playback loop.
         *
         * For each output buffer of SINE_TABLE_SIZE stereo samples:
         *   1. Compute a fixed-point fade multiplier (fade_q8, range 0–256).
         *      Using integer Q8 instead of float avoids soft-FPU overhead and
         *      cumulative truncation error.
         *   2. Read from the pristine sine_table via a 32-bit phase
         *      accumulator (phase_step per sample) to produce the correct
         *      output frequency without altering the table.
         *   3. Write into write_buf, then send to the DAC.
         *
         * sine_table is NEVER written inside this loop.
         * ---------------------------------------------------------------- */
        int sample_index = 0;
        rt_uint32_t phase_acc = 0;   /* 32-bit DDS accumulator */

        for (int i = 0; i < cycles; i++)
        {
            if (!beep_active) break;

            for (int j = 0; j < SINE_TABLE_SIZE; j++)
            {
                /* Fixed-point fade envelope: 0..256 maps to 0.0..1.0 */
                int fade_q8;
                if (sample_index < fade_samples) {
                    /* Fade in */
                    fade_q8 = (sample_index * 256) / fade_samples;
                } else if (sample_index > (total_render - fade_samples)) {
                    /* Fade out */
                    fade_q8 = ((total_render - sample_index) * 256) / fade_samples;
                } else {
                    /* Steady — full amplitude */
                    fade_q8 = 256;
                }

                /* LUT index = top SINE_TABLE_SIZE_LOG2 bits of the accumulator. */
                int phase = phase_acc >> (PHASE_ACC_BITS - SINE_TABLE_SIZE_LOG2);

                /* Apply fade to the read-only sine_table. */
                rt_int32_t s = ((rt_int32_t)sine_table[phase * 2] * fade_q8) >> 8;
                s = CLAMP(s, -32768, 32767);
                write_buf[j * 2]     = (rt_int16_t)s;
                write_buf[j * 2 + 1] = (rt_int16_t)s;   /* stereo copy */

                /* Advance phase accumulator (wraps on 32-bit overflow). */
                phase_acc += phase_step;
                sample_index++;
            }

            rt_device_write(snd_dev, 0, write_buf, sizeof(write_buf));
        }

        if (beep_led_enable)
            led_beep_pulse_stop();

        /* Restore whatever hardware gain was active before this beep
         * (normally the user's state.volume) now that the tone is done. */
        mp3_player_volume_set(saved_hw_vol);

        /* Flush DAC output pipeline with silence frames.
         * write_buf is used (not sine_table), so sine_table stays valid. */
        rt_memset(write_buf, 0, sizeof(write_buf));
        for (int i = 0; i < 15; i++)
            rt_device_write(snd_dev, 0, write_buf, sizeof(write_buf));
        rt_thread_mdelay(40);

        /* Resume MP3 if we paused it for the beep. */
        if (paused_mp3_for_beep &&
            !sd_switch_in_progress &&
            !suppress_playback &&
            (mp3_player_state_get() == PLAYER_STATE_PAUSED) &&
            !stopwatchflag &&
            !hold_browse_active)
        {
            mp3_player_resume();
            rt_thread_mdelay(5);
        }

        rt_mutex_take(beep_mutex, RT_WAITING_FOREVER);
        beep_active = RT_FALSE;
        rt_mutex_release(beep_mutex);
        rt_pin_write(AUDIO_SWITCH_PIN, saved_audio_sw);
    }
}

/* ---- Internal trigger ---- */
static void play_beep_internal(rt_bool_t with_led)
{
//    rt_kprintf("single beep, led=%d\n", with_led);
    if (!snd_dev) return;

    beep_led_enable = with_led;

    if (rt_mutex_take(beep_mutex, rt_tick_from_millisecond(10)) == RT_EOK) {
        if (!beep_active)
            rt_sem_release(beep_sem);
        rt_mutex_release(beep_mutex);
    }
}

void play_beep(void)         { play_beep_internal(RT_TRUE);  }
void play_beep_no_led(void)  { play_beep_internal(RT_FALSE); }

void stop_beep_playback(void)
{
    rt_mutex_take(beep_mutex, RT_WAITING_FOREVER);
    beep_active = RT_FALSE;
    rt_mutex_release(beep_mutex);
}

void beep_wait_done(void)
{
    rt_tick_t deadline = rt_tick_get() + rt_tick_from_millisecond(2000);
    rt_thread_mdelay(10);
    while (beep_active) {
        if ((rt_int32_t)(rt_tick_get() - deadline) >= 0) break;
        rt_thread_mdelay(10);
    }
}

/* ---- Volume helpers ---- */
void play_beep_with_volume(rt_uint8_t volume)
{
    current_volume = (volume > 100) ? 100 : volume;
    play_beep();
}

void play_beep_with_volume_no_led(rt_uint8_t volume)
{
    current_volume = (volume > 100) ? 100 : volume;
    play_beep_no_led();
}

/* ---- Multi-beep functions ----
 * Always call beep_wait_done() between beeps.  Without it, the second
 * play_beep_internal() call arrives while beep_active == true and silently
 * drops the semaphore release, so only the first beep plays.
 * The inter-beep gap (rt_thread_mdelay) is counted from the moment the
 * previous beep finishes, giving a consistent-sounding rhythm. */

void play_double_beep(void)
{
//    rt_kprintf("play_double_beep\n");
    mp3_player_volume_set(BEEP_NOTIFY_HW_VOL);
    mp3_player_pause();

    play_beep_with_volume(50);
    beep_wait_done();
    rt_thread_mdelay(80);
    play_beep_with_volume(50);
    beep_wait_done();
}

void play_double_beep_no_led(void)
{
//    rt_kprintf("play_double_beep_no_led\n");
    mp3_player_volume_set(BEEP_NOTIFY_HW_VOL);
    mp3_player_pause();

    play_beep_with_volume_no_led(50);
    beep_wait_done();
    rt_thread_mdelay(80);
    play_beep_with_volume_no_led(50);
    beep_wait_done();
}

void play_triple_beep(void)
{
//    rt_kprintf("play_triple_beep\n");
    mp3_player_volume_set(BEEP_NOTIFY_HW_VOL);

    play_beep_with_volume(50);
    beep_wait_done();
    rt_thread_mdelay(80);
    play_beep_with_volume(50);
    beep_wait_done();
    rt_thread_mdelay(80);
    play_beep_with_volume(50);
    beep_wait_done();
}

void play_triple_beep_no_led(void)
{
//    rt_kprintf("play_triple_beep_no_led\n");
    mp3_player_volume_set(BEEP_NOTIFY_HW_VOL);
    mp3_player_pause();

    play_beep_with_volume_no_led(50);
    beep_wait_done();
    rt_thread_mdelay(80);
    play_beep_with_volume_no_led(50);
    beep_wait_done();
    rt_thread_mdelay(80);
    play_beep_with_volume_no_led(50);
    beep_wait_done();
}

/* Called from play_mode.c (volume_down boundary feedback). */
void play_double_beep_with_volume(rt_uint8_t volume)
{
    current_volume = (volume > 100) ? 100 : volume;

    play_beep_with_volume(current_volume);
    beep_wait_done();
    rt_thread_mdelay(80);
    play_beep_with_volume(current_volume);
    beep_wait_done();
}

void play_5_beep(void)
{
    play_triple_beep();
    rt_thread_mdelay(120);
    play_double_beep();
}

/* ---- Initialization ---- */
int beeper_init(void)
{
    beep_sem = rt_sem_create("beep", 0, RT_IPC_FLAG_FIFO);
    if (!beep_sem) { return -1; }

    beep_mutex = rt_mutex_create("beep_mutex", RT_IPC_FLAG_FIFO);
    if (!beep_mutex) { return -1; }

    snd_dev = rt_device_find(SOUND_DEV_NAME);
    if (!snd_dev || rt_device_open(snd_dev, RT_DEVICE_OFLAG_WRONLY) != RT_EOK) {
//        rt_kprintf("Failed to open sound device '%s'\n", SOUND_DEV_NAME);
        return -1;
    }

    struct rt_audio_caps caps;
    memset(&caps, 0, sizeof(caps));

    caps.main_type = AUDIO_TYPE_OUTPUT;
    caps.sub_type  = AUDIO_DSP_SAMPLERATE;
    caps.udata.config.samplerate = BEEP_DEFAULT_SAMPLE_RATE;  /* no track loaded yet */
    rt_device_control(snd_dev, AUDIO_CTL_CONFIGURE, &caps);

    caps.sub_type = AUDIO_DSP_CHANNELS;
    caps.udata.config.channels = 2;
    rt_device_control(snd_dev, AUDIO_CTL_CONFIGURE, &caps);

    caps.sub_type = AUDIO_DSP_SAMPLEBITS;
    caps.udata.config.samplebits = 16;
    rt_device_control(snd_dev, AUDIO_CTL_CONFIGURE, &caps);

    caps.main_type    = AUDIO_TYPE_MIXER;
    caps.sub_type     = AUDIO_MIXER_VOLUME;
    caps.udata.value  = (current_volume > 100) ? 100 : current_volume;
    rt_device_control(snd_dev, AUDIO_CTL_CONFIGURE, &caps);

    update_sine_table(current_volume);

    beep_thread = rt_thread_create("beep_ctrl", beep_control_thread,
                                   RT_NULL, 1536, 12, 10);
    if (beep_thread)
        rt_thread_startup(beep_thread);
    else
        return -1;

//    rt_kprintf("DAC-based Beeper Initialized — %d Hz, %d ms, phase_step=%d\n",
//               BEEP_FREQ_HZ, BEEP_DURATION_MS, BEEP_PHASE_STEP);
    return 0;
}

void beep_deinit(void)
{
    if (beep_thread) { rt_thread_delete(beep_thread); beep_thread = RT_NULL; }
    if (beep_mutex)  { rt_mutex_release(beep_mutex); rt_mutex_delete(beep_mutex); beep_mutex = RT_NULL; }
}

INIT_APP_EXPORT(beeper_init);

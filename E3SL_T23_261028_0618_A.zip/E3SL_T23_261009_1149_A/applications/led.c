#include <rtthread.h>
#include <rtdevice.h>
#include "Gpio_Pins_Defines.h"  // Make sure Green_led and Red_led are defined
#include "led.h"
#include "cable.h"
#include "play_mode.h"
#include "mp3_player.h"
/* LED operating * modes */


#define debug_prints 0

rt_bool_t player_on    = 0;

rt_bool_t battery_low  = 0;
rt_bool_t battery_full = 0;
rt_bool_t data_tranfer = 0;




led_mode_t current_mode = LED_MODE_SOLID;
static uint16_t active_led;  // Set in update_led_color()
volatile bool ledflag=false;

void off_state(void){
    rt_pin_write(Red_led, PIN_HIGH);
    rt_pin_write(Green_led, PIN_HIGH);
}
void update_led_color(void)
{

    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);

    if (sd_det_flag == 0)
    {
        rt_pin_write(Green_led, PIN_LOW);   // ON
        rt_pin_write(Red_led, PIN_HIGH);    // OFF
        active_led = Green_led;
    }
    else if (sd_det_flag == 1)
    {
        rt_pin_write(Green_led, PIN_HIGH);  // OFF
        rt_pin_write(Red_led, PIN_LOW);     // ON
        active_led = Red_led;
    }

    else if(sd_det_flag == 3){
        led_PAUSE_blink();
    }

}





void start_task(led_mode_t mode)
{
    current_mode = mode;
}

void stop_task(void)
{
    current_mode = LED_MODE_SOLID;
}





static void led_thread_entry(void *param)
{
    static rt_uint8_t last_sd_flag = 0xFF;

    while (1)
    {
        /* 1) sd_det_flag change - inlined update_led_color() */
        if (last_sd_flag != sd_det_flag)
        {
            if (ledflag)
            {
                last_sd_flag = sd_det_flag;
                rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
                rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);
                if (sd_det_flag == 0)
                {
                    rt_pin_write(Green_led, PIN_LOW);
                    rt_pin_write(Red_led,   PIN_HIGH);
                    active_led = Green_led;
                }
                else if (sd_det_flag == 1)
                {
                    rt_pin_write(Green_led, PIN_HIGH);
                    rt_pin_write(Red_led,   PIN_LOW);
                    active_led = Red_led;
                }
                else if (sd_det_flag == 3)
                {
                    uint16_t inact = (active_led == Green_led) ? Red_led : Green_led;
                    rt_pin_write(inact,      PIN_HIGH);
                    rt_pin_write(active_led, PIN_LOW);  rt_thread_mdelay(100);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }
                    rt_pin_write(active_led, PIN_HIGH); rt_thread_mdelay(100);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }
                    rt_pin_write(active_led, PIN_LOW);  rt_thread_mdelay(100);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }
                    rt_pin_write(active_led, PIN_HIGH); rt_thread_mdelay(500);
                }
            }
        }

        /* 2) Charging / battery states - all inlined, no sub-function calls */
        if (ledflag || charging)
        {
            int player_state = mp3_player_state_get();
            if (charging && (player_state == PLAYER_STATE_PAUSED || current_mode == LED_MODE_PAUSE))
            {
                rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
                rt_pin_mode(Red_led, PIN_MODE_OUTPUT);

                active_led = (sd_det_flag == 1) ? Red_led : Green_led;
                uint16_t inactive_led = (active_led == Green_led) ? Red_led : Green_led;

                if (!battery_full)
                {
                    // Pattern: 200ms SD-color > 200ms Orange > 200ms SD-color > 800ms Orange

                    // Step 1: 200ms SD-color (active_led ON, inactive OFF)
                    rt_pin_write(inactive_led, PIN_HIGH);
                    rt_pin_write(active_led,   PIN_LOW);
                    rt_thread_mdelay(200);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }

                    // Step 2: 200ms Orange (both ON)
                    rt_pin_write(inactive_led, PIN_LOW);
                    rt_thread_mdelay(200);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }

                    // Step 3: 200ms SD-color (active_led ON, inactive OFF)
                    rt_pin_write(inactive_led, PIN_HIGH);
                    rt_thread_mdelay(200);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }

                    // Step 4: 800ms Orange (both ON)
                    rt_pin_write(inactive_led, PIN_LOW);
                    rt_thread_mdelay(800);
                }
                else
                {
                    // Full charge + pause: same pattern but battery_full
                    // Pattern: 200ms SD-color > 200ms Orange > 200ms SD-color > 800ms Orange

                    // Step 1: 200ms SD-color
                    rt_pin_write(inactive_led, PIN_HIGH);
                    rt_pin_write(active_led,   PIN_LOW);
                    rt_thread_mdelay(200);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }

                    // Step 2: 200ms Orange
                    rt_pin_write(inactive_led, PIN_LOW);
                    rt_thread_mdelay(200);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }

                    // Step 3: 200ms SD-color
                    rt_pin_write(inactive_led, PIN_HIGH);
                    rt_thread_mdelay(200);
                    if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }

                    // Step 4: 800ms Orange
                    rt_pin_write(inactive_led, PIN_LOW);
                    rt_thread_mdelay(800);
                }

                continue;
            }
            else if (charging && player_state == PLAYER_STATE_STOPED)
            {
                if (!battery_full)
                {
                    /* playerOFF_Charging: orange blink 500/500 */
                    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
                    rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);
                    rt_pin_write(Green_led, PIN_LOW);
                    rt_pin_write(Red_led,   PIN_LOW);
                    rt_thread_mdelay(500);
                    rt_pin_write(Green_led, PIN_HIGH);
                    rt_pin_write(Red_led,   PIN_HIGH);
                    rt_thread_mdelay(500);
                }
                else
                {
                    /* battery_full + player off: solid orange */
                    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
                    rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);
                    rt_pin_write(Green_led, PIN_LOW);
                    rt_pin_write(Red_led,   PIN_LOW);
                    rt_thread_mdelay(1000);
                }
                continue;
            }
            else if (charging && player_state == PLAYER_STATE_PLAYING)
            {
                if (!battery_full)
                {
                    /* playerON_Charging: orange flash then SD-color
                     * (green for internal SD, red for external SD) */
                    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
                    rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);
                    rt_pin_write(Green_led, PIN_LOW);
                    rt_pin_write(Red_led,   PIN_LOW);
                    rt_thread_mdelay(200);
                    if (sd_det_flag == 1)
                    {
                        /* External SD -> RED */
                        rt_pin_write(Green_led, PIN_HIGH);
                        rt_pin_write(Red_led,   PIN_LOW);
                        active_led = Red_led;
                    }
                    else
                    {
                        /* Internal SD -> GREEN */
                        rt_pin_write(Green_led, PIN_LOW);
                        rt_pin_write(Red_led,   PIN_HIGH);
                        active_led = Green_led;
                    }
                    rt_thread_mdelay(2000);
                }
                else
                {
                    /* battery_full + player on: green=internal, red=external */
                    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
                    rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);
                    if (sd_det_flag == 1)
                    {
                        rt_pin_write(Green_led, PIN_HIGH);   // OFF
                        rt_pin_write(Red_led,   PIN_LOW);    // solid RED (external)
                    }
                    else
                    {
                        rt_pin_write(Green_led, PIN_LOW);    // solid GREEN (internal)
                        rt_pin_write(Red_led,   PIN_HIGH);   // OFF
                    }
                    rt_thread_mdelay(1000);
                }
                continue;
            }
            else if (battery_low)
                        {
                            /* Low battery: 2s Red blink (20x 50ms ON/OFF) then 14s normal */
                            rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
                            rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);

                            /* --- 2s: 20x Red 50ms ON / 50ms OFF --- */
                            rt_pin_write(Green_led, PIN_HIGH);
                            for (int i = 0; i < 20; i++)
                            {
                                rt_pin_write(Red_led, PIN_LOW);
                                rt_thread_mdelay(50);
                                rt_pin_write(Red_led, PIN_HIGH);
                                rt_thread_mdelay(50);
                            }


                            /* --- 14s: normal LED, respecting pause/play state --- */
                            active_led = (sd_det_flag == 1) ? Red_led : Green_led;
                            {
                                rt_tick_t end_tick = rt_tick_get() + rt_tick_from_millisecond(14000);
                                while ((rt_int32_t)(rt_tick_get() - end_tick) < 0)
                                {
                                    uint16_t inact = (active_led == Green_led) ? Red_led : Green_led;
                                    if (mp3_player_state_get() == PLAYER_STATE_PAUSED ||
                                        current_mode == LED_MODE_PAUSE)
                                    {
                                        rt_pin_write(inact,      PIN_HIGH);
                                        rt_pin_write(active_led, PIN_LOW);  rt_thread_mdelay(100);
                                        if (current_mode != LED_MODE_PAUSE) { update_led_color(); break; }
                                        rt_pin_write(active_led, PIN_HIGH); rt_thread_mdelay(100);
                                        if (current_mode != LED_MODE_PAUSE) { update_led_color(); break; }
                                        rt_pin_write(active_led, PIN_LOW);  rt_thread_mdelay(100);
                                        if (current_mode != LED_MODE_PAUSE) { update_led_color(); break; }
                                        rt_pin_write(active_led, PIN_HIGH); rt_thread_mdelay(500);
                                    }
                                    else
                                    {
                                        rt_pin_write(inact,      PIN_HIGH);
                                        rt_pin_write(active_led, PIN_LOW);
                                        rt_thread_mdelay(100);
                                    }
                                }
                            }

                            continue;
                        }
        }
        else if (battery_full && charging)
        {
            /* Player off + fully charged: solid orange even when ledflag=false */
            rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
            rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);
            rt_pin_write(Green_led, PIN_LOW);
            rt_pin_write(Red_led,   PIN_LOW);
            rt_thread_mdelay(1000);
            continue;
        }

        /* 3) Normal mode handling - inlined led_PAUSE_blink and led_OFF */
        if (current_mode == LED_MODE_PAUSE)
        {
            if (ledflag)
            {
                uint16_t inact = (active_led == Green_led) ? Red_led : Green_led;
                rt_pin_mode(active_led, PIN_MODE_OUTPUT);
                rt_pin_mode(inact,      PIN_MODE_OUTPUT);
                rt_pin_write(inact,      PIN_HIGH);
                rt_pin_write(active_led, PIN_LOW);  rt_thread_mdelay(100);
                if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }
                rt_pin_write(active_led, PIN_HIGH); rt_thread_mdelay(100);
                if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }
                rt_pin_write(active_led, PIN_LOW);  rt_thread_mdelay(100);
                if (current_mode != LED_MODE_PAUSE) { update_led_color(); continue; }
                rt_pin_write(active_led, PIN_HIGH); rt_thread_mdelay(500);
            }
            else
                rt_thread_mdelay(100);
        }
        else if (current_mode == LED_MODE_OFF)
        {
            if (ledflag)
            {
                uint16_t inact = (active_led == Green_led) ? Red_led : Green_led;
                rt_pin_mode(active_led, PIN_MODE_OUTPUT);
                rt_pin_mode(inact,      PIN_MODE_OUTPUT);
                rt_pin_write(active_led, PIN_HIGH);
                rt_thread_mdelay(10);
            }
            else
                rt_thread_mdelay(100);
        }
        else
        {
            rt_thread_mdelay(100);
        }
    }
}



int led_init(void)
{

    rt_thread_t tid = rt_thread_create("led_task",
                                       led_thread_entry,
                                       RT_NULL,
                                       768, 10, 10);

    if (tid != RT_NULL)
    {
        rt_thread_startup(tid);
        return 0;
    }

    return -1;
}
INIT_APP_EXPORT(led_init);



void led_PAUSE_blink(void)
{
    uint16_t inactive_led = (active_led == Green_led) ? Red_led : Green_led;

    rt_pin_mode(active_led, PIN_MODE_OUTPUT);
    rt_pin_mode(inactive_led, PIN_MODE_OUTPUT);

    // Turn off inactive LED
    rt_pin_write(inactive_led, PIN_HIGH);  // OFF
    // Blink active LED
    rt_pin_write(active_led, PIN_LOW);   // ON
    rt_thread_mdelay(100);
    rt_pin_write(active_led, PIN_HIGH);  // OFF
    rt_thread_mdelay(100);
    rt_pin_write(active_led, PIN_LOW);   // ON
    rt_thread_mdelay(100);
    rt_pin_write(active_led, PIN_HIGH);  // OFF
    rt_thread_mdelay(500);

}

void led_beep_pulse_start(void)
{
    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);

    if (sd_det_flag == 1)
    {
        // External SD: blink RED only
        rt_pin_write(Green_led, PIN_HIGH);  // Green OFF
        rt_pin_write(Red_led, PIN_LOW);     // Red ON
    }
    else
    {
        // Internal SD: blink GREEN only
        rt_pin_write(Red_led, PIN_HIGH);    // Red OFF
        rt_pin_write(Green_led, PIN_LOW);   // Green ON
    }
}

void led_beep_pulse_stop(void)
{
    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);

    if (sd_det_flag == 1)
    {
        // External SD: turn RED off after beep pulse
        rt_pin_write(Red_led, PIN_HIGH);
        rt_pin_write(Green_led, PIN_HIGH);
    }
    else
    {
        // Internal SD: turn GREEN off after beep pulse
        rt_pin_write(Green_led, PIN_HIGH);
        rt_pin_write(Red_led, PIN_HIGH);
    }
}

void led_OFF(void)
{
    uint16_t inactive_led = (active_led == Green_led) ? Red_led : Green_led;

     rt_pin_mode(active_led, PIN_MODE_OUTPUT);
     rt_pin_mode(inactive_led, PIN_MODE_OUTPUT);
    rt_pin_write(active_led, PIN_HIGH);
    rt_thread_mdelay(10);
}


void USBdata_tranfer(void)
{
    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);
    rt_pin_write(Green_led, PIN_LOW);
    rt_thread_mdelay(500);
    rt_pin_write(Green_led, PIN_HIGH);
    rt_thread_mdelay(500);
    rt_pin_write(Red_led, PIN_LOW);
    rt_thread_mdelay(500);
    rt_pin_write(Red_led, PIN_HIGH);
    rt_thread_mdelay(500);



}

void playerOFF_Charging(void)
{

    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);

    rt_pin_write(Green_led, PIN_LOW);
    rt_pin_write(Red_led, PIN_LOW);
    rt_thread_mdelay(500);
    rt_pin_write(Green_led, PIN_HIGH);
    rt_pin_write(Red_led, PIN_HIGH);
    rt_thread_mdelay(500);


}


void playerON_Charging(void)
{
    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);

    rt_pin_write(Green_led, PIN_LOW);
    rt_pin_write(Red_led, PIN_LOW);
    rt_thread_mdelay(200);

    update_led_color();     // direct transition to green, no OFF gap
    rt_thread_mdelay(2000);
}

void battery_fullcharge(void)
{

    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);

    // NEW
    if (Playoffcharge)
    {
        if (sd_det_flag == 1)
        {
            rt_pin_write(Green_led, PIN_HIGH);   // solid RED (external)
            rt_pin_write(Red_led,   PIN_LOW);
        }
        else
        {
            rt_pin_write(Green_led, PIN_LOW);    // solid GREEN (internal)
            rt_pin_write(Red_led,   PIN_HIGH);
        }
    }
    else
    {
        rt_pin_write(Green_led, PIN_LOW);        // solid ORANGE (player off)
        rt_pin_write(Red_led,   PIN_LOW);
    }
}

void battery_lowcharge(void)
{
    /* Low battery: 2s Red blink (20x 50ms ON/OFF) then 14s normal */
    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led,   PIN_MODE_OUTPUT);

    /* --- 2s: 20x Red 50ms ON / 50ms OFF --- */
    rt_pin_write(Green_led, PIN_HIGH);
    for (int i = 0; i < 20; i++)
    {
        rt_pin_write(Red_led, PIN_LOW);
        rt_thread_mdelay(50);
        rt_pin_write(Red_led, PIN_HIGH);
        rt_thread_mdelay(50);
    }

    /* --- 14s: normal LED, respecting pause/play state --- */
    active_led = (sd_det_flag == 1) ? Red_led : Green_led;
    {
        rt_tick_t end_tick = rt_tick_get() + rt_tick_from_millisecond(14000);
        while ((rt_int32_t)(rt_tick_get() - end_tick) < 0)
        {
            uint16_t inact = (active_led == Green_led) ? Red_led : Green_led;
            if (mp3_player_state_get() == PLAYER_STATE_PAUSED ||
                current_mode == LED_MODE_PAUSE)
            {
                rt_pin_write(inact,      PIN_HIGH);
                rt_pin_write(active_led, PIN_LOW);  rt_thread_mdelay(100);
                if (current_mode != LED_MODE_PAUSE) { update_led_color(); break; }
                rt_pin_write(active_led, PIN_HIGH); rt_thread_mdelay(100);
                if (current_mode != LED_MODE_PAUSE) { update_led_color(); break; }
                rt_pin_write(active_led, PIN_LOW);  rt_thread_mdelay(100);
                if (current_mode != LED_MODE_PAUSE) { update_led_color(); break; }
                rt_pin_write(active_led, PIN_HIGH); rt_thread_mdelay(500);
            }
            else
            {
                rt_pin_write(inact,      PIN_HIGH);
                rt_pin_write(active_led, PIN_LOW);
                rt_thread_mdelay(100);
            }
        }
    }
}

void update_led_off(void)
{
    rt_pin_mode(Green_led, PIN_MODE_OUTPUT);
    rt_pin_mode(Red_led, PIN_MODE_OUTPUT);

    rt_pin_write(Green_led, PIN_HIGH);
    rt_pin_write(Red_led, PIN_HIGH);
}


/*
 * Copyright (c) 2020-2021, Bluetrum Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Date           Author       Notes
 * 2020-12-12     greedyhao    first implementation
 */

#include <board.h>
#include <mp3_player.h>


#define DBG_TAG              "drv.snd_dev"
#define DBG_LVL              DBG_INFO
#include <rtdbg.h>

#define SAI_AUDIO_FREQUENCY_8K      ((uint32_t)  8000u)
#define SAI_AUDIO_FREQUENCY_11K     ((uint32_t) 11025u)
#define SAI_AUDIO_FREQUENCY_12K     ((uint32_t) 12000u)
#define SAI_AUDIO_FREQUENCY_16K     ((uint32_t) 16000u)
#define SAI_AUDIO_FREQUENCY_22K     ((uint32_t) 22050u)
#define SAI_AUDIO_FREQUENCY_32K     ((uint32_t) 32000u)
#define SAI_AUDIO_FREQUENCY_44K     ((uint32_t) 44100u)
#define SAI_AUDIO_FREQUENCY_48K     ((uint32_t) 48000u)
#define SAI_AUDIO_FREQUENCY_38K     ((uint32_t) 38000u)
#define SAI_AUDIO_FREQUENCY_24K     ((uint32_t) 24000u)

#define TX_FIFO_SIZE                    (8192)

typedef struct {
    uint32_t in_hz, out_hz;
    uint64_t pos_q32;     /* Q32.32 */
    uint64_t step_q32;    /* (in_hz / out_hz) in Q32.32 */
    uint32_t prev32;      /* last LR frame */
    rt_bool_t have_prev;
    rt_bool_t enabled;
} rs_state_t;


static rs_state_t g_rs = {0};
static void rs_disable(void) { g_rs.enabled = RT_FALSE; g_rs.step_q32 = 0; g_rs.pos_q32 = 0; g_rs.have_prev = RT_FALSE; }

struct sound_config {
    uint32_t samplerate;
    uint8_t channels;
    uint8_t samplebits;
    uint8_t volume;
};

static struct sound_config current_config;

struct sound_device
{
    struct rt_audio_device audio;
    struct rt_audio_configure replay_config;
    rt_sem_t    semaphore;
    rt_thread_t thread;
    rt_uint8_t *tx_fifo;
    rt_uint8_t *rx_fifo;
    rt_uint8_t  volume;
    rt_uint8_t  dma_to_aubuf;
};

static struct sound_device snd_dev = {0};


void sampleRate(void)
{

}

//apll = 采样率*ADPLL_DIV*512
//audio pll init
void adpll_init(uint8_t out_spr)
{
    //hal_mdelay(100);
    PLL1CON &= ~(BIT(16) | BIT(17));                //PLL1 refclk select xosc26m
    CLKCON2  &= ~(BIT(4)| BIT(5) | BIT(6) | BIT(7));

    PLL1CON &= ~(BIT(3) | BIT(4) | BIT(5));
    PLL1CON |= BIT(3);                              //Select PLL/VCO frequency band (PLL大于206M vcos = 0x01, 否则为0)

    PLL1CON |= BIT(12);                             //enable pll1 ldo
    hal_mdelay(1);
    PLL1CON |= BIT(18);                             //pll1 sdm enable

    if (out_spr) {
        CLKCON2  |= BIT(4) | BIT(7);                //adpll_div = 10
        PLL1DIV = (225.792 * 65536) / 26;            // 225.792MHz for 44.1kHz
        // sys.aupll_type = 1;
    } else {
        CLKCON2  |= BIT(5) | BIT(7);                //adpll_div = 11
        PLL1DIV = (245.76 * 65536) / 26;          // 245.76MHz for 48kHz
        // sys.aupll_type = 0;
    }
    hal_mdelay(1);
    PLL1CON |= BIT(20);                             //update pll1div
    PLL1CON |= BIT(6);                              //enable analog pll1
   // hal_mdelay(10);                                  //wait pll1 stable
}

void dac_stop(void)
{
    // 1. Mute PA output immediately
    AUANGCON1 |= BIT(3);    // PA mute ON (mute amplifier)

    rt_thread_mdelay(5);    // short delay for mute to take effect

    // 2. Disable LPF→PA path and DAC channels
    AUANGCON1 &= ~BIT(12);  // disable LPF2PA
    AUANGCON1 &= ~(BIT(0) | BIT(1));  // disable DAC right & left

    // 3. Disable DAC analog blocks
    AUANGCON0 &= ~(BIT(15) | BIT(16) | BIT(17) | BIT(18)); // d2a, lpf, audpa, audpa_dly

    // 4. Disable bias, LDOs, and VCM safely
    AUANGCON0 &= ~BIT(9);   // VCM disable
    AUANGCON0 &= ~BIT(2);   // LDOL disable
    AUANGCON0 &= ~(BIT(0) | BIT(1) | BIT(3)); // bg, ldoh, bias disable

    // 5. Optional: disable internal buffer
    AUANGCON1 &= ~BIT(29);  // disable vcmbuf

    rt_thread_mdelay(5);    // settle time
//    rt_kprintf("DAC_disabled\n");
}

void dac_start(void)
{

    AUANGCON0 |= BIT(0) | BIT(1) | BIT(3); // bg ldoh bias enable

    AUANGCON0 &= ~(BIT(6)|BIT(5)|BIT(4));  // LDOH voltage select：3bit
    AUANGCON0 |= (3<<4); // 2.4/2.5/2.7/2.9/3.1/3.2

    AUANGCON0 |= BIT(2);           // LDOL enable

    AUANGCON0 |= BIT(9); //VCM enable
    AUANGCON0 &= ~(BIT(13)|BIT(12)); // VCM voltage select, 2bit
    AUANGCON0 |= (2<<12);

    AUANGCON0 |= BIT(15) | BIT(16) | BIT(17) | BIT(18); // d2a lpf audpa audpa_dly

    AUANGCON0 &= ~BIT(11); //VCM type: 0-->res divider with off-chip cap; 1-->internal VCM
    //AUANGCON0 |= BIT(11);

    AUANGCON0 &= ~BIT(19); // dac type: 0-->SC; 1-->SR
    //AUANGCON0 |= BIT(19);

    AUANGCON0 |= BIT(20); // pa type: 0-->diff; 1-->3.3V single

    AUANGCON3 &= ~(0x7<<4); //BIT[6:4]=PA_GF[2:0]
    AUANGCON3 |= (0<<4);
    AUANGCON3 &= ~(0xf); //BIT[3:0]=PA_GX[3:0]
    AUANGCON3 |= 0;

    AUANGCON3 &= ~(0xF<<8); //BIT[11:8]=PA2_GX[3:0]
    AUANGCON3 |= (0<<8);
    AUANGCON3 &= ~(0x7<<12); //BIT[14:12]=PA2_GF[2:0]
    AUANGCON3 |= (0<<12);

    AUANGCON1 |= BIT(0) | BIT(1); // dac enable: BIT(0)-->right channel; BIT(1)-->left channel
    //AUANGCON1 &= ~BIT(1); //disable left channel

    AUANGCON1 |= BIT(12); // lpf2pa enable

    AUANGCON1 &= ~BIT(29); // vcmbuf enable: 0-->disable
    //AUANGCON1 |= BIT(29);

    //AUANGCON1 |= BIT(30); // mirror enable

    //AUANGCON2 |= BIT(29) | BIT(30); // adc mute

    //AUANGCON1 |= BIT(3);  // pa mute

    AUANGCON1 &= ~BIT(3);

}

RT_SECTION(".irq.audio")
void audio_sem_post(void)
{
    rt_sem_release(snd_dev.semaphore);
}

void audio_sem_pend(void)
{
    rt_sem_take(snd_dev.semaphore, RT_WAITING_FOREVER);
}

void saia_frequency_set(uint32_t frequency)
{
    uint32_t code = 0;
       uint32_t hw_rate = 48000;
       rt_bool_t rs = RT_FALSE;
//       rt_kprintf("frequency = %d\n", frequency);
       //rt_kprintf("SAMPLERATE= %d\n", snd_dev.replay_config.samplerate);
       //frequency= 0u;
       if (frequency == 0) frequency = 44100; /* guard */

       if      (frequency == 48000u) { code = 0; hw_rate = 48000u; }
       else if (frequency == 44100u) { code = 1; hw_rate = 44100u; }
       else if (frequency == 32000u) { code = 3; hw_rate = 32000u; }
       else if (frequency == 24000u) { code = 0; hw_rate = 48000u; rs = RT_TRUE; } /* 24k needs resampling */
       else if (frequency == 16000u) { code = 3; hw_rate = 32000u; }
       else if (frequency ==  8000u) { code = 3; hw_rate = 32000u; rs = RT_TRUE; } /* 8k needs resampling */
       else if (frequency == 11025u) { code = 1; hw_rate = 44100u; rs = RT_TRUE; }
       else if (frequency == 12000u) { code = 0; hw_rate = 48000u; rs = RT_TRUE; }
       else {
           /* unknown: stick to nearest family */
           if (frequency % 11025u == 0) { code = 1; hw_rate = 44100u; }
           else                         { code = 0; hw_rate = 48000u; }
           rs = RT_FALSE;
       }
//       rt_kprintf("frequency updated = %d %ld\n", frequency,hw_rate);
//    frequency = 8000u;
//    code=15;
//    hw_rate =  8000u;

    /* set hw code */
    DACDIGCON0 &= ~(0xFu << 2);
   // rt_kprintf("DACDIGCON0 = %d\n", DACDIGCON0);
    DACDIGCON0 |= (code << 2);
    //rt_kprintf("DACDIGCON0 = %d\n", DACDIGCON0);

    DACDIGCON0 |= BIT(6);  /* latch */
    //DACDIGCON0=68;
   // rt_kprintf("DACDIGCON0 = %d\n", DACDIGCON0);

    /* (Re)configure resampler */
    if (rs) {
        g_rs.in_hz     = frequency;
        g_rs.out_hz    = hw_rate;
        g_rs.pos_q32   = 0;
        g_rs.have_prev = RT_FALSE;
        g_rs.enabled   = RT_TRUE;
        g_rs.step_q32  = (((uint64_t)frequency << 32) / hw_rate);
    } else {
        rs_disable();
    }

   // rt_kprintf("g_rs.out_hz = %d  g_rs.step_q32 =%d \n", g_rs.out_hz, g_rs.step_q32);

  //  rt_kprintf("freq req=%u, hw=%u code=%lu%s\n",
             //  frequency, hw_rate, (unsigned long)code, rs ? " [rs]" : "");
}

void saia_channels_set(uint8_t channels)
{
//    LOG_D("saia_channels_set=%d", channels);
    if (channels == 1) {
        AU0LMIXCOEF = 0x00007FFF;
        AU1LMIXCOEF = 0x00007FFF;
        DACDIGCON0 |= BIT(7);
        DACDIGCON0 |= BIT(8);
        AUANGCON1 &= ~BIT(0);
    } else {
        AUANGCON1 |= BIT(0);
        DACDIGCON0 &= ~BIT(7);
        DACDIGCON0 &= ~BIT(8);
    }
}

void saia_volume_set(rt_uint8_t volume)
{
    if (volume > 100)
        volume = 100;

    uint32_t dvol = volume * 163; // max is 0x7ffff
//    LOG_D("dvol=0x%x", dvol);
    DACVOLCON = dvol | (0x02 << 16); // dac fade in
}
void saia_volume_set_immediate(rt_uint8_t volume)
{
    if (volume > 100)
        volume = 100;
    uint32_t dvol = volume * 163;
    DACVOLCON = dvol;   /* no fade — instant write for user volume control */
}

uint8_t saia_volume_get(void)
{
    return ((DACVOLCON & 0xffff) / 163);
}

static rt_err_t sound_getcaps(struct rt_audio_device *audio, struct rt_audio_caps *caps)
{
    rt_err_t result = RT_EOK;
    struct sound_device *snd_dev = RT_NULL;

    RT_ASSERT(audio != RT_NULL);
    snd_dev = (struct sound_device *)audio->parent.user_data;

    switch (caps->main_type)
    {
    case AUDIO_TYPE_QUERY: /* qurey the types of hw_codec device */
    {
        switch (caps->sub_type)
        {
        case AUDIO_TYPE_QUERY:
                    // Add capability to query current config
                    caps->udata.mask = AUDIO_TYPE_OUTPUT | AUDIO_TYPE_MIXER | AUDIO_TYPE_QUERY;
                    break;

        default:
            result = -RT_ERROR;
            break;
        }

        break;
    }

    case AUDIO_TYPE_OUTPUT: /* Provide capabilities of OUTPUT unit */
    {
        switch (caps->sub_type)
        {
        case AUDIO_DSP_PARAM:
            caps->udata.config.samplerate   = snd_dev->replay_config.samplerate;
            caps->udata.config.channels     = snd_dev->replay_config.channels;
            caps->udata.config.samplebits   = snd_dev->replay_config.samplebits;
            break;

        case AUDIO_DSP_SAMPLERATE:
            caps->udata.config.samplerate   = snd_dev->replay_config.samplerate;
            break;

        case AUDIO_DSP_CHANNELS:
            caps->udata.config.channels     = snd_dev->replay_config.channels;
            break;

        case AUDIO_DSP_SAMPLEBITS:
            caps->udata.config.samplebits   = snd_dev->replay_config.samplebits;
            break;

        default:
            result = -RT_ERROR;
            break;
        }

        break;
    }

    case AUDIO_TYPE_MIXER: /* report the Mixer Units */
    {
        switch (caps->sub_type)
        {
        case AUDIO_MIXER_QUERY:
            caps->udata.mask = AUDIO_MIXER_VOLUME;
            break;

        case AUDIO_MIXER_VOLUME:
            caps->udata.value =  saia_volume_get();
            break;

        default:
            result = -RT_ERROR;
            break;
        }

        break;
    }

    default:
        result = -RT_ERROR;
        break;
    }

    return RT_EOK;
}

static rt_err_t sound_configure(struct rt_audio_device *audio, struct rt_audio_caps *caps)
{
    rt_err_t result = RT_EOK;
    struct sound_device *snd_dev = RT_NULL;

    RT_ASSERT(audio != RT_NULL);
    snd_dev = (struct sound_device *)audio->parent.user_data;

    switch (caps->main_type)
    {
    case AUDIO_TYPE_MIXER:
    {
        switch (caps->sub_type)
        {
        case AUDIO_MIXER_VOLUME:
        {
            rt_uint8_t volume = caps->udata.value;
            current_config.volume = caps->udata.value;
            saia_volume_set(volume);
            snd_dev->volume = volume;
//            LOG_D("set volume %d", volume);
            break;
        }

        case AUDIO_MIXER_EXTEND:
            snd_dev->dma_to_aubuf = caps->udata.value;
        break;

        default:
            result = -RT_ERROR;
            break;
        }

        break;
    }

    case AUDIO_TYPE_OUTPUT:
    {
        switch (caps->sub_type)
        {
        case AUDIO_DSP_PARAM:
        {
            current_config.samplerate = caps->udata.config.samplerate;
            current_config.channels = caps->udata.config.channels;
            current_config.samplebits = caps->udata.config.samplebits;

            /* set samplerate */
            saia_frequency_set(caps->udata.config.samplerate);
            /* set channels */
            saia_channels_set(caps->udata.config.channels);

            /* save configs */
            snd_dev->replay_config.samplerate = caps->udata.config.samplerate;
            snd_dev->replay_config.channels   = caps->udata.config.channels;
            snd_dev->replay_config.samplebits = caps->udata.config.samplebits;
//            LOG_D("set samplerate %d", snd_dev->replay_config.samplerate);
            break;
        }


        case AUDIO_DSP_SAMPLERATE:
        {
            saia_frequency_set(caps->udata.config.samplerate);
            snd_dev->replay_config.samplerate = caps->udata.config.samplerate;
//            LOG_D("set samplerate %d", snd_dev->replay_config.samplerate);
            break;
        }

        case AUDIO_DSP_CHANNELS:
        {
            saia_channels_set(caps->udata.config.channels);
            snd_dev->replay_config.channels   = caps->udata.config.channels;
//            LOG_D("set channels %d", snd_dev->replay_config.channels);
            break;
        }

        case AUDIO_DSP_SAMPLEBITS:
        {
            /* not support */
            snd_dev->replay_config.samplebits = caps->udata.config.samplebits;
            break;
        }

        default:
            result = -RT_ERROR;
            break;
        }

        break;
    }

    default:
        break;
    }

    return RT_EOK;
}

static rt_err_t sound_init(struct rt_audio_device *audio)
{
    struct sound_device *snd_dev = RT_NULL;

    RT_ASSERT(audio != RT_NULL);
    snd_dev = (struct sound_device *)audio->parent.user_data;

    //dac_stop();
    adpll_init(0);
    //dac_start();
//    rt_kprintf("soundinit =%d \n",player.mp3_info.samplerate);
    /* set default params */
    saia_frequency_set(snd_dev->replay_config.samplerate);
    saia_channels_set(snd_dev->replay_config.channels);
    saia_volume_set(snd_dev->volume);

    return RT_EOK;
}

static rt_err_t sound_start(struct rt_audio_device *audio, int stream)
{
    struct sound_device *snd_dev = RT_NULL;

    RT_ASSERT(audio != RT_NULL);
    snd_dev = (struct sound_device *)audio->parent.user_data;

    if (stream == AUDIO_STREAM_REPLAY)
    {
//        LOG_D("open sound device");

        AUBUFSIZE  = (TX_FIFO_SIZE / 4 - 1);       // 2047 words max (unchanged)
        AUBUFSIZE |= (TX_FIFO_SIZE / 8) << 16;
        AUBUFSTARTADDR  = DMA_ADR(snd_dev->rx_fifo);

        DACDIGCON0  |= BIT(0) | BIT(10); // (0x01<<2)

        AUBUFCON |= BIT(1);
    }

    return RT_EOK;
}

static rt_err_t sound_stop(struct rt_audio_device *audio, int stream)
{
    RT_ASSERT(audio != RT_NULL);

    if (stream == AUDIO_STREAM_REPLAY)
    {
//        LOG_D("close sound device");
    }

    return RT_EOK;
}

rt_size_t sound_transmit(struct rt_audio_device *audio, const void *writeBuf, void *readBuf, rt_size_t size)
{
    struct sound_device *snd_dev = RT_NULL;
    rt_size_t tmp_size = size / 4;
    rt_size_t count = 0;

    RT_ASSERT(audio != RT_NULL);
    snd_dev = (struct sound_device *)audio->parent.user_data;

    while (tmp_size-- > 0) {
        if (AUBUFCON & BIT(8)) { // aubuf full
            AUBUFCON |= BIT(1) | BIT(4);
            audio_sem_pend();
        }
        AUBUFDATA = ((const uint32_t *)writeBuf)[count++];
    }

    return size;
}

static void sound_buffer_info(struct rt_audio_device *audio, struct rt_audio_buf_info *info)
{
    struct sound_device *snd_dev = RT_NULL;

    RT_ASSERT(audio != RT_NULL);
    snd_dev = (struct sound_device *)audio->parent.user_data;

    /**
     *               TX_FIFO
     * +----------------+----------------+
     * |     block1     |     block2     |
     * +----------------+----------------+
     *  \  block_size  /
     */
    info->buffer      = snd_dev->tx_fifo;
    info->total_size  = TX_FIFO_SIZE;
    info->block_size  = TX_FIFO_SIZE / 2;
    info->block_count = 2;
}

static struct rt_audio_ops ops =
{
    .getcaps     = sound_getcaps,
    .configure   = sound_configure,
    .init        = sound_init,
    .start       = sound_start,
    .stop        = sound_stop,
    .transmit    = sound_transmit,
    .buffer_info = sound_buffer_info,
};

RT_SECTION(".irq.audio")
static void audio_isr(int vector, void *param)
{
    rt_interrupt_enter();

    //Audio buffer pend
    if (AUBUFCON & BIT(5)) {
        AUBUFCON |= BIT(1);         //Audio Buffer Pend Clear
        AUBUFCON &= ~BIT(4);
        audio_sem_post();
    }
    rt_interrupt_leave();
}

 void audio_thread_entry(void *parameter)
{
    while (1)
    {
        if ((snd_dev.dma_to_aubuf == RT_FALSE) && (snd_dev.audio.replay->activated == RT_TRUE)) {
            rt_audio_tx_complete(&snd_dev.audio);
            rt_thread_mdelay(1);
        } else {
            rt_thread_mdelay(5);
        }
    }
}

 int rt_hw_sound_init(void)
{



     dac_stop();
    rt_uint8_t *tx_fifo = RT_NULL;
    rt_uint8_t *rx_fifo = RT_NULL;

    /* 分配 DMA 搬运 buffer */
    tx_fifo = rt_calloc(1, TX_FIFO_SIZE);
    if(tx_fifo == RT_NULL)
    {
        return -RT_ENOMEM;
    }

    snd_dev.tx_fifo = tx_fifo;

    /* 分配 DMA 搬运 buffer */
    rx_fifo = rt_calloc(1, TX_FIFO_SIZE);
    if(rx_fifo == RT_NULL)
    {
        return -RT_ENOMEM;
    }

    snd_dev.rx_fifo = rx_fifo;

    snd_dev.semaphore = rt_sem_create("snd", 0, RT_IPC_FLAG_FIFO);
    if (snd_dev.semaphore == RT_NULL)
    {
        return -RT_ENOMEM;
    }

    snd_dev.thread = rt_thread_create(
        "audio",
        audio_thread_entry,
        RT_NULL,
        1024,
        20, // must equal or lower than tshell priority
        1
    );

    if (snd_dev.thread != RT_NULL)
    {
        rt_thread_startup(snd_dev.thread);
    }

    /* init default configuration */
    {
        snd_dev.replay_config.samplerate = player.mp3_info.samplerate;
        snd_dev.replay_config.channels   = 2;
        snd_dev.replay_config.samplebits = 16;
        snd_dev.volume                   = 20;
    }

    /* register snd_dev device */
    snd_dev.audio.ops = &ops;
    rt_audio_register(&snd_dev.audio, "sound0", RT_DEVICE_FLAG_WRONLY, &snd_dev);

    rt_hw_interrupt_install(IRQ_AUBUF0_1_VECTOR, audio_isr, RT_NULL, "au_isr");
//    rt_kprintf("sample in hwinit =%d\n",player.mp3_info.samplerate);
    return RT_EOK;
}
void Sound_deinit(void)
{
    if (snd_dev.thread) {
        rt_thread_delete(snd_dev.thread);
       // snd_dev.thread= RT_NULL;
    }



}

INIT_DEVICE_EXPORT(rt_hw_sound_init);
